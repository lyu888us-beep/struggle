/**
 * 全量词库导入脚本
 * 数据来源（均为开源授权词库）：
 *  - kajweb/dict  (CET4_3 / CET6_3 / KaoYan_3 / IELTS_2)  —— 单词 + 英美音标 + 中文释义 + 例句
 *  - C3H3-AI/vocab-wordbank (gaokao-3500 / cet4 / cet6 / postgraduate / toefl) —— 考试大纲词表
 *  - KyleBing/english-vocabulary (高中 / CET4 / CET6 / 考研) —— 中文释义与词组
 * 输出：src/data/fullLists.ts
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const RAW = path.join(__dirname, "..", "data_raw");
const OUT = path.join(__dirname, "..", "src", "data", "fullLists.ts");

/* ---------------- 工具 ---------------- */
function readJSON(name) {
  return JSON.parse(fs.readFileSync(path.join(RAW, name), "utf8"));
}

function readJSONL(name) {
  const text = fs.readFileSync(path.join(RAW, name), "utf8");
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t[0] !== "{") continue;
    try {
      out.push(JSON.parse(t));
    } catch {
      /* skip broken line */
    }
  }
  return out;
}

function clean(text, max = 44) {
  if (!text) return "";
  let t = String(text)
    .replace(/\\n/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s"'“(（,，。.、;；:：-]+/, "")
    .trim();
  // 保留前两个义项
  const parts = t.split(/[；;]/).filter(Boolean);
  if (parts.length > 2) t = parts.slice(0, 2).join("；");
  if (t.length > max) t = t.slice(0, max);
  return t;
}

function cleanPos(pos) {
  if (!pos) return "";
  return String(pos)
    .replace(/[^a-zA-Z. ]/g, "")
    .trim()
    .slice(0, 6);
}

/* ---------------- 解析各类来源 ---------------- */
// kajweb/dict：JSONL，含英美音标与中释
function parseKajweb(name) {
  return readJSONL(name).map((item) => {
    const head = item.headWord || item.word || "";
    const inner = item.content?.word?.content || {};
    const trans = inner.trans || [];
    const pos = trans.find((t) => t.pos)?.pos || "";
    const meaning = clean(trans.map((t) => t.tranCn).filter(Boolean).join("；"));
    return {
      word: head.toLowerCase().trim(),
      uk: (inner.ukphone || inner.phone || "").replace(/^\/|\/$/g, ""),
      us: (inner.usphone || "").replace(/^\/|\/$/g, ""),
      pos: cleanPos(pos),
      meaning,
    };
  });
}

// KyleBing/english-vocabulary：词 + 中文释义 + 词组
function parseKyleBing(name) {
  return readJSON(name).map((item) => {
    const trans = item.translations || [];
    const pos = trans.find((t) => t.type)?.type || "";
    const meaning = clean(trans.map((t) => t.translation).filter(Boolean).join("；"));
    return {
      word: String(item.word || "").toLowerCase().trim(),
      uk: "",
      us: "",
      pos: cleanPos(pos),
      meaning,
    };
  });
}

// vocab-wordbank：[word, ipa, pos, meaning]
function parseWordbank(name) {
  const raw = readJSON(name);
  const arr = Array.isArray(raw) ? raw : raw.words || raw.data || [];
  return arr.map((row) => ({
    word: String(row[0] || "").toLowerCase().trim(),
    uk: String(row[1] || "").replace(/^\/|\/$/g, "").replace(/^\[|\]$/g, ""),
    us: "",
    pos: cleanPos(row[2]),
    meaning: clean(row[3]),
  }));
}

/* ---------------- 合并器 ---------------- */
const VALID_WORD = /^[a-z][a-z'-]*$/;

function mergeBooks(...sources) {
  const map = new Map();
  for (const list of sources) {
    for (const item of list) {
      if (!item.word || item.word.length > 32 || !VALID_WORD.test(item.word)) continue;
      const prev = map.get(item.word);
      if (!prev) {
        map.set(item.word, item);
      } else {
        map.set(item.word, {
          word: item.word,
          uk: prev.uk || item.uk,
          us: prev.us || item.us,
          pos: prev.pos || item.pos,
          meaning: prev.meaning || item.meaning,
        });
      }
    }
  }
  return [...map.values()].filter((w) => w.meaning);
}

function padTo(list, extraSources, target) {
  const used = new Set(list.map((w) => w.word));
  const out = [...list];
  for (const src of extraSources) {
    for (const item of src) {
      if (out.length >= target) break;
      if (!item.meaning || used.has(item.word) || !item.word || !VALID_WORD.test(item.word)) continue;
      used.add(item.word);
      out.push(item);
    }
    if (out.length >= target) break;
  }
  return out.slice(0, target);
}

/* ---------------- 主流程 ---------------- */
const kajCet4 = parseKajweb("cet4_3.jsonl");
const kajCet6 = parseKajweb("cet6_3.jsonl");
const kajKaoYan = parseKajweb("KaoYan_3.jsonl");
const kajIelts = parseKajweb("IELTS_2.jsonl");

const kbGaoZhong = parseKyleBing("kb_gaozhong.json");
const kbCet4 = parseKyleBing("kb_cet4.json");
const kbCet6 = parseKyleBing("kb_cet6.json");
const kbKaoYan = parseKyleBing("kb_kaoyan.json");

const wbGaoKao = parseWordbank("wb_gaokao.json");
const wbCet4 = parseWordbank("wb_cet4.json");
const wbCet6 = parseWordbank("wb_cet6.json");
const wbKaoYan = parseWordbank("wb_kaoyan.json");
const wbToefl = parseWordbank("wb_toefl.json");

const books = {
  // 高考 3500 词：以考纲词表为准，释义补充自高中词库
  gaokao: padTo(mergeBooks(wbGaoKao, kbGaoZhong), [kbGaoZhong, wbCet4], 3500),
  // 四级 4500 词：kajweb CET4 精品数据优先
  cet4: padTo(mergeBooks(kajCet4, wbCet4, kbCet4), [wbCet4, kbCet4], 4500),
  // 六级 5500 词
  cet6: padTo(mergeBooks(kajCet6, wbCet6, kbCet6), [wbCet6, kbCet6, wbToefl], 5500),
  // 考研 5500 词
  kaoyan: padTo(mergeBooks(kajKaoYan, wbKaoYan, kbKaoYan), [wbKaoYan, kbKaoYan, wbToefl], 5500),
  // 雅思 6000 词：雅思词库 + 学术补充
  ielts: padTo(mergeBooks(kajIelts, wbToefl, kajCet6), [wbToefl, kajCet6, kbKaoYan], 6000),
};

// 输出
const header = `/* eslint-disable */
// 自动生成文件（scripts/build-fulllists.mjs）—— 请勿手动编辑
// 数据来源：kajweb/dict · C3H3-AI/vocab-wordbank · KyleBing/english-vocabulary（开源词库）
// 条目格式: [word, uk音标, us音标, 词性, 中文释义]
export type PackedWord = [string, string, string, string, string];

`;

const sections = Object.entries(books)
  .map(([key, list]) => {
    const packed = list.map((w) => [w.word, w.uk, w.us, w.pos, w.meaning]);
    return `export const FULL_${key.toUpperCase()}: PackedWord[] = ${JSON.stringify(packed)};`;
  })
  .join("\n\n");

const counts = `export const FULL_COUNTS = { ${Object.entries(books)
  .map(([k, v]) => `${k}: ${v.length}`)
  .join(", ")} } as const;
`;

fs.writeFileSync(OUT, header + sections + "\n\n" + counts);

const bytes = fs.statSync(OUT).size;
console.log("written:", OUT, (bytes / 1024 / 1024).toFixed(2), "MB");
for (const [k, v] of Object.entries(books)) {
  const withIpa = v.filter((w) => w.uk).length;
  console.log(
    `${k.padEnd(8)} ${String(v.length).padStart(6)} 词  音标 ${withIpa}  示例: ${v[0]?.word} = ${v[0]?.meaning}`
  );
}
