import type { Accent } from "../types/vocab";

/* ------------------------------------------------------------------ *
 *  发音引擎：英式 / 美式真人录音 + Web Speech 语音合成兜底
 *  · 真人录音：Youdao dictvoice（type=1 英式，type=2 美式）
 *  · 兜底：浏览器 SpeechSynthesis，优先选择 en-GB / en-US 声线
 * ------------------------------------------------------------------ */

const ACCENT_KEY = "lexio_accent";

export function getGlobalAccent(): Accent {
  if (typeof window === "undefined") return "uk";
  const saved = localStorage.getItem(ACCENT_KEY);
  return saved === "us" ? "us" : "uk";
}

export function setGlobalAccent(accent: Accent) {
  if (typeof window === "undefined") return;
  localStorage.setItem(ACCENT_KEY, accent);
}

const accentLabel: Record<Accent, string> = { uk: "英式发音", us: "美式发音" };
export function accentName(accent: Accent) {
  return accentLabel[accent];
}

/* ---------------------------- 音效 ---------------------------- */
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!audioCtx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) audioCtx = new AudioCtx();
    }
    if (audioCtx && audioCtx.state === "suspended") void audioCtx.resume();
    return audioCtx;
  } catch {
    return null;
  }
}

function tone(
  freqStart: number,
  freqEnd: number,
  duration: number,
  type: OscillatorType = "sine",
  volume = 0.18,
  delay = 0
) {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now);
    osc.frequency.exponentialRampToValueAtTime(freqEnd, now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  } catch {
    /* ignore */
  }
}

export function playSuccessSound() {
  tone(523.25, 783.99, 0.3);
  tone(659.25, 1046.5, 0.32, "sine", 0.1, 0.07);
}

export function playErrorSound() {
  tone(220, 140, 0.22, "sawtooth", 0.14);
}

export function playFlipSound() {
  tone(320, 480, 0.09, "triangle", 0.1);
}

export function playComboSound(combo = 3) {
  const base = 440 + Math.min(combo * 45, 520);
  tone(base, base * 1.5, 0.24, "sine", 0.16);
  tone(base * 1.25, base * 1.9, 0.22, "sine", 0.09, 0.08);
}

export function playLevelUpSound() {
  [523.25, 659.25, 783.99, 1046.5].forEach((f, i) =>
    tone(f, f * 1.01, 0.26, "sine", 0.14, i * 0.09)
  );
}

/* ---------------------------- 语音合成 ---------------------------- */
function pickVoice(accent: Accent): SpeechSynthesisVoice | undefined {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return undefined;
  const voices = window.speechSynthesis.getVoices();
  if (!voices.length) return undefined;
  const english = voices.filter((v) => v.lang.toLowerCase().startsWith("en"));
  if (!english.length) return undefined;

  const priorities: Record<Accent, string[]> = {
    uk: ["en-gb", "en-ie", "en-au", "en-nz", "en-za", "en-in", "en"],
    us: ["en-us", "en-ca", "en-gb", "en-au", "en"],
  };

  for (const lang of priorities[accent]) {
    const exact = english.find((v) => v.lang.toLowerCase().replace("_", "-").startsWith(lang));
    if (exact) return exact;
  }
  return english[0];
}

function synth(text: string, accent: Accent, rate: number): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve();
      return;
    }
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = accent === "uk" ? "en-GB" : "en-US";
      utterance.rate = rate;
      utterance.pitch = 1;
      const voice = pickVoice(accent);
      if (voice) utterance.voice = voice;
      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();
      window.speechSynthesis.speak(utterance);
      // 部分浏览器不会触发 onend，加一层超时保护
      window.setTimeout(resolve, 6000);
    } catch {
      resolve();
    }
  });
}

/* ------------------------- 真人录音播放 ------------------------- */
let currentAudio: HTMLAudioElement | null = null;

function playRecording(text: string, accent: Accent): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
      }
      const type = accent === "uk" ? 1 : 2;
      const url = `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(text)}&type=${type}`;
      const audio = new Audio(url);
      audio.preload = "auto";
      currentAudio = audio;

      const timeout = window.setTimeout(() => {
        reject(new Error("audio timeout"));
      }, 3200);

      audio.onended = () => {
        window.clearTimeout(timeout);
        resolve();
      };
      audio.onerror = () => {
        window.clearTimeout(timeout);
        reject(new Error("audio error"));
      };

      const playPromise = audio.play();
      if (playPromise) {
        playPromise.then(() => window.clearTimeout(timeout)).catch(() => {
          window.clearTimeout(timeout);
          reject(new Error("autoplay blocked"));
        });
      } else {
        window.clearTimeout(timeout);
        resolve();
      }
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * 朗读单词 / 短语：优先真人录音（英式 type=1 / 美式 type=2），失败时自动使用 TTS。
 * 返回实际使用的引擎，便于界面展示「真人录音 / 智能合成」。
 */
export async function pronounce(
  text: string,
  accent: Accent = "uk"
): Promise<"recorded" | "synth"> {
  const clean = text.trim();
  if (!clean) return "synth";
  try {
    await playRecording(clean, accent);
    return "recorded";
  } catch {
    await synth(clean, accent, accent === "uk" ? 0.9 : 0.95);
    return "synth";
  }
}

/** 朗读整句（使用更自然的 TTS，避免逐词拼接） */
export async function pronounceSentence(text: string, accent: Accent = "uk"): Promise<void> {
  await synth(text, accent, accent === "uk" ? 0.88 : 0.92);
}

/** 兼容旧调用 */
export function speakWord(text: string, rate = 0.95): Promise<void> {
  return synth(text, getGlobalAccent(), rate);
}

export function cancelPronunciation() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
  if (currentAudio) {
    currentAudio.pause();
    currentAudio = null;
  }
}
