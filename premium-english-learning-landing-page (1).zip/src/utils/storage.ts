import { UserProgress } from "../types/vocab";

const STORAGE_KEY = "lexio_student_progress_v1";

const DEFAULT_PROGRESS: UserProgress = {
  selectedBook: "cet4",
  streakDays: 7,
  lastStudyDate: new Date().toISOString().slice(0, 10),
  todayLearnedCount: 14,
  todayGoal: 20,
  learnedWordIds: ["cet4-1", "cet4-2"],
  mistakeWordIds: ["cet4-5"],
  masteredWordIds: ["cet4-1"],
  totalScore: 1240,
};

export function loadUserProgress(): UserProgress {
  if (typeof window === "undefined") return DEFAULT_PROGRESS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_PROGRESS, ...parsed };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveUserProgress(progress: UserProgress) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // ignore
  }
}
