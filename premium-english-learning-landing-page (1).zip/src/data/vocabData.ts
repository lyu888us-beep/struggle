import type { DailySentence, RootLesson, VocabBook, WordItem } from "../types/vocab";
import { GAOKAO_WORDS } from "./words/gaokao";
import { CET4_WORDS } from "./words/cet4";
import { CET6_WORDS } from "./words/cet6";
import { KAOYAN_WORDS } from "./words/kaoyan";
import { IELTS_WORDS } from "./words/ielts";
import { GAOKAO_WORDS_2, CET4_WORDS_2 } from "./words/extraA";
import { CET6_WORDS_2, KAOYAN_WORDS_2 } from "./words/extraB";
import { IELTS_WORDS_2 } from "./words/extraC";

export const VOCAB_BOOKS: VocabBook[] = [
  {
    id: "gaokao",
    title: "高考核心 3500 词",
    subtitle: "全国卷 & 新高考必考考纲词汇",
    totalWords: 3500,
    badge: "冲刺高考",
    icon: "🎓",
    color: "from-blue-500 to-indigo-600",
    highlights: ["考纲 3500 词全覆盖", "近 10 年真题高频标注", "完形 + 阅读语境例句"],
  },
  {
    id: "cet4",
    title: "大学英语四级 (CET-4)",
    subtitle: "历年四级高频考点核心词汇",
    totalWords: 4500,
    badge: "高频核心",
    icon: "📘",
    color: "from-indigo-500 to-violet-600",
    highlights: ["四级 4500 词分级", "听力 + 阅读双场景", "写作话题词块"],
  },
  {
    id: "cet6",
    title: "大学英语六级 (CET-6)",
    subtitle: "六级刷分与阅读难词特训",
    totalWords: 5500,
    badge: "进阶刷分",
    icon: "🚀",
    color: "from-violet-500 to-purple-600",
    highlights: ["六级难词精讲", "同义替换专项", "翻译高频表达"],
  },
  {
    id: "kaoyan",
    title: "考研英语必背 5500",
    subtitle: "历年考研英语真题熟词生义",
    totalWords: 5500,
    badge: "上岸必备",
    icon: "🏆",
    color: "from-fuchsia-500 to-pink-600",
    highlights: ["熟词生义深挖", "考研长难句拆解", "写作高分替换"],
  },
  {
    id: "ielts",
    title: "雅思核心词汇 (IELTS)",
    subtitle: "听力/阅读/写作高分学术词汇",
    totalWords: 6000,
    badge: "留学首选",
    icon: "🌏",
    color: "from-emerald-500 to-teal-600",
    highlights: ["剑桥雅思真题语料", "大作文话题词伙", "学术搭配与词族"],
  },
];

export const INITIAL_WORDS: WordItem[] = [
  ...GAOKAO_WORDS,
  ...GAOKAO_WORDS_2,
  ...CET4_WORDS,
  ...CET4_WORDS_2,
  ...CET6_WORDS,
  ...CET6_WORDS_2,
  ...KAOYAN_WORDS,
  ...KAOYAN_WORDS_2,
  ...IELTS_WORDS,
  ...IELTS_WORDS_2,
];

export const WORDS_BY_CATEGORY: Record<string, WordItem[]> = {
  gaokao: [...GAOKAO_WORDS, ...GAOKAO_WORDS_2],
  cet4: [...CET4_WORDS, ...CET4_WORDS_2],
  cet6: [...CET6_WORDS, ...CET6_WORDS_2],
  kaoyan: [...KAOYAN_WORDS, ...KAOYAN_WORDS_2],
  ielts: [...IELTS_WORDS, ...IELTS_WORDS_2],
};

export function getWordsOfBook(bookId: string): WordItem[] {
  return WORDS_BY_CATEGORY[bookId] ?? WORDS_BY_CATEGORY.cet4;
}

/* ----------------------- 每日一句（英式发音） ----------------------- */
export const DAILY_SENTENCES: DailySentence[] = [
  {
    id: "ds-1",
    en: "Small steps, taken daily, carry you further than one giant leap.",
    zh: "每天迈出的一小步，比一次巨大的跨越能带你走得更远。",
    source: "Lexio 学习激励 · 高频句式",
    tip: "注意 daily 作副词时位于句尾；further 表示抽象意义上的“更远”。",
  },
  {
    id: "ds-2",
    en: "The more you expose yourself to authentic English, the more natural it becomes.",
    zh: "你接触真实英语越多，它就会变得越自然。",
    source: "剑桥雅思写作范文 · 句型",
    tip: "the more…, the more… 是比较级并列结构，写作提分利器。",
  },
  {
    id: "ds-3",
    en: "What matters is not how fast you memorize, but how often you review.",
    zh: "重要的不是记得多快，而是复习得多勤。",
    source: "考研英语一 · 完形填空语感",
    tip: "what 引导主语从句；not…but… 构成对比，适合论证段落。",
  },
  {
    id: "ds-4",
    en: "Language is not a subject to be studied, but a world to be explored.",
    zh: "语言不是一门用来研究的学科，而是一个值得探索的世界。",
    source: "Lexio 每日一句",
    tip: "be studied / be explored 为不定式被动，语气更正式。",
  },
];

/* ----------------------- 词根词缀小课堂 ----------------------- */
export const ROOT_LESSONS: RootLesson[] = [
  {
    id: "root-1",
    root: "spect / spec",
    meaning: "看（look）",
    color: "from-indigo-500 to-violet-600",
    words: [
      { word: "inspect", zh: "检查（往里看）" },
      { word: "perspective", zh: "视角（透过看）" },
      { word: "scrutinize", zh: "仔细审查" },
    ],
  },
  {
    id: "root-2",
    root: "port",
    meaning: "携带（carry）",
    color: "from-emerald-500 to-teal-600",
    words: [
      { word: "transport", zh: "运输（跨地携带）" },
      { word: "support", zh: "支持（从下托举）" },
      { word: "portable", zh: "便携的" },
    ],
  },
  {
    id: "root-3",
    root: "mit / miss",
    meaning: "送、放（send）",
    color: "from-fuchsia-500 to-pink-600",
    words: [
      { word: "submit", zh: "提交（向上送）" },
      { word: "mitigate", zh: "减轻（让走开）" },
      { word: "mission", zh: "任务（被派出）" },
    ],
  },
  {
    id: "root-4",
    root: "dict",
    meaning: "说（speak）",
    color: "from-amber-500 to-orange-600",
    words: [
      { word: "predict", zh: "预测（预先说）" },
      { word: "contradict", zh: "反驳（反着说）" },
      { word: "dedicate", zh: "奉献（郑重说出）" },
    ],
  },
];

/* --------------------- 英式/美式发音试听示例 --------------------- */
export const PRONUNCIATION_SAMPLES: {
  word: string;
  uk: string;
  us: string;
  zh: string;
  note: string;
}[] = [
  {
    word: "schedule",
    uk: "/ˈʃedjuːl/",
    us: "/ˈskedʒuːl/",
    zh: "日程；计划",
    note: "英式读 /ʃ/，美式读 /sk/，是考试听力最常见的辨析点。",
  },
  {
    word: "advertisement",
    uk: "/ədˈvɜːtɪsmənt/",
    us: "/ˌædvərˈtaɪzmənt/",
    zh: "广告",
    note: "英式重音在第二音节，美式常在第三音节。",
  },
  {
    word: "either",
    uk: "/ˈaɪðə/",
    us: "/ˈiːðər/",
    zh: "二者之一",
    note: "英式多用 /aɪ/，美式多用 /iː/，两种均为标准读音。",
  },
  {
    word: "vase",
    uk: "/vɑːz/",
    us: "/veɪs/",
    zh: "花瓶",
    note: "雅思口语 Part 2 物品题高频词，注意英式长元音。",
  },
];
