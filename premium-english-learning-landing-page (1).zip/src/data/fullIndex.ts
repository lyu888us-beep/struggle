import type { WordCategory, WordItem } from "../types/vocab";
import {
  FULL_CET4,
  FULL_CET6,
  FULL_GAOKAO,
  FULL_IELTS,
  FULL_KAOYAN,
  FULL_COUNTS,
  type PackedWord,
} from "./fullLists";
import { WORDS_BY_CATEGORY } from "./vocabData";

const PACKED: Record<WordCategory, PackedWord[]> = {
  gaokao: FULL_GAOKAO,
  cet4: FULL_CET4,
  cet6: FULL_CET6,
  kaoyan: FULL_KAOYAN,
  ielts: FULL_IELTS,
};

function toItem(book: WordCategory, row: PackedWord): WordItem {
  const [word, uk, us, pos, meaning] = row;
  return {
    id: `${book}::${word}`,
    word,
    phonetic: uk ? `/${uk}/` : "",
    usPhonetic: us ? `/${us}/` : "",
    pos: pos || "",
    meaning,
    example: "",
    exampleTranslation: "",
    category: book,
    frequency: 3,
  };
}

function buildBook(book: WordCategory): WordItem[] {
  const rich = WORDS_BY_CATEGORY[book] ?? [];
  const seen = new Set(rich.map((w) => w.word.toLowerCase()));
  const lite = PACKED[book]
    .filter((row) => !seen.has(row[0]))
    .map((row) => toItem(book, row));
  return [...rich, ...lite];
}

const CACHE = new Map<WordCategory, WordItem[]>();

export function getBookWords(book: WordCategory): WordItem[] {
  let list = CACHE.get(book);
  if (!list) {
    list = buildBook(book);
    CACHE.set(book, list);
  }
  return list;
}

export const BOOK_TOTALS: Record<WordCategory, number> = FULL_COUNTS;
export const TOTAL_IMPORTED = Object.values(FULL_COUNTS).reduce((a, b) => a + b, 0);
export const TOTAL_WITH_IPA = (Object.keys(PACKED) as WordCategory[]).reduce(
  (sum, key) => sum + PACKED[key].filter((row) => row[1]).length,
  0
);
