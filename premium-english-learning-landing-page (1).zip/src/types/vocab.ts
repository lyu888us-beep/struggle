export type WordCategory = "gaokao" | "cet4" | "cet6" | "kaoyan" | "ielts";
export type Accent = "uk" | "us";

export interface Collocation {
  phrase: string;
  zh: string;
}

export interface WordFamilyItem {
  word: string;
  pos: string;
  zh: string;
}

export interface WordItem {
  id: string;
  word: string;
  /** 英式音标 */
  phonetic?: string;
  /** 美式音标 */
  usPhonetic?: string;
  pos: string;
  meaning: string;
  example?: string;
  exampleTranslation?: string;
  mnemonic?: string;
  category: WordCategory;
  frequency: number;
  synonyms?: string[];
  antonyms?: string[];
  collocations?: Collocation[];
  wordFamily?: WordFamilyItem[];
  examSource?: string;
}

export interface VocabBook {
  id: WordCategory;
  title: string;
  subtitle: string;
  totalWords: number;
  badge: string;
  icon: string;
  color: string;
  highlights: string[];
}

export interface DailySentence {
  id: string;
  en: string;
  zh: string;
  source: string;
  tip: string;
}

export interface RootLesson {
  id: string;
  root: string;
  meaning: string;
  color: string;
  words: { word: string; zh: string }[];
}

export interface UserProgress {
  selectedBook: WordCategory;
  streakDays: number;
  lastStudyDate: string;
  todayLearnedCount: number;
  todayGoal: number;
  learnedWordIds: string[];
  mistakeWordIds: string[];
  masteredWordIds: string[];
  totalScore: number;
}
