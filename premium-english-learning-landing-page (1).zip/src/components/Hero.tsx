import { useState } from "react";
import Reveal from "./Reveal";
import { pronounce } from "../utils/audio";

const words = [
  { en: "serendipity", zh: "意外发现美好事物的运气", pos: "n.", phonetic: "/ˌserənˈdɪpəti/", sentence: "Finding that book was pure serendipity." },
  { en: "resilient", zh: "有韧性的；适应力强的", pos: "adj.", phonetic: "/rɪˈzɪliənt/", sentence: "Students are remarkably resilient learners." },
  { en: "illuminate", zh: "照亮；阐明", pos: "v.", phonetic: "/ɪˈluːmɪneɪt/", sentence: "Good examples illuminate new words." },
];

function FlashcardMock({ onOpenApp }: { onOpenApp: () => void }) {
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const word = words[index];

  const next = (known: boolean) => {
    void known;
    setFlipped(false);
    setTimeout(() => setIndex((i) => (i + 1) % words.length), 180);
  };

  return (
    <div className="relative mx-auto w-full max-w-sm">
      {/* Floating badges */}
      <div className="glass animate-float absolute -left-6 top-10 z-20 hidden items-center gap-2 rounded-2xl px-4 py-3 shadow-xl shadow-indigo-900/10 sm:flex">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-100 text-lg" aria-hidden="true">🔥</span>
        <div>
          <p className="text-xs font-semibold text-slate-900">连续打卡 42 天</p>
          <p className="text-[11px] text-slate-500">超过 98% 的同学</p>
        </div>
      </div>
      <div className="glass animate-float-slow absolute -right-8 bottom-16 z-20 hidden items-center gap-2 rounded-2xl px-4 py-3 shadow-xl shadow-indigo-900/10 sm:flex">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-indigo-100 text-lg" aria-hidden="true">🧠</span>
        <div>
          <p className="text-xs font-semibold text-slate-900">今日记忆 68 词</p>
          <p className="text-[11px] text-slate-500">记忆保持率 94%</p>
        </div>
      </div>

      {/* Phone frame */}
      <div className="relative rounded-[2.4rem] border border-white/60 bg-white/70 p-3 shadow-2xl shadow-indigo-500/20 backdrop-blur-xl">
        <div className="overflow-hidden rounded-[1.9rem] bg-gradient-to-b from-slate-50 to-indigo-50/60">
          {/* status bar */}
          <div className="flex items-center justify-between px-6 pb-2 pt-4 text-[10px] font-semibold text-slate-400">
            <span>9:41</span>
            <button
              onClick={onOpenApp}
              className="rounded-full bg-indigo-600 px-2 py-0.5 text-[9px] font-bold text-white hover:bg-indigo-700 transition-colors"
            >
              点击全屏使用 ↗
            </button>
          </div>
          {/* progress */}
          <div className="px-6">
            <div className="flex items-center justify-between text-[11px] font-medium text-slate-500">
              <span>四级核心 · Unit 7</span>
              <span>{index + 1} / 20</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200/80">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 transition-all duration-500"
                style={{ width: `${((index + 1) / words.length) * 60 + 10}%` }}
              />
            </div>
          </div>

          {/* flip card */}
          <div className="px-5 py-6" style={{ perspective: "1200px" }}>
            <button
              onClick={() => {
                setFlipped((f) => !f);
                void pronounce(word.en, "uk");
              }}
              aria-label={flipped ? "查看单词" : "查看释义"}
              className="relative block h-64 w-full cursor-pointer transition-transform duration-700 [transform-style:preserve-3d] focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
              style={{ transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)" }}
            >
              {/* front */}
              <span className="absolute inset-0 flex flex-col items-center justify-center rounded-3xl border border-white bg-white p-6 text-center shadow-lg shadow-indigo-900/5 [backface-visibility:hidden]">
                <span className="rounded-full bg-indigo-50 px-3 py-1 text-[11px] font-semibold text-indigo-600">{word.pos} · 高频词</span>
                <span className="mt-4 text-3xl font-bold tracking-tight text-slate-900">{word.en}</span>
                <span className="mt-2 text-sm text-slate-400">{word.phonetic}</span>
                <span className="mt-6 flex items-center gap-1.5 text-xs font-medium text-indigo-500">
                  <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z" /></svg>
                  点击卡片 · 英式朗读
                </span>
              </span>
              {/* back */}
              <span
                className="absolute inset-0 flex flex-col items-center justify-center rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-6 text-center shadow-lg shadow-indigo-500/30 [backface-visibility:hidden]"
                style={{ transform: "rotateY(180deg)" }}
              >
                <span className="text-xl font-bold text-white">{word.zh}</span>
                <span className="mt-4 rounded-2xl bg-white/15 px-4 py-3 text-xs leading-relaxed text-indigo-50">
                  “{word.sentence}”
                </span>
              </span>
            </button>
          </div>

          {/* actions */}
          <div className="flex gap-3 px-5 pb-6">
            <button
              onClick={() => next(false)}
              className="flex-1 rounded-2xl border border-slate-200 bg-white py-3 text-sm font-semibold text-slate-600 transition-all duration-200 hover:-translate-y-0.5 hover:border-rose-200 hover:text-rose-500 hover:shadow-lg hover:shadow-rose-500/10"
            >
              不认识
            </button>
            <button
              onClick={() => next(true)}
              className="flex-1 rounded-2xl bg-slate-900 py-3 text-sm font-semibold text-white transition-all duration-200 hover:-translate-y-0.5 hover:bg-indigo-600 hover:shadow-lg hover:shadow-indigo-500/30"
            >
              认识 ✓
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface HeroProps {
  onOpenApp: () => void;
}

export default function Hero({ onOpenApp }: HeroProps) {
  return (
    <section id="top" className="relative overflow-hidden pb-20 pt-32 sm:pt-40 lg:pb-28">
      {/* Ambient background */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="animate-blob absolute -top-32 left-1/4 h-[32rem] w-[32rem] rounded-full bg-indigo-300/30 blur-3xl" />
        <div className="animate-blob absolute right-0 top-20 h-[28rem] w-[28rem] rounded-full bg-fuchsia-300/25 blur-3xl" style={{ animationDelay: "-6s" }} />
        <div className="animate-blob absolute -bottom-24 left-0 h-[24rem] w-[24rem] rounded-full bg-sky-300/25 blur-3xl" style={{ animationDelay: "-12s" }} />
        <div
          className="absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(99,102,241,0.07) 1px, transparent 1px), linear-gradient(to bottom, rgba(99,102,241,0.07) 1px, transparent 1px)",
            backgroundSize: "56px 56px",
            maskImage: "radial-gradient(ellipse 80% 60% at 50% 0%, black, transparent)",
          }}
        />
      </div>

      <div className="relative mx-auto grid max-w-6xl items-center gap-16 px-5 sm:px-6 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="text-center lg:text-left">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-indigo-200/80 bg-white/70 px-4 py-1.5 text-xs font-semibold text-indigo-600 shadow-sm backdrop-blur">
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-indigo-500" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-indigo-500" />
              </span>
              2026 新学期 · 超过 300 万学生正在使用
            </span>
          </Reveal>

          <Reveal delay={120} as="h1">
            <span className="mt-6 block text-4xl font-extrabold leading-[1.12] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              背单词，
              <br className="hidden sm:block" />
              从此<span className="text-gradient">快 3 倍</span>且不再遗忘
            </span>
          </Reveal>

          <Reveal delay={240} as="p">
            <span className="mx-auto mt-6 block max-w-xl text-base leading-relaxed text-slate-500 sm:text-lg lg:mx-0">
              Lexio 乐词已全量录入高考 3500 / 四级 4500 / 六级 5500 / 考研 5500 / 雅思 6000 共 25,000 词，基于 AI 记忆曲线为你定制每日词单。
              真题语境 + 英式真人发音 + 游戏化闯关，让每一个单词都刻进长期记忆。
            </span>
          </Reveal>

          <Reveal delay={360}>
            <div className="mt-9 flex flex-col items-center gap-4 sm:flex-row sm:justify-center lg:justify-start">
              <button
                onClick={onOpenApp}
                className="group relative inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-[length:200%_auto] px-8 py-4 text-base font-semibold text-white shadow-xl shadow-indigo-500/30 transition-all duration-300 hover:-translate-y-0.5 hover:bg-[position:right_center] hover:shadow-2xl hover:shadow-indigo-500/40 sm:w-auto cursor-pointer"
              >
                <span>立即进入背单词 App (免安装)</span>
                <svg className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
              <a
                href="#showcase"
                className="group inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white/80 px-8 py-4 text-base font-semibold text-slate-700 backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-indigo-300 hover:text-indigo-600 hover:shadow-lg hover:shadow-indigo-500/10 sm:w-auto"
              >
                <svg className="h-5 w-5 text-indigo-500 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M8 5v14l11-7z" />
                </svg>
                功能特性演示
              </a>
            </div>
          </Reveal>

          <Reveal delay={480}>
            <div className="mt-9 flex items-center justify-center gap-4 lg:justify-start">
              <div className="flex -space-x-2.5" aria-hidden="true">
                {["from-amber-400 to-orange-500", "from-sky-400 to-indigo-500", "from-emerald-400 to-teal-500", "from-fuchsia-400 to-pink-500"].map((g, i) => (
                  <span key={i} className={`grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-gradient-to-br ${g} text-[11px] font-bold text-white shadow`}>
                    {["李", "王", "张", "陈"][i]}
                  </span>
                ))}
              </div>
              <div className="text-left">
                <div className="flex text-amber-400" aria-label="评分 4.9 / 5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <svg key={i} className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path d="M9.05 2.93c.3-.92 1.6-.92 1.9 0l1.3 3.98a1 1 0 0 0 .95.69h4.18c.97 0 1.37 1.24.59 1.81l-3.39 2.46a1 1 0 0 0-.36 1.12l1.3 3.98c.3.92-.76 1.69-1.54 1.12l-3.38-2.46a1 1 0 0 0-1.18 0l-3.38 2.46c-.78.57-1.84-.2-1.54-1.12l1.3-3.98a1 1 0 0 0-.36-1.12L2.03 9.4c-.78-.57-.38-1.8.59-1.8H6.8a1 1 0 0 0 .95-.7l1.3-3.98z" />
                    </svg>
                  ))}
                </div>
                <p className="text-xs font-medium text-slate-500">4.9 分 · 来自 12 万+ 学生真实评价</p>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={300} direction="scale">
          <FlashcardMock onOpenApp={onOpenApp} />
        </Reveal>
      </div>
    </section>
  );
}
