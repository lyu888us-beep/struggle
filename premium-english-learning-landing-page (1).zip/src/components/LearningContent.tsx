import { useState } from "react";
import Reveal from "./Reveal";
import { VOCAB_BOOKS, PRONUNCIATION_SAMPLES, ROOT_LESSONS, INITIAL_WORDS, WORDS_BY_CATEGORY } from "../data/vocabData";
import { BOOK_TOTALS, TOTAL_IMPORTED, TOTAL_WITH_IPA } from "../data/fullIndex";
import { pronounce, setGlobalAccent } from "../utils/audio";
import { cn } from "../utils/cn";
import type { Accent, WordCategory } from "../types/vocab";

const WORD_COUNTS: Record<string, number> = BOOK_TOTALS as unknown as Record<string, number>;
const RICH_COUNTS: Record<string, number> = Object.fromEntries(
  Object.entries(WORDS_BY_CATEGORY).map(([k, v]) => [k, v.length])
);

interface LearningContentProps {
  onOpenApp: () => void;
  onOpenBook: (book: WordCategory) => void;
}

export default function LearningContent({ onOpenApp, onOpenBook }: LearningContentProps) {
  const [playing, setPlaying] = useState<string | null>(null);
  const [activeAccent, setActiveAccent] = useState<Accent>("uk");

  const play = async (word: string, accent: Accent, key: string) => {
    setPlaying(key);
    setActiveAccent(accent);
    setGlobalAccent(accent);
    await pronounce(word, accent);
    setPlaying(null);
  };

  return (
    <section id="content" className="relative overflow-hidden py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute -left-20 top-1/4 h-[26rem] w-[26rem] rounded-full bg-indigo-200/30 blur-3xl" />
        <div className="absolute -right-16 bottom-10 h-[22rem] w-[22rem] rounded-full bg-fuchsia-200/30 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-indigo-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-indigo-600 ring-1 ring-indigo-100">
              学习内容矩阵
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
              不只是单词表，
              <span className="text-gradient">而是一整套备考内容</span>
            </span>
          </Reveal>
          <Reveal delay={200} as="p">
            <span className="mt-5 block text-base leading-relaxed text-slate-500 sm:text-lg">
              5 大目标词库全量录入 · 共 {TOTAL_IMPORTED.toLocaleString()} 词 · {TOTAL_WITH_IPA.toLocaleString()} 词含英美音标 · {INITIAL_WORDS.length} 个精讲词条
            </span>
          </Reveal>
        </div>

        {/* 英式发音试听 */}
        <Reveal delay={120} direction="scale">
          <div className="mt-14 overflow-hidden rounded-[2rem] border border-slate-200/80 bg-white/90 p-6 shadow-xl shadow-indigo-900/5 backdrop-blur sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <span className="grid h-8 w-8 place-items-center rounded-xl bg-indigo-100 text-base">🎧</span>
                  英式发音 · 美式发音 双音试听
                </h3>
                <p className="mt-1.5 text-sm text-slate-500">
                  词条、例句均支持英式真人录音与美式真人录音，可随时切换；弱网环境自动切换智能语音。
                </p>
                <p className="mt-1 text-[11px] text-slate-400">
                  默认 🇬🇧 英式发音 · 真人录音来自在线词典音频，语音合成使用浏览器本地 en-GB / en-US 声线
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-2xl border border-slate-200 p-1" role="group" aria-label="默认发音偏好">
                {(
                  [
                    { id: "uk" as Accent, label: "🇬🇧 英式" },
                    { id: "us" as Accent, label: "🇺🇸 美式" },
                  ]
                ).map((a) => (
                  <button
                    key={a.id}
                    onClick={() => {
                      setActiveAccent(a.id);
                      setGlobalAccent(a.id);
                    }}
                    aria-pressed={activeAccent === a.id}
                    className={cn(
                      "rounded-xl px-3 py-1.5 text-xs font-bold transition-all",
                      activeAccent === a.id ? "bg-slate-900 text-white shadow" : "text-slate-500 hover:text-slate-800"
                    )}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {PRONUNCIATION_SAMPLES.map((s, i) => (
                <div
                  key={s.word}
                  className="group rounded-2xl border border-slate-200 bg-slate-50/60 p-4 transition-all hover:-translate-y-0.5 hover:border-indigo-200 hover:bg-white hover:shadow-md"
                  style={{ transitionDelay: `${i * 30}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-lg font-extrabold text-slate-900">{s.word}</p>
                    <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-semibold text-slate-500 ring-1 ring-slate-200">{s.zh}</span>
                  </div>
                  <div className="mt-2.5 flex flex-wrap gap-2">
                    <button
                      onClick={() => void play(s.word, "uk", `${s.word}-uk`)}
                      className={cn(
                        "flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-semibold transition-all",
                        activeAccent === "uk" ? "bg-indigo-600 text-white shadow" : "bg-white text-indigo-700 ring-1 ring-indigo-200 hover:bg-indigo-50"
                      )}
                    >
                      🇬🇧 英式 <span className="font-mono opacity-80">{s.uk}</span>
                      <span className={playing === `${s.word}-uk` ? "animate-pulse" : ""}>🔊</span>
                    </button>
                    <button
                      onClick={() => void play(s.word, "us", `${s.word}-us`)}
                      className={cn(
                        "flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-semibold transition-all",
                        activeAccent === "us" ? "bg-slate-900 text-white shadow" : "bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50"
                      )}
                    >
                      🇺🇸 美式 <span className="font-mono opacity-80">{s.us}</span>
                      <span className={playing === `${s.word}-us` ? "animate-pulse" : ""}>🔊</span>
                    </button>
                  </div>
                  <p className="mt-2.5 text-[11px] leading-relaxed text-slate-500">💡 {s.note}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* 词库矩阵 */}
        <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {VOCAB_BOOKS.map((book, i) => (
            <Reveal key={book.id} delay={i * 70}>
              <article className="group flex h-full flex-col rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-sm backdrop-blur transition-all duration-500 hover:-translate-y-1.5 hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-500/10">
                <div className="flex items-center justify-between">
                  <span className={`grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br ${book.color} text-xl shadow-lg transition-transform duration-500 group-hover:scale-110`}>
                    {book.icon}
                  </span>
                  <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-[10px] font-bold text-indigo-700">{book.badge}</span>
                </div>
                <h3 className="mt-4 text-base font-bold text-slate-900">{book.title}</h3>
                <p className="mt-1 text-xs text-slate-500">{book.subtitle}</p>
                <ul className="mt-3 flex-1 space-y-1.5">
                  {book.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-1.5 text-[11px] text-slate-600">
                      <span className="mt-0.5 text-emerald-500">✓</span>
                      {h}
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                  <span className="text-[11px] font-semibold text-slate-400">已录入 {(WORD_COUNTS[book.id] ?? 0).toLocaleString()} 词 · 精讲 {RICH_COUNTS[book.id] ?? 0} 词</span>
                  <button
                    onClick={() => onOpenBook(book.id)}
                    className="text-[11px] font-bold text-indigo-600 transition-transform group-hover:translate-x-0.5 hover:text-fuchsia-600"
                  >
                    开始学习 →
                  </button>
                </div>
              </article>
            </Reveal>
          ))}

          {/* 词根课堂卡片 */}
          <Reveal delay={350}>
            <article className="flex h-full flex-col rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl">
              <div className="flex items-center justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 text-xl">🧩</span>
                <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold text-indigo-200">每日更新</span>
              </div>
              <h3 className="mt-4 text-base font-bold">词根词缀小课堂</h3>
              <p className="mt-1 text-xs text-slate-400">掌握 1 个词根，串起 8 个单词</p>
              <div className="mt-3 flex-1 space-y-2">
                {ROOT_LESSONS.slice(0, 3).map((r) => (
                  <div key={r.id} className="rounded-xl bg-white/5 p-2.5 ring-1 ring-white/10">
                    <p className="text-[11px] font-bold text-indigo-200">
                      {r.root} <span className="font-normal text-slate-400">· {r.meaning}</span>
                    </p>
                    <p className="mt-0.5 text-[10px] text-slate-300">{r.words.map((w) => w.word).join(" / ")}</p>
                  </div>
                ))}
              </div>
              <button
                onClick={onOpenApp}
                className="mt-4 rounded-xl bg-white/10 py-2 text-[11px] font-bold text-white ring-1 ring-white/20 transition-colors hover:bg-white/20"
              >
                进入内容中心 →
              </button>
            </article>
          </Reveal>
        </div>

        <Reveal delay={150}>
          <div className="mt-10 flex flex-col items-center justify-between gap-4 rounded-3xl border border-indigo-100 bg-indigo-50/60 p-5 sm:flex-row sm:p-6">
            <div className="text-center sm:text-left">
              <p className="text-sm font-bold text-slate-900">想看完整词条、搭配与真题出处？</p>
              <p className="mt-0.5 text-xs text-slate-500">进入 App 的「词库内容中心」，支持搜索、双音试听、错词标记与词族拓展。</p>
            </div>
            <button
              onClick={onOpenApp}
              className="group inline-flex shrink-0 items-center gap-2 rounded-2xl bg-slate-900 px-5 py-3 text-xs font-bold text-white shadow-lg transition-all hover:-translate-y-0.5 hover:bg-indigo-600"
            >
              打开词库内容中心
              <svg className="h-4 w-4 transition-transform group-hover:translate-x-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
