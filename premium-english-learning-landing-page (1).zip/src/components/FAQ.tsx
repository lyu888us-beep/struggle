import { useState } from "react";
import Reveal from "./Reveal";
import { cn } from "../utils/cn";

const faqs = [
  {
    q: "系统里到底有多少单词？是完整词库吗？",
    a: "五套目标词库已全量录入：高考 3,500 词、CET-4 4,500 词、CET-6 5,500 词、考研 5,500 词、雅思 6,000 词，合计 25,000 词，全部带中文释义，其中 15,800+ 词附英式 / 美式音标。另有 100 个精讲词条额外提供真题例句、词根助记、近反义词、高频搭配与词族。",
  },
  {
    q: "词条里具体包含哪些学习内容？",
    a: "精讲词条包含：英式 / 美式两套音标、词性、中文释义、词根词缀助记、真题例句与翻译、近义词、反义词、高频搭配、同根词族与真题出处；全量大纲词条则提供音标、词性与中文释义。进入 App 的「词库内容中心」即可跨词库搜索、试听并查看完整详情。",
  },
  {
    q: "英式发音是真人录音吗？可以切换美音吗？",
    a: "词条发音优先使用英式 / 美式真人录音，默认英式；如果网络较弱或音频不可用，会自动切换为浏览器 en-GB / en-US 智能语音兜底。你可以在 App 顶部或学习卡片上随时切换英音与美音，例句也支持整句朗读。",
  },
  {
    q: "Lexio 和普通背单词 App 有什么不同？",
    a: "大多数 App 只是电子化的单词书。Lexio 的核心是 FSRS 间隔重复记忆引擎——为每个单词建立独立记忆档案，在你即将遗忘的时刻精准安排复习。配合真题语境、词根拆解和游戏化机制，不仅背得快，更忘得慢。",
  },
  {
    q: "覆盖哪些考试的词库？",
    a: "全面覆盖小学、中考、高考（含 3500 考纲词）、四级、六级、考研、专四专八、雅思、托福、GRE 等 30+ 官方考纲词库，并持续更新。Pro 用户还可以导入自定义词单。",
  },
  {
    q: "每天需要花多少时间？",
    a: "平均 15 分钟即可完成当日任务。你可以在设置里自由调整每日新词量（10–100 词），AI 会根据你的考试日期和学习状态动态平衡新词与复习词的比例。",
  },
  {
    q: "免费版够用吗？",
    a: "免费版包含完整的 AI 记忆曲线复习功能和 1 个词库，适合轻度学习。如果你在备考冲刺期，Pro 版的无限词量、错词强化、真题语境和对战功能可以显著提升效率——还有 7 天免费试用，不满意随时取消。",
  },
  {
    q: "没有网络也能学习吗？",
    a: "可以。Pro 版支持词库离线下载，地铁、飞机上照常学习，联网后自动同步进度。手机、平板、电脑网页三端数据实时互通。",
  },
  {
    q: "家长或老师可以查看学习情况吗？",
    a: "可以。开启「学习周报」后，系统每周自动生成可视化报告（学习时长、掌握词量、薄弱点分析），可一键分享给家长。学校班级版还提供教师管理后台和班级学情大屏。",
  },
];

function Item({ faq, open, onToggle, index }: { faq: (typeof faqs)[number]; open: boolean; onToggle: () => void; index: number }) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border transition-all duration-300",
        open ? "border-indigo-200 bg-white shadow-lg shadow-indigo-500/10" : "border-slate-200/80 bg-white/70 hover:border-indigo-200/70"
      )}
    >
      <button
        className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
        onClick={onToggle}
        aria-expanded={open}
        aria-controls={`faq-panel-${index}`}
      >
        <span className="text-sm font-bold text-slate-900 sm:text-base">{faq.q}</span>
        <span
          className={cn(
            "grid h-8 w-8 shrink-0 place-items-center rounded-full border text-slate-500 transition-all duration-300",
            open ? "rotate-45 border-indigo-300 bg-indigo-50 text-indigo-600" : "border-slate-200 bg-white"
          )}
          aria-hidden="true"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M12 5v14M5 12h14" />
          </svg>
        </span>
      </button>
      <div
        id={`faq-panel-${index}`}
        role="region"
        className={cn("grid transition-all duration-400 ease-in-out", open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")}
      >
        <div className="overflow-hidden">
          <p className="px-6 pb-6 text-sm leading-relaxed text-slate-500">{faq.a}</p>
        </div>
      </div>
    </div>
  );
}

export default function FAQ() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="relative bg-gradient-to-b from-white to-indigo-50/50 py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5 sm:px-6">
        <div className="text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-sky-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-sky-600 ring-1 ring-sky-100">
              常见问题
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
              你想知道的，都在这里
            </span>
          </Reveal>
        </div>

        <div className="mt-12 space-y-3.5">
          {faqs.map((f, i) => (
            <Reveal key={f.q} delay={i * 70}>
              <Item faq={f} index={i} open={open === i} onToggle={() => setOpen(open === i ? -1 : i)} />
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mt-10 text-center text-sm text-slate-500">
            还有其他问题？
            <a href="#cta" className="font-semibold text-indigo-600 underline-offset-4 transition-colors hover:text-fuchsia-600 hover:underline">
              联系我们的学习顾问 →
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
