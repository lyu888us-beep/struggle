import { Logo } from "./Navbar";

const columns = [
  {
    title: "产品",
    links: ["核心功能", "词库中心", "好友对战", "学情报告", "更新日志"],
  },
  {
    title: "学习资源",
    links: ["高考 3500 词", "四六级词库", "考研大纲词", "雅思托福", "学习方法博客"],
  },
  {
    title: "支持",
    links: ["帮助中心", "联系我们", "学校合作", "隐私政策", "服务条款"],
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-slate-200/80 bg-white">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[1.2fr_2fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-500">
              Lexio 乐词 — 为学生打造的智能英语单词学习平台。科学记忆，快乐坚持，成绩看得见。
            </p>
            <div className="mt-6 flex gap-3">
              {[
                { label: "微信", d: "M8.5 10.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm7 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM12 3C6.5 3 2 6.6 2 11c0 2.4 1.3 4.5 3.4 6L4.5 20l3.4-1.8c1.3.4 2.7.6 4.1.6 5.5 0 10-3.6 10-8S17.5 3 12 3z" },
                { label: "微博", d: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm0 12a6 6 0 0 1-5-2.7c0-1.6 3.3-2.5 5-2.5s5 .9 5 2.5A6 6 0 0 1 12 19z" },
                { label: "哔哩哔哩", d: "M17.8 4.2l-1.4 1.4H7.6L6.2 4.2 4.8 5.6l1.1 1.1A3 3 0 0 0 3 9.6v6.8a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V9.6a3 3 0 0 0-2.9-3l1.1-1-1.4-1.4zM9 11l6 2.5L9 16v-5z" },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#top"
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-400 transition-all duration-300 hover:-translate-y-0.5 hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-600"
                >
                  <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="currentColor" aria-hidden="true" style={{ height: "1.1rem", width: "1.1rem" }}>
                    <path d={s.d} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {columns.map((c) => (
              <nav key={c.title} aria-label={c.title}>
                <h3 className="text-sm font-bold text-slate-900">{c.title}</h3>
                <ul className="mt-4 space-y-2.5">
                  {c.links.map((l) => (
                    <li key={l}>
                      <a href="#top" className="text-sm text-slate-500 transition-colors duration-200 hover:text-indigo-600">
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-slate-100 pt-8 sm:flex-row">
          <p className="text-xs text-slate-400">© 2026 Lexio 乐词 · 保留所有权利</p>
          <p className="text-xs text-slate-400">用 ❤️ 为每一位奋斗中的学生打造</p>
        </div>
      </div>
    </footer>
  );
}
