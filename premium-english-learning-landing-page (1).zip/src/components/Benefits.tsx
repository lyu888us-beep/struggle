import Reveal from "./Reveal";

const benefits = [
  {
    num: "01",
    title: "每天只需 15 分钟",
    desc: "课间、通勤、睡前碎片时间即可完成当日任务。智能词单把大目标拆成轻松的小步伐，坚持从未如此简单。",
    stat: "15 分钟",
    statLabel: "平均每日学习时长",
  },
  {
    num: "02",
    title: "成绩看得见的提升",
    desc: "连续使用 60 天的学生，词汇测试平均提分 23%。阅读速度更快、完形更准，单词量就是硬实力。",
    stat: "+23%",
    statLabel: "60 天词汇测试平均提升",
  },
  {
    num: "03",
    title: "告别背了就忘",
    desc: "传统背诵 7 天后仅剩 25% 记忆。Lexio 的间隔复习引擎让 30 天记忆保持率高达 94%,背过的词真正属于你。",
    stat: "94%",
    statLabel: "30 天记忆保持率",
  },
];

export default function Benefits() {
  return (
    <section className="relative py-24 sm:py-32" aria-label="学习收益">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <Reveal>
              <span className="inline-block rounded-full bg-fuchsia-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-fuchsia-600 ring-1 ring-fuchsia-100">
                为什么选择 Lexio
              </span>
            </Reveal>
            <Reveal delay={100} as="h2">
              <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
                把时间花在<span className="text-gradient">刀刃上</span>，
                让努力真正转化为分数
              </span>
            </Reveal>
            <Reveal delay={200} as="p">
              <span className="mt-5 block text-base leading-relaxed text-slate-500">
                学习不该是蛮力的重复。Lexio 用数据和算法帮你省下无效刷词的时间，
                专注攻克真正影响成绩的薄弱点。
              </span>
            </Reveal>
            <Reveal delay={300}>
              <a
                href="#pricing"
                className="group mt-8 inline-flex items-center gap-2 rounded-2xl bg-slate-900 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-slate-900/15 transition-all duration-300 hover:-translate-y-0.5 hover:bg-indigo-600 hover:shadow-xl hover:shadow-indigo-500/30"
              >
                查看学生专属优惠
                <svg className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
            </Reveal>
          </div>

          <div className="space-y-6">
            {benefits.map((b, i) => (
              <Reveal key={b.num} delay={i * 120} direction="right">
                <article className="group relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-7 shadow-sm transition-all duration-500 hover:-translate-y-1 hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-500/10 sm:p-9">
                  <span className="absolute -right-3 -top-6 select-none text-[7rem] font-black leading-none text-slate-100 transition-colors duration-500 group-hover:text-indigo-100/80" aria-hidden="true">
                    {b.num}
                  </span>
                  <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
                    <div className="shrink-0 rounded-2xl bg-gradient-to-br from-indigo-50 to-fuchsia-50 px-5 py-4 text-center ring-1 ring-indigo-100/80 transition-transform duration-500 group-hover:scale-105">
                      <p className="text-gradient text-3xl font-extrabold">{b.stat}</p>
                      <p className="mt-1 max-w-[9rem] text-[11px] font-medium leading-snug text-slate-500">{b.statLabel}</p>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900">{b.title}</h3>
                      <p className="mt-2.5 text-sm leading-relaxed text-slate-500">{b.desc}</p>
                    </div>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
