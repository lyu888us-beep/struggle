import Reveal from "./Reveal";

const testimonials = [
  {
    name: "林晓雨",
    role: "高三学生 · 高考英语 142 分",
    avatar: "林",
    gradient: "from-sky-400 to-indigo-500",
    quote: "以前抱着单词书从 abandon 背到放弃。用 Lexio 三个月，3500 考纲词全部过完两轮，阅读几乎没有生词，高考英语冲到了 142。",
  },
  {
    name: "陈子豪",
    role: "大二学生 · 六级 612 分",
    avatar: "陈",
    gradient: "from-emerald-400 to-teal-500",
    quote: "好友对战太上头了，每天跟室友约战两局，不知不觉词汇量测试从 4200 涨到 7800。六级一次过，还拿了 612。",
  },
  {
    name: "王梦琪",
    role: "考研党 · 上岸 985",
    avatar: "王",
    gradient: "from-fuchsia-400 to-pink-500",
    quote: "考研 5500 词配真题例句太香了，背词的同时就在熟悉长难句。错词本自动强化，省了我自己整理的两个小时/周。",
  },
  {
    name: "李想",
    role: "初三学生",
    avatar: "李",
    gradient: "from-amber-400 to-orange-500",
    quote: "我是那种坐不住的人，但是闯关和连续打卡勋章让我停不下来。连续打卡 148 天，中考词汇早就滚瓜烂熟了。",
  },
  {
    name: "赵老师",
    role: "重点中学英语教研组长",
    avatar: "赵",
    gradient: "from-violet-400 to-purple-500",
    quote: "班级版的学情报告帮我精准定位每个学生的薄弱词,备课效率翻倍。整个班的平均词汇量一学期提升了 31%。",
  },
  {
    name: "孙一诺",
    role: "高一学生 · 雅思 7.5",
    avatar: "孙",
    gradient: "from-rose-400 to-red-500",
    quote: "跟读评分功能像请了个私人外教，纠正了我一堆发音坏习惯。雅思听力口语都上了 7.5，面试官夸我发音地道。",
  },
];

function Stars() {
  return (
    <div className="flex text-amber-400" aria-label="五星好评">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path d="M9.05 2.93c.3-.92 1.6-.92 1.9 0l1.3 3.98a1 1 0 0 0 .95.69h4.18c.97 0 1.37 1.24.59 1.81l-3.39 2.46a1 1 0 0 0-.36 1.12l1.3 3.98c.3.92-.76 1.69-1.54 1.12l-3.38-2.46a1 1 0 0 0-1.18 0l-3.38 2.46c-.78.57-1.84-.2-1.54-1.12l1.3-3.98a1 1 0 0 0-.36-1.12L2.03 9.4c-.78-.57-.38-1.8.59-1.8H6.8a1 1 0 0 0 .95-.7l1.3-3.98z" />
        </svg>
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative overflow-hidden bg-gradient-to-b from-white via-indigo-50/40 to-white py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-amber-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-amber-600 ring-1 ring-amber-100">
              学生评价
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
              他们的分数，<span className="text-gradient">就是最好的证明</span>
            </span>
          </Reveal>
          <Reveal delay={200} as="p">
            <span className="mt-5 block text-base text-slate-500 sm:text-lg">
              来自全国各地学生与老师的真实反馈。
            </span>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={(i % 3) * 110}>
              <figure className="group flex h-full flex-col rounded-3xl border border-slate-200/80 bg-white/90 p-7 shadow-sm backdrop-blur transition-all duration-500 hover:-translate-y-1.5 hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-500/10">
                <Stars />
                <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-slate-600">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-slate-100 pt-5">
                  <span className={`grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br ${t.gradient} text-sm font-bold text-white shadow-lg transition-transform duration-300 group-hover:scale-110`} aria-hidden="true">
                    {t.avatar}
                  </span>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
