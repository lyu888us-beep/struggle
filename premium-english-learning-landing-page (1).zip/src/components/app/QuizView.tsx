import { useState, useMemo, useCallback } from "react";
import type { Accent, WordItem } from "../../types/vocab";
import { playSuccessSound, playErrorSound, playComboSound, pronounce } from "../../utils/audio";
import { cn } from "../../utils/cn";

interface QuizViewProps {
  words: WordItem[];
  allWords: WordItem[];
  onWordMistake: (wordId: string) => void;
  onAddScore: (points: number) => void;
  accent: Accent;
}

interface Question {
  target: WordItem;
  options: { wordId: string; text: string; isCorrect: boolean }[];
}

export default function QuizView({
  words,
  allWords,
  onWordMistake,
  onAddScore,
  accent,
}: QuizViewProps) {
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  // Generate question deck
  const questions: Question[] = useMemo(() => {
    const list = words.length >= 4 ? words : allWords;
    return [...list]
      .sort(() => 0.5 - Math.random())
      .slice(0, 10)
      .map((target) => {
      // Pick 3 distractors
      const others = allWords.filter((w) => w.id !== target.id && w.meaning !== target.meaning);
      const shuffledOthers = [...others].sort(() => 0.5 - Math.random()).slice(0, 3);
      const options = [
        { wordId: target.id, text: target.meaning, isCorrect: true },
        ...shuffledOthers.map((o) => ({ wordId: o.id, text: o.meaning, isCorrect: false })),
      ].sort(() => 0.5 - Math.random());

      return { target, options };
    });
  }, [words, allWords]);

  const currentQ = questions[questionIndex % questions.length];

  const handleSelect = useCallback(
    (idx: number) => {
      if (isAnswered || !currentQ) return;
      setSelectedOption(idx);
      setIsAnswered(true);

      const option = currentQ.options[idx];
      if (option.isCorrect) {
        const newCombo = combo + 1;
        setCombo(newCombo);
        setMaxCombo((prev) => Math.max(prev, newCombo));
        setCorrectCount((prev) => prev + 1);

        const gained = 100 + (newCombo - 1) * 20;
        setScore((prev) => prev + gained);
        onAddScore(gained);

        if (newCombo >= 3) {
          playComboSound(newCombo);
        } else {
          playSuccessSound();
        }
      } else {
        setCombo(0);
        playErrorSound();
        onWordMistake(currentQ.target.id);
      }
    },
    [isAnswered, currentQ, combo, onAddScore, onWordMistake]
  );

  const handleNext = useCallback(() => {
    if (questionIndex + 1 >= questions.length) {
      setQuizFinished(true);
    } else {
      setSelectedOption(null);
      setIsAnswered(false);
      setQuestionIndex((prev) => prev + 1);
    }
  }, [questionIndex, questions.length]);

  const handleRestart = useCallback(() => {
    setQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setCombo(0);
    setMaxCombo(0);
    setCorrectCount(0);
    setQuizFinished(false);
  }, []);

  if (quizFinished) {
    const accuracy = Math.round((correctCount / questions.length) * 100);
    return (
      <div className="mx-auto w-full max-w-lg px-4 py-12 text-center">
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-indigo-500 to-fuchsia-600 text-4xl shadow-xl shadow-indigo-500/30 text-white animate-bounce">
          🏆
        </div>
        <h3 className="mt-6 text-2xl font-black text-slate-900">闯关挑战完成！</h3>
        <p className="mt-2 text-sm text-slate-500">
          你的词汇敏感度相当出色，继续保持！
        </p>

        <div className="mt-8 grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-white p-4 border border-slate-100 shadow-sm">
            <p className="text-xs text-slate-400">总得分</p>
            <p className="text-2xl font-extrabold text-indigo-600 mt-1">+{score}</p>
          </div>
          <div className="rounded-2xl bg-white p-4 border border-slate-100 shadow-sm">
            <p className="text-xs text-slate-400">正确率</p>
            <p className="text-2xl font-extrabold text-emerald-600 mt-1">{accuracy}%</p>
          </div>
          <div className="rounded-2xl bg-white p-4 border border-slate-100 shadow-sm">
            <p className="text-xs text-slate-400">最高连击</p>
            <p className="text-2xl font-extrabold text-amber-500 mt-1">{maxCombo} 🔥</p>
          </div>
        </div>

        <button
          onClick={handleRestart}
          className="mt-8 rounded-2xl bg-slate-900 px-8 py-3.5 text-sm font-bold text-white shadow-lg transition-transform hover:-translate-y-0.5 hover:bg-indigo-600"
        >
          再战一轮
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-lg px-2 py-4 sm:py-6">
      {/* Top Status */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
            得分 {score}
          </span>
          {combo >= 2 && (
            <span className="animate-pulse text-xs font-bold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              🔥 {combo} 连击!
            </span>
          )}
        </div>
        <span className="text-xs font-semibold text-slate-400">
          第 {questionIndex + 1} / {questions.length} 题
        </span>
      </div>

      {/* Target Word Card */}
      <div className="rounded-3xl border border-white/80 bg-white p-7 text-center shadow-lg shadow-indigo-900/5">
        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
          {currentQ.target.pos}
        </span>
        <h2 className="mt-4 text-3xl font-extrabold text-slate-900 sm:text-4xl">
          {currentQ.target.word}
        </h2>
        <div className="mt-2 flex items-center justify-center gap-2 text-sm text-slate-400">
          <span>{currentQ.target.phonetic}</span>
          <button
            onClick={() => void pronounce(currentQ.target.word, accent)}
            className="text-indigo-600 hover:text-indigo-800"
            title="发音"
          >
            🔊
          </button>
        </div>
      </div>

      {/* 4 Choices */}
      <div className="mt-5 space-y-3">
        {currentQ.options.map((opt, i) => {
          let btnStyle = "border-slate-200 bg-white hover:border-indigo-300 hover:bg-indigo-50/40 text-slate-800";

          if (isAnswered) {
            if (opt.isCorrect) {
              btnStyle = "border-emerald-400 bg-emerald-50 text-emerald-900 font-bold ring-2 ring-emerald-400/30";
            } else if (selectedOption === i) {
              btnStyle = "border-rose-400 bg-rose-50 text-rose-900 font-bold ring-2 ring-rose-400/30";
            } else {
              btnStyle = "border-slate-100 bg-slate-50 text-slate-400 opacity-60";
            }
          }

          return (
            <button
              key={opt.text}
              disabled={isAnswered}
              onClick={() => handleSelect(i)}
              className={cn(
                "w-full rounded-2xl border p-4 text-left text-sm font-medium transition-all duration-200 flex items-center justify-between",
                btnStyle
              )}
            >
              <span>{opt.text}</span>
              {isAnswered && opt.isCorrect && (
                <span className="text-emerald-600 font-bold">✓</span>
              )}
              {isAnswered && !opt.isCorrect && selectedOption === i && (
                <span className="text-rose-500 font-bold">✕</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Answer Explanation & Next Button */}
      {isAnswered && (
        <div className="mt-5 rounded-2xl bg-indigo-50/70 p-4 border border-indigo-100">
          <p className="text-xs text-indigo-900 leading-relaxed">
            <span className="font-bold">{currentQ.target.example ? "例句：" : "释义："}</span>
            {currentQ.target.example || currentQ.target.meaning}
          </p>
          {currentQ.target.example && (
            <p className="mt-1 text-[11px] text-indigo-700/80">{currentQ.target.exampleTranslation}</p>
          )}
          <button
            onClick={handleNext}
            className="mt-3 w-full rounded-xl bg-indigo-600 py-3 text-sm font-bold text-white shadow-md hover:bg-indigo-700 transition-colors"
          >
            {questionIndex + 1 >= questions.length ? "查看成绩单" : "下一题 →"}
          </button>
        </div>
      )}
    </div>
  );
}
