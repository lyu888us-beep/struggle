import { useState, useEffect, useMemo, useCallback } from "react";
import type { Accent, WordItem } from "../../types/vocab";
import { playSuccessSound, playErrorSound, playComboSound, pronounce } from "../../utils/audio";
import { cn } from "../../utils/cn";

interface BattleViewProps {
  words: WordItem[];
  onAddScore: (points: number) => void;
  accent?: Accent;
}

export default function BattleView({ words, onAddScore, accent = "uk" }: BattleViewProps) {
  const [gameState, setGameState] = useState<"lobby" | "playing" | "finished">("lobby");
  const [timeLeft, setTimeLeft] = useState(30);
  const [myScore, setMyScore] = useState(0);
  const [botScore, setBotScore] = useState(0);
  const [qIndex, setQIndex] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);

  const opponent = {
    name: "学霸小林",
    school: "清华附中 · 高三(1)班",
    avatar: "林",
    avatarBg: "from-sky-400 to-indigo-600",
  };

  // Deck of battle questions
  const battleQuestions = useMemo(() => {
    return words.slice(0, 15).map((target) => {
      const distractors = words.filter((w) => w.id !== target.id);
      const shuffled = [...distractors].sort(() => 0.5 - Math.random()).slice(0, 3);
      const options = [
        { text: target.meaning, correct: true },
        ...shuffled.map((d) => ({ text: d.meaning, correct: false })),
      ].sort(() => 0.5 - Math.random());
      return { target, options };
    });
  }, [words]);

  // Start battle
  const handleStart = () => {
    setMyScore(0);
    setBotScore(0);
    setTimeLeft(30);
    setQIndex(0);
    setSelectedOpt(null);
    setGameState("playing");
  };

  // Timer loop
  useEffect(() => {
    if (gameState !== "playing") return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setGameState("finished");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState]);

  // Simulated bot opponent actions
  useEffect(() => {
    if (gameState !== "playing") return;
    const interval = setInterval(() => {
      // 75% chance bot gets +100
      if (Math.random() > 0.3) {
        setBotScore((prev) => prev + 100);
      }
    }, 2800);

    return () => clearInterval(interval);
  }, [gameState]);

  const currentQ = battleQuestions[qIndex % battleQuestions.length];

  const handleSelectOption = useCallback(
    (index: number) => {
      if (selectedOpt !== null || !currentQ) return;
      setSelectedOpt(index);
      const isCorrect = currentQ.options[index].correct;

      if (isCorrect) {
        setMyScore((s) => s + 120);
        playComboSound(4);
      } else {
        playErrorSound();
      }

      setTimeout(() => {
        setSelectedOpt(null);
        setQIndex((i) => i + 1);
      }, 350);
    },
    [selectedOpt, currentQ]
  );

  // Finishing logic
  useEffect(() => {
    if (gameState === "finished") {
      if (myScore > botScore) {
        playSuccessSound();
        onAddScore(200);
      }
    }
  }, [gameState, myScore, botScore, onAddScore]);

  if (gameState === "lobby") {
    return (
      <div className="mx-auto w-full max-w-md px-4 py-8 text-center">
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-amber-500 to-rose-500 text-4xl shadow-xl shadow-amber-500/30 text-white">
          ⚔️
        </div>
        <h2 className="mt-5 text-2xl font-black text-slate-900">1v1 单词对决竞技场</h2>
        <p className="mt-2 text-sm text-slate-500 leading-relaxed">
          30 秒极速竞速，实时匹配同考级学霸。答对得分、连对加倍，看谁的词汇反应更快！
        </p>

        {/* Matched Opponent Preview */}
        <div className="mt-8 rounded-3xl border border-slate-200/80 bg-white p-5 shadow-sm">
          <p className="text-xs font-semibold text-slate-400">已匹配到对手</p>
          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center gap-3 text-left">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-base font-bold text-white shadow">
                你
              </span>
              <div>
                <p className="font-bold text-slate-900">你 (挑战者)</p>
                <p className="text-xs text-indigo-600">本周胜率 82%</p>
              </div>
            </div>

            <span className="text-sm font-black text-slate-300">VS</span>

            <div className="flex items-center gap-3 text-right">
              <div>
                <p className="font-bold text-slate-900">{opponent.name}</p>
                <p className="text-xs text-slate-400">{opponent.school}</p>
              </div>
              <span className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${opponent.avatarBg} text-base font-bold text-white shadow`}>
                {opponent.avatar}
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={handleStart}
          className="mt-8 w-full rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 py-4 text-base font-bold text-white shadow-xl shadow-indigo-500/25 transition-transform hover:-translate-y-0.5"
        >
          立即开战 (30秒)
        </button>
      </div>
    );
  }

  if (gameState === "finished") {
    const isWin = myScore > botScore;
    const isDraw = myScore === botScore;

    return (
      <div className="mx-auto w-full max-w-md px-4 py-8 text-center">
        <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-500 text-4xl shadow-xl shadow-orange-500/30 text-white animate-bounce">
          {isWin ? "👑" : isDraw ? "🤝" : "💥"}
        </div>
        <h2 className="mt-5 text-3xl font-black text-slate-900">
          {isWin ? "旗开得胜！" : isDraw ? "势均力敌！" : "惜败，再接再厉！"}
        </h2>
        <p className="mt-2 text-sm text-slate-500">
          {isWin ? "你的反应速度击败了对手，获得 +200 经验积分！" : "对手实力强劲，多背两组单词马上反超！"}
        </p>

        {/* Final Scoreboard */}
        <div className="mt-6 rounded-3xl border border-slate-200/80 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-around">
            <div>
              <p className="text-xs text-slate-400">你的最终得分</p>
              <p className="text-3xl font-extrabold text-indigo-600 mt-1">{myScore}</p>
            </div>
            <span className="text-slate-300 font-bold">:</span>
            <div>
              <p className="text-xs text-slate-400">{opponent.name}</p>
              <p className="text-3xl font-extrabold text-slate-600 mt-1">{botScore}</p>
            </div>
          </div>
        </div>

        <div className="mt-8 flex gap-3">
          <button
            onClick={handleStart}
            className="flex-1 rounded-2xl bg-slate-900 py-3.5 text-sm font-bold text-white shadow-md hover:bg-indigo-600 transition-colors"
          >
            再来一局
          </button>
          <button
            onClick={() => setGameState("lobby")}
            className="rounded-2xl border border-slate-200 bg-white px-5 py-3.5 text-sm font-bold text-slate-600 hover:bg-slate-50"
          >
            返回大厅
          </button>
        </div>
      </div>
    );
  }

  const totalScore = Math.max(myScore + botScore, 1);
  const myPercent = Math.round((myScore / totalScore) * 100);

  return (
    <div className="mx-auto w-full max-w-lg px-2 py-4">
      {/* Top Head-to-Head HUD */}
      <div className="rounded-3xl border border-white/80 bg-white p-4 shadow-md">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-indigo-600 text-xs font-bold text-white">
              我
            </span>
            <div>
              <p className="text-xs font-semibold text-slate-500">我的得分</p>
              <p className="text-lg font-black text-indigo-600">{myScore}</p>
            </div>
          </div>

          {/* Countdown timer */}
          <div className="rounded-full bg-rose-50 px-3.5 py-1 text-center border border-rose-200">
            <span className="text-xs font-black text-rose-600">⏱️ {timeLeft}s</span>
          </div>

          <div className="flex items-center gap-2 text-right">
            <div>
              <p className="text-xs font-semibold text-slate-500">{opponent.name}</p>
              <p className="text-lg font-black text-slate-700">{botScore}</p>
            </div>
            <span className={`grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br ${opponent.avatarBg} text-xs font-bold text-white`}>
              {opponent.avatar}
            </span>
          </div>
        </div>

        {/* Tug of war bar */}
        <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200 flex">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 transition-all duration-300"
            style={{ width: `${myPercent}%` }}
          />
          <div
            className="h-full bg-gradient-to-r from-rose-400 to-orange-400 transition-all duration-300"
            style={{ width: `${100 - myPercent}%` }}
          />
        </div>
      </div>

      {/* Target Word */}
      <div className="mt-5 rounded-3xl border border-white/80 bg-white p-6 text-center shadow-lg shadow-indigo-900/5">
        <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
          快速选出正确释义
        </span>
        <div className="mt-3 flex items-center justify-center gap-2">
          <h3 className="text-3xl font-black text-slate-900">{currentQ.target.word}</h3>
          <button
            onClick={() => void pronounce(currentQ.target.word, accent)}
            className="rounded-lg bg-indigo-50 px-2 py-1 text-sm text-indigo-600 hover:bg-indigo-100"
            aria-label={`播放${accent === "uk" ? "英式" : "美式"}发音`}
          >
            🔊
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          {currentQ.target.phonetic} · {accent === "uk" ? "英式发音" : "美式发音"}
        </p>
      </div>

      {/* Options */}
      <div className="mt-4 space-y-2.5">
        {currentQ.options.map((opt, i) => {
          let style = "bg-white border-slate-200 text-slate-800 hover:border-indigo-300 hover:bg-indigo-50/50";
          if (selectedOpt !== null) {
            if (opt.correct) {
              style = "bg-emerald-500 text-white border-emerald-500 font-bold";
            } else if (selectedOpt === i) {
              style = "bg-rose-500 text-white border-rose-500 font-bold";
            }
          }

          return (
            <button
              key={opt.text}
              disabled={selectedOpt !== null}
              onClick={() => handleSelectOption(i)}
              className={cn(
                "w-full rounded-2xl border p-4 text-left text-sm font-semibold transition-all duration-150",
                style
              )}
            >
              {opt.text}
            </button>
          );
        })}
      </div>
    </div>
  );
}
