import { useState, useEffect, useCallback } from "react";
import type { Accent, WordItem } from "../../types/vocab";
import {
  playFlipSound,
  playSuccessSound,
  playErrorSound,
  pronounce,
  pronounceSentence,
} from "../../utils/audio";
import { cn } from "../../utils/cn";

interface LearnViewProps {
  words: WordItem[];
  bookTitle: string;
  onWordResult: (wordId: string, result: "forgot" | "vague" | "mastered") => void;
  todayCount: number;
  todayGoal: number;
  accent: Accent;
  onAccentChange: (accent: Accent) => void;
}

function SpeakerIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77zm-4 4.77H6c-.55 0-1 .45-1 1v6c0 .55.45 1 1 1h4l5 5V3l-5 5z" />
    </svg>
  );
}

export default function LearnView({
  words,
  bookTitle,
  onWordResult,
  todayCount,
  todayGoal,
  accent,
  onAccentChange,
}: LearnViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [playing, setPlaying] = useState<string | null>(null);
  const [engine, setEngine] = useState<"recorded" | "synth" | null>(null);
  const [completed, setCompleted] = useState(false);

  const currentWord = words[currentIndex % Math.max(words.length, 1)] ?? words[0];

  const playWord = useCallback(
    async (word: string, target: Accent, key: string) => {
      setPlaying(key);
      setEngine(null);
      onAccentChange(target);
      const used = await pronounce(word, target);
      setEngine(used);
      setPlaying(null);
    },
    [onAccentChange]
  );

  const playSentence = useCallback(async () => {
    if (!currentWord?.example) return;
    setPlaying("sentence");
    await pronounceSentence(currentWord.example, accent);
    setPlaying(null);
  }, [currentWord, accent]);

  const handleFlip = useCallback(() => {
    playFlipSound();
    setFlipped((prev) => !prev);
  }, []);

  const handleGrade = useCallback(
    (grade: "forgot" | "vague" | "mastered") => {
      if (!currentWord) return;
      if (grade === "mastered") playSuccessSound();
      else if (grade === "forgot") playErrorSound();
      else playFlipSound();

      onWordResult(currentWord.id, grade);
      setFlipped(false);

      if (currentIndex + 1 >= words.length) setCompleted(true);
      else setTimeout(() => setCurrentIndex((prev) => prev + 1), 150);
    },
    [currentWord, currentIndex, words.length, onWordResult]
  );

  useEffect(() => {
    setCurrentIndex(0);
    setFlipped(false);
    setCompleted(false);
  }, [bookTitle]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (completed) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        handleFlip();
      } else if (e.key === "1") handleGrade("forgot");
      else if (e.key === "2") handleGrade("vague");
      else if (e.key === "3") handleGrade("mastered");
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [completed, handleFlip, handleGrade]);

  if (!currentWord) {
    return <p className="py-16 text-center text-sm text-slate-500">该词库内容正在更新中。</p>;
  }

  if (completed) {
    return (
      <div className="flex flex-col items-center justify-center px-4 py-12 text-center">
        <div className="grid h-20 w-20 animate-bounce place-items-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-500 text-4xl text-white shadow-xl shadow-orange-500/25">
          🎉
        </div>
        <h3 className="mt-6 text-2xl font-black text-slate-900">本组单词学习完成！</h3>
        <p className="mt-2 max-w-sm text-sm text-slate-500">
          今天已累计学习 {todayCount} 词。复习计划已按 FSRS 记忆曲线自动排期，明天见！
        </p>
        <button
          onClick={() => {
            setCurrentIndex(0);
            setCompleted(false);
            setFlipped(false);
          }}
          className="mt-8 rounded-2xl bg-slate-900 px-6 py-3 text-sm font-bold text-white shadow-lg transition-all hover:-translate-y-0.5 hover:bg-indigo-600"
        >
          再学一组
        </button>
      </div>
    );
  }

  const progressPercent = Math.min(Math.round(((currentIndex + 1) / words.length) * 100), 100);

  return (
    <div className="mx-auto w-full max-w-xl px-2 py-4 sm:py-6">
      {/* Progress + accent engine */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-xs font-semibold text-slate-500">
        <div className="flex items-center gap-2">
          <span className="rounded-lg bg-indigo-50 px-2.5 py-1 text-indigo-700">{bookTitle}</span>
          <span>
            今日 {todayCount}/{todayGoal} 词
          </span>
        </div>
        <div className="flex items-center gap-1 rounded-full bg-slate-100 p-0.5" role="group" aria-label="发音偏好">
          {(["uk", "us"] as Accent[]).map((a) => (
            <button
              key={a}
              onClick={() => onAccentChange(a)}
              className={cn(
                "rounded-full px-2.5 py-1 text-[11px] font-bold transition-all",
                accent === a ? "bg-white text-indigo-700 shadow-sm" : "text-slate-500"
              )}
              aria-pressed={accent === a}
            >
              {a === "uk" ? "🇬🇧 英音" : "🇺🇸 美音"}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
        <div
          className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-600 transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Flashcard */}
      <div className="relative w-full" style={{ perspective: "1400px" }}>
        <div
          onClick={handleFlip}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleFlip();
          }}
          aria-label={flipped ? "查看单词正面" : "翻转卡片查看释义"}
          className="relative min-h-[410px] w-full cursor-pointer select-none rounded-[2rem] transition-transform duration-700 [transform-style:preserve-3d] focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          style={{ transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)" }}
        >
          {/* FRONT */}
          <div
            className={cn(
              "absolute inset-0 flex flex-col justify-between rounded-[2rem] border border-white/80 bg-white/95 p-7 shadow-xl shadow-indigo-900/5 backdrop-blur-xl [backface-visibility:hidden] sm:p-9",
              flipped && "pointer-events-none"
            )}
          >
            <div className="flex items-center justify-between">
              <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-600">{currentWord.pos}</span>
              <div className="flex gap-0.5 text-xs text-amber-400" aria-label={`考频 ${currentWord.frequency} 星`}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className={i < currentWord.frequency ? "" : "text-slate-200"}>★</span>
                ))}
              </div>
            </div>

            <div className="my-auto py-4 text-center">
              <h2 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">{currentWord.word}</h2>

              <div className="mt-5 flex flex-col items-center justify-center gap-2 sm:flex-row">
                {(
                  [
                    { a: "uk" as Accent, flag: "🇬🇧", label: "英式", ipa: currentWord.phonetic },
                    { a: "us" as Accent, flag: "🇺🇸", label: "美式", ipa: currentWord.usPhonetic },
                  ]
                ).map((item) => (
                  <button
                    key={item.a}
                    onClick={(e) => {
                      e.stopPropagation();
                      void playWord(currentWord.word, item.a, item.a);
                    }}
                    className={cn(
                      "flex w-full items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold transition-all sm:w-auto",
                      accent === item.a
                        ? "border-indigo-200 bg-indigo-50/80 text-indigo-700"
                        : "border-slate-200 bg-white text-slate-600 hover:border-indigo-200 hover:bg-indigo-50/50"
                    )}
                    aria-label={`播放${item.label}发音`}
                  >
                    <span>{item.flag}</span>
                    <span className="text-slate-400">{item.ipa}</span>
                    <SpeakerIcon className={cn("h-3.5 w-3.5", playing === item.a && "animate-pulse")} />
                  </button>
                ))}
              </div>

              <p className={`mt-2 text-[10px] font-medium ${engine ? "text-emerald-600" : "text-slate-400"}`}>
                {engine
                  ? engine === "recorded"
                    ? "✓ 英式/美式真人录音已播放"
                    : "✓ 已使用智能语音合成（弱网兜底）"
                  : "英式真人录音优先 · 弱网自动切换智能语音"}
              </p>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-xs font-medium text-slate-400">
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
                <path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              点击卡片翻面 · 快捷键 空格
            </div>
          </div>

          {/* BACK */}
          <div
            className={cn(
              "absolute inset-0 flex flex-col overflow-hidden rounded-[2rem] border border-indigo-100 bg-gradient-to-br from-white via-indigo-50/40 to-violet-50/50 p-6 shadow-xl shadow-indigo-900/10 [backface-visibility:hidden] sm:p-8",
              !flipped && "pointer-events-none"
            )}
            style={{ transform: "rotateY(180deg)" }}
          >
            <div className="flex items-center justify-between border-b border-indigo-100/70 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-slate-900">{currentWord.word}</span>
                <span className="text-[11px] text-slate-400">{currentWord.phonetic}</span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  void playWord(currentWord.word, accent, "back-word");
                }}
                className="grid h-7 w-7 place-items-center rounded-full bg-indigo-100 text-indigo-700 hover:bg-indigo-200"
                aria-label="朗读单词"
              >
                <SpeakerIcon className={cn("h-3.5 w-3.5", playing === "back-word" && "animate-pulse")} />
              </button>
            </div>

            <div className="mt-3 flex-1 space-y-3 overflow-y-auto pr-0.5">
              <p className="text-lg font-extrabold text-indigo-900">{currentWord.meaning}</p>

              {currentWord.mnemonic && (
                <div className="rounded-xl border border-amber-200/60 bg-amber-50/90 p-3 text-xs leading-relaxed text-amber-900">
                  <span className="font-bold text-amber-800">💡 词根助记：</span>
                  {currentWord.mnemonic}
                </div>
              )}

              {currentWord.example ? (
              <div className="rounded-xl border border-indigo-100 bg-white/85 p-3.5 text-xs">
                <div className="flex items-start justify-between gap-2">
                  <p className="font-semibold leading-relaxed text-slate-800">“{currentWord.example}”</p>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      void playSentence();
                    }}
                    className="shrink-0 rounded-lg p-1 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600"
                    aria-label="朗读例句"
                  >
                    <SpeakerIcon className={cn("h-3.5 w-3.5", playing === "sentence" && "animate-pulse")} />
                  </button>
                </div>
                <p className="mt-1 text-slate-500">{currentWord.exampleTranslation}</p>
              </div>
              ) : (
                <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50/70 p-3.5 text-center text-[11px] text-slate-400">
                  该词为大纲词条，例句与助记在「精讲词条」中提供
                </div>
              )}

              {currentWord.examSource && (
                <p className="text-[11px] font-medium text-slate-500">
                  📍 真题出处：<span className="text-indigo-600">{currentWord.examSource}</span>
                </p>
              )}
            </div>

            <p className="pt-2 text-center text-[11px] text-slate-400">评估掌握度，系统自动安排下次复习</p>
          </div>
        </div>
      </div>

      {/* Rating */}
      <div className="mt-5 grid grid-cols-3 gap-3">
        <button
          onClick={() => handleGrade("forgot")}
          className="group flex flex-col items-center justify-center rounded-2xl border border-rose-200 bg-white px-2 py-3.5 transition-all hover:-translate-y-0.5 hover:border-rose-300 hover:bg-rose-50 hover:shadow-md"
        >
          <span className="text-base font-bold text-rose-600">🔴 又忘了</span>
          <span className="mt-0.5 text-[10px] text-slate-400">按 1 键</span>
        </button>
        <button
          onClick={() => handleGrade("vague")}
          className="group flex flex-col items-center justify-center rounded-2xl border border-amber-200 bg-white px-2 py-3.5 transition-all hover:-translate-y-0.5 hover:border-amber-300 hover:bg-amber-50 hover:shadow-md"
        >
          <span className="text-base font-bold text-amber-600">🟡 模糊</span>
          <span className="mt-0.5 text-[10px] text-slate-400">按 2 键</span>
        </button>
        <button
          onClick={() => handleGrade("mastered")}
          className="flex flex-col items-center justify-center rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 px-2 py-3.5 text-white shadow-md shadow-emerald-500/20 transition-all hover:-translate-y-0.5 hover:shadow-lg"
        >
          <span className="text-base font-bold">🟢 记住了</span>
          <span className="mt-0.5 text-[10px] text-emerald-100">按 3 键</span>
        </button>
      </div>

      {/* 考点拓展 */}
      {(currentWord.synonyms?.length || currentWord.antonyms?.length || currentWord.collocations?.length || currentWord.wordFamily?.length) ? (
      <div className="mt-5 rounded-3xl border border-slate-200/80 bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">📚 考点拓展</h3>
          <span className="text-[10px] font-semibold text-indigo-600">近义 · 搭配 · 词族</span>
        </div>

        <div className="mt-3 space-y-3 text-xs">
          <div className="flex flex-wrap gap-1.5">
            {currentWord.synonyms?.map((s) => (
              <span key={s} className="rounded-lg bg-emerald-50 px-2 py-1 font-medium text-emerald-700">
                近 {s}
              </span>
            ))}
            {currentWord.antonyms?.map((s) => (
              <span key={s} className="rounded-lg bg-rose-50 px-2 py-1 font-medium text-rose-700">
                反 {s}
              </span>
            ))}
          </div>

          {currentWord.collocations && currentWord.collocations.length > 0 && (
            <div>
              <p className="mb-1 text-[11px] font-bold text-slate-500">高频搭配</p>
              <ul className="space-y-1">
                {currentWord.collocations.map((c) => (
                  <li key={c.phrase} className="flex items-start justify-between gap-2 rounded-lg bg-slate-50 px-2.5 py-1.5">
                    <span className="font-semibold text-slate-800">{c.phrase}</span>
                    <span className="shrink-0 text-slate-500">{c.zh}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {currentWord.wordFamily && currentWord.wordFamily.length > 0 && (
            <div>
              <p className="mb-1 text-[11px] font-bold text-slate-500">同根词族</p>
              <div className="flex flex-wrap gap-1.5">
                {currentWord.wordFamily.map((w) => (
                  <span key={w.word} className="rounded-lg border border-slate-200 px-2 py-1 text-slate-600">
                    <b className="text-slate-900">{w.word}</b> <span className="text-slate-400">{w.pos}</span> {w.zh}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      ) : null}

      {/* Word list quick jump */}
      <div className="mt-4 rounded-3xl border border-slate-200/80 bg-white p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-500">本组词单 · {words.length} 词</h3>
          <span className="text-[10px] text-slate-400">点击跳转</span>
        </div>
        <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1">
          {words.map((w, i) => (
            <button
              key={w.id}
              onClick={() => {
                setCurrentIndex(i);
                setFlipped(false);
              }}
              className={cn(
                "shrink-0 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold transition-colors",
                i === currentIndex ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              {i + 1}. {w.word}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
