import { VOCAB_BOOKS } from "../../data/vocabData";
import { WordCategory } from "../../types/vocab";
import { cn } from "../../utils/cn";

interface BookSelectorModalProps {
  isOpen: boolean;
  currentBook: WordCategory;
  onSelect: (bookId: WordCategory) => void;
  onClose: () => void;
}

export default function BookSelectorModal({
  isOpen,
  currentBook,
  onSelect,
  onClose,
}: BookSelectorModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-lg rounded-3xl border border-white/60 bg-white p-6 shadow-2xl transition-all sm:p-7">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-xl font-bold text-slate-900">选择目标词库</h3>
            <p className="text-xs text-slate-500 mt-0.5">随时切换词书，学习进度独立保存</p>
          </div>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            aria-label="关闭"
          >
            ✕
          </button>
        </div>

        <div className="mt-4 space-y-3 max-h-[65vh] overflow-y-auto pr-1">
          {VOCAB_BOOKS.map((book) => {
            const isSelected = book.id === currentBook;
            return (
              <button
                key={book.id}
                onClick={() => {
                  onSelect(book.id);
                  onClose();
                }}
                className={cn(
                  "flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition-all duration-200",
                  isSelected
                    ? "border-indigo-500 bg-indigo-50/70 shadow-sm ring-2 ring-indigo-500/20"
                    : "border-slate-200 bg-white hover:border-indigo-200 hover:bg-slate-50/70"
                )}
              >
                <div
                  className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br ${book.color} text-2xl shadow-md text-white`}
                >
                  {book.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 truncate">{book.title}</span>
                    <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] font-semibold text-indigo-700">
                      {book.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 truncate mt-1">{book.subtitle}</p>
                  <p className="text-[11px] font-medium text-slate-400 mt-1">共 {book.totalWords} 词</p>
                </div>
                {isSelected && (
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                    ✓
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
