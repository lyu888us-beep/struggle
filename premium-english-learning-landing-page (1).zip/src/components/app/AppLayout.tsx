import { useState, useMemo, useCallback } from "react";
import { VOCAB_BOOKS } from "../../data/vocabData";
import { getBookWords } from "../../data/fullIndex";
import { loadUserProgress, saveUserProgress } from "../../utils/storage";
import { getGlobalAccent, setGlobalAccent } from "../../utils/audio";
import { Accent, WordCategory } from "../../types/vocab";
import BookSelectorModal from "./BookSelectorModal";
import LearnView from "./LearnView";
import QuizView from "./QuizView";
import BattleView from "./BattleView";
import WordbookView from "./WordbookView";
import StatsView from "./StatsView";
import { cn } from "../../utils/cn";

interface AppLayoutProps {
  onBackToLanding: () => void;
  initialBook?: WordCategory | null;
}

type TabType = "learn" | "quiz" | "battle" | "wordbook" | "stats";

export default function AppLayout({ onBackToLanding, initialBook }: AppLayoutProps) {
  const [progress, setProgress] = useState(() => {
    const stored = loadUserProgress();
    return initialBook ? { ...stored, selectedBook: initialBook } : stored;
  });
  const [activeTab, setActiveTab] = useState<TabType>("learn");
  const [isBookModalOpen, setIsBookModalOpen] = useState(false);
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [accent, setAccent] = useState<Accent>(getGlobalAccent);

  const handleAccentChange = useCallback((next: Accent) => {
    setAccent(next);
    setGlobalAccent(next);
  }, []);

  // Filter words by selected book category
  const currentBookInfo = useMemo(() => {
    return VOCAB_BOOKS.find((b) => b.id === progress.selectedBook) || VOCAB_BOOKS[1];
  }, [progress.selectedBook]);

  const currentBookWords = useMemo(
    () => getBookWords(progress.selectedBook),
    [progress.selectedBook]
  );

  const allBooksWords = useMemo(
    () => (["gaokao", "cet4", "cet6", "kaoyan", "ielts"] as WordCategory[]).flatMap((b) => getBookWords(b)),
    []
  );

  // 每日学习会话：20 词一组，随学习进度向前推进
  const sessionWords = useMemo(() => {
    const SESSION = 20;
    const total = currentBookWords.length;
    if (total <= SESSION) return currentBookWords;
    const start = (progress.todayLearnedCount * SESSION) % total;
    return Array.from({ length: SESSION }, (_, i) => currentBookWords[(start + i) % total]);
  }, [currentBookWords, progress.todayLearnedCount]);

  // Actions
  const handleSelectBook = useCallback((bookId: WordCategory) => {
    setProgress((prev) => {
      const next = { ...prev, selectedBook: bookId };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const handleWordResult = useCallback((wordId: string, result: "forgot" | "vague" | "mastered") => {
    setProgress((prev) => {
      const learnedSet = new Set(prev.learnedWordIds);
      learnedSet.add(wordId);

      const mistakeSet = new Set(prev.mistakeWordIds);
      const masteredSet = new Set(prev.masteredWordIds);

      if (result === "forgot") {
        mistakeSet.add(wordId);
        masteredSet.delete(wordId);
      } else if (result === "mastered") {
        masteredSet.add(wordId);
        mistakeSet.delete(wordId);
      }

      const next = {
        ...prev,
        todayLearnedCount: prev.todayLearnedCount + 1,
        learnedWordIds: Array.from(learnedSet),
        mistakeWordIds: Array.from(mistakeSet),
        masteredWordIds: Array.from(masteredSet),
        totalScore: prev.totalScore + (result === "mastered" ? 15 : 5),
      };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const handleWordMistake = useCallback((wordId: string) => {
    setProgress((prev) => {
      const mistakeSet = new Set(prev.mistakeWordIds);
      mistakeSet.add(wordId);
      const next = {
        ...prev,
        mistakeWordIds: Array.from(mistakeSet),
      };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const handleAddScore = useCallback((pts: number) => {
    setProgress((prev) => {
      const next = { ...prev, totalScore: prev.totalScore + pts };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const handleToggleMastered = useCallback((id: string) => {
    setProgress((prev) => {
      const set = new Set(prev.masteredWordIds);
      if (set.has(id)) {
        set.delete(id);
      } else {
        set.add(id);
      }
      const next = { ...prev, masteredWordIds: Array.from(set) };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const handleToggleMistake = useCallback((id: string) => {
    setProgress((prev) => {
      const set = new Set(prev.mistakeWordIds);
      if (set.has(id)) {
        set.delete(id);
      } else {
        set.add(id);
      }
      const next = { ...prev, mistakeWordIds: Array.from(set) };
      saveUserProgress(next);
      return next;
    });
  }, []);

  const navItems = [
    { id: "learn", label: "背单词", icon: "🎴" },
    { id: "quiz", label: "快速测验", icon: "🎯" },
    { id: "battle", label: "单词对决", icon: "⚔️" },
    { id: "wordbook", label: "词库", icon: "📖" },
    { id: "stats", label: "学情报告", icon: "📊" },
  ] as const;

  const renderActiveView = () => (
    <>
      {activeTab === "learn" && (
        <LearnView
          words={sessionWords}
          bookTitle={currentBookInfo.title}
          onWordResult={handleWordResult}
          todayCount={progress.todayLearnedCount}
          todayGoal={progress.todayGoal}
          accent={accent}
          onAccentChange={handleAccentChange}
        />
      )}
      {activeTab === "quiz" && (
        <QuizView
          words={currentBookWords}
          allWords={allBooksWords}
          onWordMistake={handleWordMistake}
          onAddScore={handleAddScore}
          accent={accent}
        />
      )}
      {activeTab === "battle" && (
        <BattleView words={sessionWords} onAddScore={handleAddScore} accent={accent} />
      )}
      {activeTab === "wordbook" && (
        <WordbookView
          words={currentBookWords}
          bookTitle={currentBookInfo.title}
          bookId={currentBookInfo.id}
          allWords={allBooksWords}
          masteredIds={progress.masteredWordIds}
          mistakeIds={progress.mistakeWordIds}
          onToggleMastered={handleToggleMastered}
          onToggleMistake={handleToggleMistake}
          accent={accent}
          onAccentChange={handleAccentChange}
        />
      )}
      {activeTab === "stats" && (
        <StatsView progress={progress} totalWordsInBook={currentBookWords.length} />
      )}
    </>
  );

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-800 flex flex-col font-sans">
      {/* Top Universal App Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-3 py-2.5 sm:px-6">
          {/* Brand + Current Book trigger */}
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToLanding}
              className="flex items-center gap-2 group text-left"
              title="返回官网"
            >
              <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 text-white shadow-md transition-transform group-hover:scale-105">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.2}>
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                </svg>
              </span>
              <span className="hidden sm:inline font-bold text-slate-900 tracking-tight text-sm">
                Lexio <span className="text-gradient">乐词 App</span>
              </span>
            </button>

            {/* Current Book Pill */}
            <button
              onClick={() => setIsBookModalOpen(true)}
              className="flex items-center gap-1.5 rounded-full border border-indigo-200 bg-indigo-50/80 px-3 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition-colors shadow-2xs"
            >
              <span>{currentBookInfo.icon}</span>
              <span className="max-w-[88px] sm:max-w-none truncate">{currentBookInfo.title}</span>
              <span className="hidden text-[10px] text-indigo-500 sm:inline">▼ 切换</span>
            </button>
          </div>

          {/* Right utility buttons */}
          <div className="flex items-center gap-2">
            {/* Accent switch */}
            <div
              className="flex items-center gap-0.5 rounded-full border border-slate-200 bg-white p-0.5"
              role="group"
              aria-label="发音偏好设置"
            >
              {(["uk", "us"] as Accent[]).map((a) => (
                <button
                  key={a}
                  onClick={() => handleAccentChange(a)}
                  aria-pressed={accent === a}
                  title={a === "uk" ? "英式发音（默认）" : "美式发音"}
                  className={cn(
                    "rounded-full px-2 py-1 text-[10px] font-bold transition-all",
                    accent === a ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500 hover:bg-slate-50"
                  )}
                >
                  <span className="hidden sm:inline">{a === "uk" ? "🇬🇧 英音" : "🇺🇸 美音"}</span>
                  <span className="sm:hidden">{a === "uk" ? "🇬🇧" : "🇺🇸"}</span>
                </button>
              ))}
            </div>

            {/* Streak Badge */}
            <div className="hidden sm:flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-700 border border-amber-200/60">
              <span>🔥</span>
              <span>{progress.streakDays} 天打卡</span>
            </div>

            {/* Desktop / Mobile Frame View Switcher */}
            <button
              onClick={() => setIsMobileFrame((v) => !v)}
              className="hidden md:flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors"
              title={isMobileFrame ? "切换至全屏网页模式" : "切换至手机 App 模式"}
            >
              <span>{isMobileFrame ? "💻 网页全屏" : "📱 手机框视图"}</span>
            </button>

            {/* Back to landing */}
            <button
              onClick={onBackToLanding}
              className="rounded-xl bg-slate-900 px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-indigo-600 transition-colors"
            >
              <span className="hidden sm:inline">🌐 返回官网</span>
              <span className="sm:hidden" aria-hidden="true">🌐</span>
              <span className="sr-only">返回官网</span>
            </button>
          </div>
        </div>

        {/* Desktop Primary Nav Tabs */}
        {!isMobileFrame && (
          <div className="hidden border-t border-slate-100 bg-white md:block">
            <nav className="mx-auto flex max-w-6xl items-center gap-1 overflow-x-auto px-4 py-1.5 sm:px-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as TabType)}
                  className={cn(
                    "flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition-all",
                    activeTab === item.id
                      ? "bg-indigo-50 text-indigo-700 shadow-2xs"
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"
                  )}
                >
                  <span>{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="flex-1 flex flex-col justify-center items-center p-2 sm:p-6 pb-20 md:pb-6">
        {isMobileFrame ? (
          /* Phone Shell Simulator */
          <div className="relative my-4 w-full max-w-[400px] rounded-[3rem] border-8 border-slate-800 bg-white shadow-2xl overflow-hidden min-h-[720px] flex flex-col">
            {/* Phone Notch/Island */}
            <div className="bg-slate-800 py-1.5 flex justify-center items-center">
              <div className="h-4 w-28 bg-slate-900 rounded-full flex items-center justify-end px-3">
                <span className="h-2 w-2 rounded-full bg-slate-700" />
              </div>
            </div>

            {/* Phone Content Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-slate-50">{renderActiveView()}</div>

            {/* Phone Bottom Tab Bar */}
            <div className="border-t border-slate-200 bg-white grid grid-cols-5 py-2 px-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as TabType)}
                  className={cn(
                    "flex flex-col items-center justify-center py-1 text-[10px] font-semibold transition-colors",
                    activeTab === item.id ? "text-indigo-600 font-bold" : "text-slate-400"
                  )}
                >
                  <span className="text-base">{item.icon}</span>
                  <span className="mt-0.5">{item.label}</span>
                </button>
              ))}
            </div>

            {/* iPhone Home Indicator */}
            <div className="bg-white py-1 flex justify-center">
              <div className="h-1 w-28 bg-slate-300 rounded-full" />
            </div>
          </div>
        ) : (
          /* Responsive Desktop/Tablet Web Mode */
          <div className="w-full max-w-4xl mx-auto flex-1">{renderActiveView()}</div>
        )}
      </main>

      {/* Mobile Screen Bottom Floating Navigation Dock (when not in mobile shell mode and on small screens) */}
      {!isMobileFrame && (
        <div className="fixed bottom-0 inset-x-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur-md md:hidden grid grid-cols-5 py-2 px-1 shadow-lg">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as TabType)}
              className={cn(
                "flex flex-col items-center justify-center py-1 text-[10px] transition-colors",
                activeTab === item.id ? "text-indigo-600 font-bold" : "text-slate-400 font-medium"
              )}
            >
              <span className="text-base">{item.icon}</span>
              <span className="mt-0.5">{item.label}</span>
            </button>
          ))}
        </div>
      )}

      {/* Book Selector Modal */}
      <BookSelectorModal
        isOpen={isBookModalOpen}
        currentBook={progress.selectedBook}
        onSelect={handleSelectBook}
        onClose={() => setIsBookModalOpen(false)}
      />
    </div>
  );
}
