import { useEffect, useMemo, useState } from "react";
import type { Accent, WordItem } from "../../types/vocab";
import { DAILY_SENTENCES, ROOT_LESSONS } from "../../data/vocabData";
import { pronounce, pronounceSentence } from "../../utils/audio";
import { cn } from "../../utils/cn";

interface WordbookViewProps {
  words: WordItem[];
  allWords: WordItem[];
  bookTitle: string;
  bookId: string;
  masteredIds: string[];
  mistakeIds: string[];
  onToggleMastered: (id: string) => void;
  onToggleMistake: (id: string) => void;
  accent: Accent;
  onAccentChange: (accent: Accent) => void;
}

function WordDetailModal({
  item,
  accent,
  onAccentChange,
  onClose,
  isMastered,
  isMistake,
  onToggleMastered,
  onToggleMistake,
}: {
  item: WordItem;
  accent: Accent;
  onAccentChange: (a: Accent) => void;
  onClose: () => void;
  isMastered: boolean;
  isMistake: boolean;
  onToggleMastered: (id: string) => void;
  onToggleMistake: (id: string) => void;
}) {
  const [playing, setPlaying] = useState<string | null>(null);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose]);

  const play = async (target: Accent) => {
    setPlaying(target);
    onAccentChange(target);
    await pronounce(item.word, target);
    setPlaying(null);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={`${item.word} 词条详情`}
        className="relative z-10 max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-white/60 bg-white p-6 shadow-2xl sm:rounded-3xl"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-baseline gap-2">
              <h3 className="text-2xl font-extrabold text-slate-900">{item.word}</h3>
              <span className="rounded bg-indigo-50 px-1.5 py-0.5 text-[10px] font-bold text-indigo-600">{item.pos}</span>
            </div>
            <p className="mt-1 text-sm font-semibold text-indigo-700">{item.meaning}</p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full text-slate-400 hover:bg-slate-100" aria-label="关闭详情">
            ✕
          </button>
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {(
            [
              { a: "uk" as Accent, flag: "🇬🇧", label: "英式发音", ipa: item.phonetic },
              { a: "us" as Accent, flag: "🇺🇸", label: "美式发音", ipa: item.usPhonetic },
            ]
          ).map((v) => (
            <button
              key={v.a}
              onClick={() => void play(v.a)}
              className={cn(
                "flex items-center justify-between gap-2 rounded-2xl border p-3 text-left transition-all",
                accent === v.a
                  ? "border-indigo-300 bg-indigo-50/70"
                  : "border-slate-200 bg-white hover:border-indigo-200 hover:bg-indigo-50/40"
              )}
            >
              <div>
                <p className="text-[11px] font-bold text-slate-500">{v.flag} {v.label}</p>
                <p className="mt-0.5 text-sm font-semibold text-slate-800">{v.ipa}</p>
              </div>
              <span className={cn("text-lg", playing === v.a && "animate-pulse")}>🔊</span>
            </button>
          ))}
        </div>

        {item.mnemonic && (
          <div className="mt-4 rounded-2xl border border-amber-200/60 bg-amber-50/80 p-3.5 text-xs leading-relaxed text-amber-900">
            <b>💡 词根助记：</b>{item.mnemonic}
          </div>
        )}

        <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm font-semibold leading-relaxed text-slate-800">
              {item.example ? `“${item.example}”` : "该词条为大纲词汇，精讲例句见精选词条"}
            </p>
            <button
              onClick={() => void pronounceSentence(item.example, accent)}
              className="shrink-0 rounded-lg bg-white p-1.5 text-slate-500 ring-1 ring-slate-200 hover:text-indigo-600"
              aria-label="朗读例句"
            >
              🔊
            </button>
          </div>
          <p className="mt-1.5 text-xs text-slate-500">{item.exampleTranslation || item.meaning}</p>
          {item.examSource && <p className="mt-2 text-[11px] text-indigo-600">📍 {item.examSource}</p>}
        </div>

        {(item.synonyms?.length || item.antonyms?.length) && (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {item.synonyms?.map((s) => (
              <span key={s} className="rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-medium text-emerald-700">近 {s}</span>
            ))}
            {item.antonyms?.map((s) => (
              <span key={s} className="rounded-lg bg-rose-50 px-2 py-1 text-[11px] font-medium text-rose-700">反 {s}</span>
            ))}
          </div>
        )}

        {item.collocations && (
          <div className="mt-4">
            <p className="text-xs font-bold text-slate-500">高频搭配</p>
            <ul className="mt-1.5 space-y-1.5">
              {item.collocations.map((c) => (
                <li key={c.phrase} className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2 text-xs ring-1 ring-slate-200">
                  <span className="font-semibold text-slate-800">{c.phrase}</span>
                  <span className="text-slate-500">{c.zh}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {item.wordFamily && (
          <div className="mt-4">
            <p className="text-xs font-bold text-slate-500">同根词族</p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {item.wordFamily.map((w) => (
                <span key={w.word} className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-[11px] text-slate-600">
                  <b className="text-slate-900">{w.word}</b> <span className="text-slate-400">{w.pos}</span> {w.zh}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5 flex gap-2">
          <button
            onClick={() => onToggleMastered(item.id)}
            className={cn(
              "flex-1 rounded-xl py-2.5 text-xs font-bold transition-colors",
              isMastered ? "bg-emerald-500 text-white" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
            )}
          >
            {isMastered ? "✓ 已掌握" : "标为已掌握"}
          </button>
          <button
            onClick={() => onToggleMistake(item.id)}
            className={cn(
              "flex-1 rounded-xl py-2.5 text-xs font-bold transition-colors",
              isMistake ? "bg-rose-500 text-white" : "bg-rose-50 text-rose-700 hover:bg-rose-100"
            )}
          >
            {isMistake ? "★ 在错词本中" : "+ 加入错词本"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function WordbookView({
  words,
  allWords,
  bookTitle,
  bookId,
  masteredIds,
  mistakeIds,
  onToggleMastered,
  onToggleMistake,
  accent,
  onAccentChange,
}: WordbookViewProps) {
  const [filter, setFilter] = useState<"all" | "mistakes" | "mastered">("all");
  const [search, setSearch] = useState("");
  const [scope, setScope] = useState<"book" | "all">("book");
  const [visible, setVisible] = useState(40);
  const [activeDetail, setActiveDetail] = useState<WordItem | null>(null);
  const [dailyIndex, setDailyIndex] = useState(0);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const daily = DAILY_SENTENCES[(bookId.length + dailyIndex) % DAILY_SENTENCES.length];
  const baseWords = scope === "all" ? allWords : words;

  const filteredWords = useMemo(() => {
    return baseWords.filter((w) => {
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        if (!w.word.toLowerCase().includes(q) && !w.meaning.includes(q)) return false;
      }
      if (filter === "mistakes") return mistakeIds.includes(w.id);
      if (filter === "mastered") return masteredIds.includes(w.id);
      return true;
    });
  }, [baseWords, search, filter, mistakeIds, masteredIds]);

  useEffect(() => {
    setVisible(40);
  }, [filter, search, scope]);

  const playWord = async (item: WordItem) => {
    setPlayingId(item.id);
    await pronounce(item.word, accent);
    setPlayingId(null);
  };

  return (
    <div className="mx-auto w-full max-w-2xl px-2 py-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-xl font-black text-slate-900">📚 词库内容中心</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            {bookTitle} · 英美双音 · 近义搭配 · 词根助记 · 真题语料
          </p>
        </div>
        <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700">
          已收录 {baseWords.length.toLocaleString()} 个词条
        </span>
      </div>

      {/* 每日一句 */}
      <div className="mt-4 overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-5 text-white shadow-lg shadow-indigo-500/20">
        <div className="flex items-center justify-between">
          <span className="rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold backdrop-blur">每日一句 · 英式发音</span>
          <button
            onClick={() => setDailyIndex((v) => v + 1)}
            className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-semibold hover:bg-white/25"
          >
            换一句 ↻
          </button>
        </div>
        <p className="mt-3 text-sm font-bold leading-relaxed">“{daily.en}”</p>
        <p className="mt-1.5 text-xs text-indigo-100">{daily.zh}</p>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            onClick={() => void pronounceSentence(daily.en, "uk")}
            className="rounded-xl bg-white px-3 py-1.5 text-[11px] font-bold text-indigo-700 hover:bg-indigo-50"
          >
            🇬🇧 听英式
          </button>
          <button
            onClick={() => void pronounceSentence(daily.en, "us")}
            className="rounded-xl bg-white/15 px-3 py-1.5 text-[11px] font-bold text-white ring-1 ring-white/30 hover:bg-white/25"
          >
            🇺🇸 听美式
          </button>
          <span className="text-[10px] text-indigo-200">{daily.source}</span>
        </div>
        <p className="mt-3 border-t border-white/15 pt-2 text-[10px] leading-relaxed text-indigo-100">📝 {daily.tip}</p>
      </div>

      {/* 词根小课堂 */}
      <div className="mt-4 rounded-3xl border border-slate-200/80 bg-white p-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">🧩 词根词缀小课堂</h3>
          <span className="text-[10px] text-slate-400">掌握 1 个词根 ≈ 记住 8 个单词</span>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {ROOT_LESSONS.map((root) => (
            <div key={root.id} className={cn("rounded-2xl bg-gradient-to-br p-3 text-white", root.color)}>
              <div className="flex items-center justify-between">
                <span className="text-sm font-black">{root.root}</span>
                <span className="rounded-full bg-white/20 px-2 py-0.5 text-[10px]">{root.meaning}</span>
              </div>
              <ul className="mt-2 space-y-0.5 text-[11px] text-white/90">
                {root.words.map((w) => (
                  <li key={w.word}><b>{w.word}</b> · {w.zh}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="relative mt-5">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="搜索英文单词或中文释义…"
          className="w-full rounded-2xl border border-slate-200 bg-white py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          aria-label="搜索单词"
        />
        <span className="absolute left-4 top-3.5 text-slate-400" aria-hidden="true">🔍</span>
      </div>

      {/* Filters + accent */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-1.5">
          {[
            { id: "all", label: `全部 ${baseWords.length}` },
            { id: "mistakes", label: `⚠️ 错词 ${mistakeIds.length}` },
            { id: "mastered", label: `🌟 已掌握 ${masteredIds.length}` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as typeof filter)}
              className={cn(
                "rounded-xl px-3 py-1.5 text-[11px] font-bold transition-colors",
                filter === tab.id ? "bg-slate-900 text-white shadow-sm" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <div className="flex rounded-xl bg-slate-100 p-0.5">
            {[
              { id: "book" as const, label: "本书" },
              { id: "all" as const, label: "全词库" },
            ].map((sc) => (
              <button
                key={sc.id}
                onClick={() => setScope(sc.id)}
                className={cn(
                  "rounded-lg px-2 py-1 text-[10px] font-bold transition-all",
                  scope === sc.id ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"
                )}
              >
                {sc.label}
              </button>
            ))}
          </div>
          <button
            onClick={() => onAccentChange(accent === "uk" ? "us" : "uk")}
            className="rounded-xl border border-indigo-200 bg-indigo-50 px-2.5 py-1.5 text-[10px] font-bold text-indigo-700 hover:bg-indigo-100"
          >
            发音：{accent === "uk" ? "🇬🇧 英式" : "🇺🇸 美式"} ⇄
          </button>
        </div>
      </div>

      {/* Word list */}
      {filteredWords.length === 0 ? (
        <div className="py-12 text-center">
          <p className="text-3xl">📭</p>
          <p className="mt-3 text-sm font-semibold text-slate-600">没有找到匹配的单词</p>
          <p className="mt-1 text-xs text-slate-400">换个筛选条件，或去「背单词」学几个新词</p>
        </div>
      ) : (
        <div className="mt-3 space-y-2.5">
          {filteredWords.slice(0, visible).map((item) => {
            const isMastered = masteredIds.includes(item.id);
            const isMistake = mistakeIds.includes(item.id);
            return (
              <div key={item.id} className="group rounded-2xl border border-slate-200/80 bg-white p-4 transition-all hover:border-indigo-200 hover:shadow-md">
                <div className="flex items-start justify-between gap-3">
                  <button onClick={() => setActiveDetail(item)} className="flex-1 text-left">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-bold text-slate-900">{item.word}</span>
                      <span className="text-[11px] text-slate-400">
                        <span className="text-slate-500">🇬🇧</span> {item.phonetic}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        <span className="text-slate-500">🇺🇸</span> {item.usPhonetic}
                      </span>
                      <span className="rounded bg-indigo-50 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-700">{item.pos}</span>
                      {isMistake && <span className="rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-semibold text-rose-600">错词</span>}
                      {isMastered && <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-600">已掌握</span>}
                    </div>
                    <p className="mt-1 text-sm font-semibold text-slate-700">{item.meaning}</p>
                    <p className="mt-1.5 line-clamp-2 text-[11px] italic leading-relaxed text-slate-500">{item.example ? `“${item.example}”` : item.meaning}</p>
                    <p className="mt-1 text-[10px] text-indigo-600">查看详情 · 搭配 · 词族 ›</p>
                  </button>
                  <div className="flex shrink-0 flex-col gap-1.5">
                    <button
                      onClick={() => void playWord(item)}
                      className={cn(
                        "rounded-xl bg-indigo-50 px-2.5 py-1 text-[11px] font-bold text-indigo-700 hover:bg-indigo-100",
                        playingId === item.id && "animate-pulse"
                      )}
                      aria-label={`朗读 ${item.word}`}
                    >
                      🔊 {accent === "uk" ? "英" : "美"}
                    </button>
                    <button
                      onClick={() => onToggleMastered(item.id)}
                      className={cn(
                        "rounded-xl px-2.5 py-1 text-[10px] font-bold transition-colors",
                        isMastered ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500 hover:bg-emerald-50 hover:text-emerald-600"
                      )}
                    >
                      {isMastered ? "✓" : "掌握"}
                    </button>
                    <button
                      onClick={() => onToggleMistake(item.id)}
                      className={cn(
                        "rounded-xl px-2.5 py-1 text-[10px] font-bold transition-colors",
                        isMistake ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-500 hover:bg-rose-50 hover:text-rose-600"
                      )}
                    >
                      {isMistake ? "★" : "+错词"}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {filteredWords.length > visible && (
        <button
          onClick={() => setVisible((v) => v + 60)}
          className="mt-4 w-full rounded-2xl border border-slate-200 bg-white py-3 text-xs font-bold text-slate-600 transition-colors hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-600"
        >
          加载更多词条（剩余 {(filteredWords.length - visible).toLocaleString()} 词）
        </button>
      )}

      {activeDetail && (
        <WordDetailModal
          item={activeDetail}
          accent={accent}
          onAccentChange={onAccentChange}
          onClose={() => setActiveDetail(null)}
          isMastered={masteredIds.includes(activeDetail.id)}
          isMistake={mistakeIds.includes(activeDetail.id)}
          onToggleMastered={onToggleMastered}
          onToggleMistake={onToggleMistake}
        />
      )}
    </div>
  );
}
