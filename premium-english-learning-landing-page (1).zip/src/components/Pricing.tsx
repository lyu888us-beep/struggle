import { useState } from "react";
import Reveal from "./Reveal";
import { cn } from "../utils/cn";

const plans = [
  {
    name: "免费版",
    desc: "适合体验核心记忆功能",
    monthly: 0,
    yearly: 0,
    cta: "免费注册",
    featured: false,
    features: ["1 个考纲词库", "AI 记忆曲线复习", "每日 20 个新词上限", "基础学习统计", "英美双音发音"],
  },
  {
    name: "Pro 学生版",
    desc: "冲刺考试的最优选择",
    monthly: 25,
    yearly: 15,
    cta: "开始 7 天免费试用",
    featured: true,
    features: ["全部 30+ 考纲词库", "无限新词 + 错词强化引擎", "真题语境 + 词根词缀拆解", "好友对战 & 班级排行榜", "AI 发音评分跟读", "每周学情报告", "离线学习 & 多端同步"],
  },
  {
    name: "班级版",
    desc: "面向学校与培训机构",
    monthly: -1,
    yearly: -1,
    cta: "联系我们",
    featured: false,
    features: ["包含 Pro 全部功能", "教师管理后台", "班级学情大屏", "自定义校本词库", "专属客户成功经理"],
  },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute left-1/2 top-1/3 h-[30rem] w-[40rem] -translate-x-1/2 rounded-full bg-indigo-100/50 blur-3xl" />
      </div>
      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-emerald-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-emerald-600 ring-1 ring-emerald-100">
              学生专属定价
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
              一杯奶茶钱，<span className="text-gradient">换一整月高效记忆</span>
            </span>
          </Reveal>
          <Reveal delay={200}>
            <div className="mt-8 inline-flex items-center gap-1 rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm">
              <button
                onClick={() => setYearly(false)}
                aria-pressed={!yearly}
                className={cn(
                  "rounded-xl px-5 py-2 text-sm font-semibold transition-all duration-300",
                  !yearly ? "bg-slate-900 text-white shadow" : "text-slate-500 hover:text-slate-900"
                )}
              >
                按月付费
              </button>
              <button
                onClick={() => setYearly(true)}
                aria-pressed={yearly}
                className={cn(
                  "flex items-center gap-2 rounded-xl px-5 py-2 text-sm font-semibold transition-all duration-300",
                  yearly ? "bg-slate-900 text-white shadow" : "text-slate-500 hover:text-slate-900"
                )}
              >
                按年付费
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-600">省 40%</span>
              </button>
            </div>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3 lg:items-stretch">
          {plans.map((p, i) => {
            const price = yearly ? p.yearly : p.monthly;
            return (
              <Reveal key={p.name} delay={i * 120} direction={p.featured ? "scale" : "up"}>
                <article
                  className={cn(
                    "relative flex h-full flex-col rounded-3xl p-8 transition-all duration-500",
                    p.featured
                      ? "border border-transparent bg-gradient-to-b from-indigo-600 via-violet-600 to-fuchsia-600 text-white shadow-2xl shadow-indigo-500/35 hover:-translate-y-2 lg:scale-[1.04]"
                      : "border border-slate-200/80 bg-white/90 shadow-sm backdrop-blur hover:-translate-y-1.5 hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-500/10"
                  )}
                >
                  {p.featured && (
                    <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-gradient-to-r from-amber-400 to-orange-400 px-4 py-1.5 text-xs font-bold text-amber-950 shadow-lg">
                      ⚡ 93% 的学生选择
                    </span>
                  )}
                  <h3 className={cn("text-lg font-bold", p.featured ? "text-white" : "text-slate-900")}>{p.name}</h3>
                  <p className={cn("mt-1 text-sm", p.featured ? "text-indigo-100" : "text-slate-500")}>{p.desc}</p>

                  <div className="mt-6 flex items-end gap-1.5">
                    {price < 0 ? (
                      <span className={cn("text-4xl font-extrabold tracking-tight", p.featured ? "text-white" : "text-slate-900")}>定制报价</span>
                    ) : (
                      <>
                        <span className={cn("text-5xl font-extrabold tracking-tight", p.featured ? "text-white" : "text-slate-900")}>
                          ¥{price}
                        </span>
                        <span className={cn("pb-1.5 text-sm font-medium", p.featured ? "text-indigo-100" : "text-slate-400")}>/ 月</span>
                      </>
                    )}
                  </div>
                  {p.featured && yearly && (
                    <p className="mt-1.5 text-xs font-medium text-indigo-100">年付 ¥180，相当于每天 ¥0.5</p>
                  )}

                  <ul className="mt-7 flex-1 space-y-3">
                    {p.features.map((f) => (
                      <li key={f} className={cn("flex items-start gap-2.5 text-sm", p.featured ? "text-indigo-50" : "text-slate-600")}>
                        <span
                          className={cn(
                            "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px]",
                            p.featured ? "bg-white/20 text-white" : "bg-indigo-50 text-indigo-600"
                          )}
                          aria-hidden="true"
                        >
                          ✓
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>

                  <a
                    href="#cta"
                    className={cn(
                      "mt-8 block rounded-2xl py-3.5 text-center text-sm font-bold transition-all duration-300 hover:-translate-y-0.5",
                      p.featured
                        ? "bg-white text-indigo-700 shadow-lg hover:shadow-xl"
                        : "bg-slate-900 text-white shadow-md hover:bg-indigo-600 hover:shadow-lg hover:shadow-indigo-500/30"
                    )}
                  >
                    {p.cta}
                  </a>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={300}>
          <p className="mt-10 text-center text-sm text-slate-400">
            🎓 凭学生证可再享 85 折 · 随时取消 · 7 天无理由退款
          </p>
        </Reveal>
      </div>
    </section>
  );
}
