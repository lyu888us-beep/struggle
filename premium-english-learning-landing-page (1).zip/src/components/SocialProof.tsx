import { useEffect, useRef, useState } from "react";
import Reveal from "./Reveal";

function useCountUp(target: number, duration = 1800) {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const start = performance.now();
          const tick = (now: number) => {
            const p = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            setValue(Math.round(target * eased));
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          io.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [target, duration]);

  return { ref, value };
}

function Stat({ target, suffix, label, delay }: { target: number; suffix: string; label: string; delay: number }) {
  const { ref, value } = useCountUp(target);
  return (
    <Reveal delay={delay} className="text-center">
      <p className="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
        <span ref={ref}>{value.toLocaleString()}</span>
        <span className="text-gradient">{suffix}</span>
      </p>
      <p className="mt-1.5 text-sm text-slate-500">{label}</p>
    </Reveal>
  );
}

const schools = ["清华附中", "人大附中", "复旦附中", "杭州外国语", "深圳中学", "成都七中", "南京外国语", "华师一附中", "上海中学", "衡水中学"];

export default function SocialProof() {
  return (
    <section className="relative border-y border-slate-200/70 bg-white/60 py-14 backdrop-blur-sm" aria-label="数据与口碑">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
          <Stat target={300} suffix="万+" label="注册学生用户" delay={0} />
          <Stat target={12} suffix="亿+" label="累计记忆单词次数" delay={100} />
          <Stat target={94} suffix="%" label="30 天记忆保持率" delay={200} />
          <Stat target={4} suffix=".9 分" label="应用商店平均评分" delay={300} />
        </div>

        <Reveal delay={200} className="mt-12">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">
            全国 2,000+ 所学校师生的共同选择
          </p>
          <div className="relative mt-6 overflow-hidden" aria-hidden="true">
            <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-20 bg-gradient-to-r from-white to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-white to-transparent" />
            <div className="animate-marquee flex w-max gap-10">
              {[...schools, ...schools].map((s, i) => (
                <span
                  key={i}
                  className="flex items-center gap-2 whitespace-nowrap text-sm font-semibold text-slate-400 transition-colors duration-300 hover:text-indigo-500"
                >
                  <svg className="h-4 w-4 text-indigo-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 10L12 5 2 10l10 5 10-5zM6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5" />
                  </svg>
                  {s}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
