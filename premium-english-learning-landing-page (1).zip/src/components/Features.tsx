import Reveal from "./Reveal";

const features = [
  {
    icon: "🧠",
    gradient: "from-indigo-500 to-violet-500",
    title: "AI 记忆曲线",
    desc: "算法实时追踪你对每个单词的掌握度，在遗忘临界点精准推送复习，记忆保持率提升至 94%。",
  },
  {
    icon: "🎯",
    gradient: "from-fuchsia-500 to-pink-500",
    title: "考纲精准词库",
    desc: "覆盖中考、高考、四六级、考研、雅思托福全系词库，每个词标注真题出现频次与考点。",
  },
  {
    icon: "🎮",
    gradient: "from-amber-500 to-orange-500",
    title: "游戏化闯关",
    desc: "单词消消乐、限时拼写赛、好友对战——把枯燥的背诵变成每天最期待的 15 分钟。",
  },
  {
    icon: "📖",
    gradient: "from-emerald-500 to-teal-500",
    title: "真题语境 + 词族拓展",
    desc: "精讲词条包含真题例句、近义辨析、反义词、高频搭配、同根词族与词根助记，不止认识，更会运用。",
  },
  {
    icon: "🔊",
    gradient: "from-sky-500 to-blue-500",
    title: "英式 · 美式真人发音",
    desc: "每个词条与例句均配备英式 / 美式真人录音，可随时切换、单句循环跟读；弱网自动切换智能语音兜底。",
  },
  {
    icon: "📊",
    gradient: "from-violet-500 to-purple-500",
    title: "学情报告",
    desc: "每周生成可视化学习报告，薄弱词自动归入错词本，家长与老师一目了然。",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-indigo-200 to-transparent" />
      </div>
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-indigo-50 px-4 py-1.5 text-xs font-semibold tracking-wide text-indigo-600 ring-1 ring-indigo-100">
              核心功能
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl">
              为「记得住」而设计的
              <span className="text-gradient">每一个细节</span>
            </span>
          </Reveal>
          <Reveal delay={200} as="p">
            <span className="mt-5 block text-base leading-relaxed text-slate-500 sm:text-lg">
              我们研究了 10 万+ 学生的学习数据，把认知科学变成你每天都在用的功能。
            </span>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 90}>
              <article className="group relative h-full overflow-hidden rounded-3xl border border-slate-200/80 bg-white/80 p-7 shadow-sm backdrop-blur transition-all duration-500 hover:-translate-y-1.5 hover:border-indigo-200 hover:shadow-2xl hover:shadow-indigo-500/10">
                <div className="pointer-events-none absolute -right-12 -top-12 h-36 w-36 rounded-full bg-gradient-to-br from-indigo-100/0 to-indigo-100/0 blur-2xl transition-all duration-500 group-hover:from-indigo-200/60 group-hover:to-fuchsia-200/40" aria-hidden="true" />
                <div className={`relative grid h-13 w-13 place-items-center rounded-2xl bg-gradient-to-br ${f.gradient} text-2xl shadow-lg transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3`} style={{ height: "3.25rem", width: "3.25rem" }}>
                  <span aria-hidden="true">{f.icon}</span>
                </div>
                <h3 className="relative mt-5 text-lg font-bold text-slate-900">{f.title}</h3>
                <p className="relative mt-2.5 text-sm leading-relaxed text-slate-500">{f.desc}</p>
                <span className="relative mt-5 inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 opacity-0 transition-all duration-300 group-hover:opacity-100">
                  了解更多
                  <svg className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </span>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
