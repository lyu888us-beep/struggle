import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import Benefits from "./components/Benefits";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import LearningContent from "./components/LearningContent";
import AppLayout from "./components/app/AppLayout";
import type { WordCategory } from "./types/vocab";

export default function App() {
  const [initialBook, setInitialBook] = useState<WordCategory | null>(null);
  const [viewMode, setViewMode] = useState<"landing" | "app">(() => {
    if (typeof window !== "undefined" && window.location.hash === "#app") {
      return "app";
    }
    return "landing";
  });

  useEffect(() => {
    const handleHash = () => {
      if (window.location.hash === "#app") {
        setViewMode("app");
      }
    };
    window.addEventListener("hashchange", handleHash);
    return () => window.removeEventListener("hashchange", handleHash);
  }, []);

  const openApp = () => {
    setInitialBook(null);
    setViewMode("app");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openBook = (book: WordCategory) => {
    setInitialBook(book);
    setViewMode("app");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const backToLanding = () => {
    setViewMode("landing");
    if (window.location.hash === "#app") {
      history.pushState(null, "", window.location.pathname);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (viewMode === "app") {
    return <AppLayout onBackToLanding={backToLanding} initialBook={initialBook} />;
  }

  return (
    <div className="min-h-screen">
      <a
        href="#features"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-xl focus:bg-indigo-600 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
      >
        跳转到主要内容
      </a>

      <Navbar onOpenApp={openApp} />
      <main>
        <Hero onOpenApp={openApp} />
        <SocialProof />
        <Features />
        <LearningContent onOpenApp={openApp} onOpenBook={openBook} />
        <Showcase onOpenApp={openApp} />
        <Benefits />
        <Testimonials />
        <Pricing />
        <FAQ />
        <CTA onOpenApp={openApp} />
      </main>
      <Footer />

      {/* Floating Bottom Quick-Launcher to App */}
      <div className="fixed bottom-6 right-6 z-40 hidden sm:block">
        <button
          onClick={openApp}
          className="group flex items-center gap-2.5 rounded-full bg-slate-900/90 pl-4 pr-5 py-3 text-sm font-bold text-white shadow-2xl shadow-indigo-900/30 backdrop-blur-md ring-1 ring-white/20 transition-all duration-300 hover:scale-105 hover:bg-gradient-to-r hover:from-indigo-600 hover:to-violet-600 cursor-pointer"
        >
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500" />
          </span>
          <span>免安装 · 启动背单词 App</span>
          <span className="rounded-full bg-white/20 px-2 py-0.5 text-xs">GO →</span>
        </button>
      </div>
    </div>
  );
}
