# 自动运维交付边界

`PRODUCTION-OPS.md` describes the automation to run in the production backend; `API-CONTRACT.md` describes the API interfaces. The static preview only demonstrates the front-end trial timer and checkout handoff UX. No real payments, emails, recurring jobs, monitoring service, or server backups are active until infrastructure and merchant credentials are configured.