# Lexio API contract (production integration target)

This file describes the boundary required to activate billing. No live payment API is included in this front-end prototype.

## `POST /api/trial/start`

Requires an authenticated user and explicit consent to trial / renewal terms. The server creates the trial and returns a server-authoritative expiry timestamp. If the selected payment provider requires payment details before a free trial, create the trial through the provider's hosted checkout flow instead of collecting payment data in the app.

## `GET /api/me/entitlement`

Example response:

```json
{
  "status": "trialing",
  "trialEndsAt": "2026-11-01T00:00:00Z",
  "plan": "lexio-pro-monthly",
  "canStudy": true,
  "cancelAtPeriodEnd": false
}
```

The server—not browser localStorage—decides access.

## `POST /api/checkout`

The prototype sends only `{ "plan": "monthly" | "annual", "provider": "wechat" | "alipay" }`. Require auth + CSRF protection. Resolve amount, discounts, currency and renewal terms from trusted server configuration / merchant product IDs; never trust browser-supplied price. Return the provider's approved redirect / QR-payment payload only after creating a server-side order. Recurring billing must use the chosen provider's approved authorization flow.

## `POST /api/webhooks/{provider}`

Verify the provider signature against the raw request body. Persist provider event IDs for idempotency. Handle subscription created / updated / deleted and invoice paid / failed events. Return success only after safely recording an event for processing.

## `POST /api/subscription/cancel`

Requires auth. Cancels through the provider and records when access ends. Provide self-serve subscription management and an audit log.
