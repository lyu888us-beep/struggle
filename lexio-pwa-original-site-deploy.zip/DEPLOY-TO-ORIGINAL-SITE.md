# 发布到原站域名：静态 PWA 文件包

本包已把原站的落地页模块与当前 Lexio PWA 学习功能、25,024 条考试分类学习记录融合到同一套静态站点文件中。它尚未发布到线上原域名：当前工作区没有连接原站的项目源码或发布权限。

## 上传要求

1. 在原站的站点编辑 / 发布平台中，将本包**内部的文件**作为站点根目录内容上传或替换；不要只上传 ZIP 文件本身。
2. 保留原有目录结构，尤其是 `data/original-site-wordbank.json`；`index.html`、`manifest.webmanifest`、`sw.js`、两份 JSON 配置及图标需位于根目录。
3. 通过 HTTPS 发布。PWA 安装和 Service Worker 需要安全来源。
4. 发布后验收首页、`/manifest.webmanifest`、`/sw.js`、`/wordbank.config.json`、`/data/original-site-wordbank.json` 均可访问；浏览器首次在线打开时会把词库导入 IndexedDB。
5. 如果 Arena.site 的编辑器不支持 ZIP/静态文件导入，请先从项目后台导出源码或提供其 Git 仓库 / 发布方式，再按该平台的入口发布。

## 重要边界

- 这个包中的 `index.html` 是已融合模块的静态首页版本；线上原站没有被此包自动修改。需要站点所有者在托管平台点击发布，才能让原址开始提供新 PWA。
- 价格仍是示例配置，支付入口尚未连接商户或后端；不要公开填入支付密钥。
- 词库文件含原站页面中公开的词条数据。正式商业发布前请确认数据使用授权。
