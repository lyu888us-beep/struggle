import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export type LessonBlock =
  | { type: "lead"; text: string }
  | { type: "heading"; text: string }
  | { type: "paragraph"; text: string }
  | { type: "quote"; text: string; source: string }
  | { type: "tip"; title: string; text: string }
  | { type: "phrases"; title: string; items: { en: string; zh: string }[] }
  | { type: "note"; text: string };

export type QuizQuestion = {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
};

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    sessionKey: text("session_key").notNull(),
    displayName: text("display_name").notNull().default("学习者"),
    email: text("email"),
    plan: text("plan").notNull().default("trial"),
    status: text("status").notNull().default("trialing"),
    trialStartedAt: timestamp("trial_started_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }).notNull(),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
    autoRenew: boolean("auto_renew").notNull().default(true),
    preferredDevice: text("preferred_device").notNull().default("desktop"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_session_key_idx").on(table.sessionKey)],
);

export const courses = pgTable(
  "courses",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    titleEn: text("title_en").notNull(),
    tagline: text("tagline").notNull(),
    description: text("description").notNull(),
    category: text("category").notNull(),
    level: text("level").notNull(),
    accent: text("accent").notNull().default("forest"),
    emoji: text("emoji").notNull().default("✦"),
    minutes: integer("minutes").notNull().default(0),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("courses_slug_idx").on(table.slug)],
);

export const lessons = pgTable(
  "lessons",
  {
    id: serial("id").primaryKey(),
    courseId: integer("course_id")
      .notNull()
      .references(() => courses.id, { onDelete: "cascade" }),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    titleZh: text("title_zh").notNull(),
    summary: text("summary").notNull(),
    level: text("level").notNull(),
    minutes: integer("minutes").notNull().default(12),
    xp: integer("xp").notNull().default(50),
    content: jsonb("content").$type<LessonBlock[]>().notNull(),
    quiz: jsonb("quiz").$type<QuizQuestion[]>().notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("lessons_slug_idx").on(table.slug)],
);

export const words = pgTable(
  "words",
  {
    id: serial("id").primaryKey(),
    word: text("word").notNull(),
    phonetic: text("phonetic").notNull(),
    partOfSpeech: text("part_of_speech").notNull(),
    meaningZh: text("meaning_zh").notNull(),
    nuance: text("nuance").notNull(),
    exampleEn: text("example_en").notNull(),
    exampleZh: text("example_zh").notNull(),
    level: text("level").notNull().default("C1"),
  },
  (table) => [uniqueIndex("words_word_idx").on(table.word)],
);

export const lessonProgress = pgTable(
  "lesson_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: integer("lesson_id")
      .notNull()
      .references(() => lessons.id, { onDelete: "cascade" }),
    score: integer("score").notNull().default(0),
    attempts: integer("attempts").notNull().default(1),
    completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("lesson_progress_user_lesson_idx").on(table.userId, table.lessonId)],
);

export const wordProgress = pgTable(
  "word_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    wordId: integer("word_id")
      .notNull()
      .references(() => words.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("learning"),
    reviewCount: integer("review_count").notNull().default(0),
    addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
    lastReviewedAt: timestamp("last_reviewed_at", { withTimezone: true }),
  },
  (table) => [uniqueIndex("word_progress_user_word_idx").on(table.userId, table.wordId)],
);

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    orderNo: text("order_no").notNull(),
    plan: text("plan").notNull(),
    planName: text("plan_name").notNull(),
    amountCents: integer("amount_cents").notNull(),
    subtotalCents: integer("subtotal_cents").notNull(),
    discountCents: integer("discount_cents").notNull().default(0),
    coupon: text("coupon"),
    currency: text("currency").notNull().default("CNY"),
    method: text("method").notNull(),
    status: text("status").notNull().default("paid"),
    periodStart: timestamp("period_start", { withTimezone: true }),
    periodEnd: timestamp("period_end", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("payments_order_no_idx").on(table.orderNo)],
);

export type User = typeof users.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type Word = typeof words.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type WordProgress = typeof wordProgress.$inferSelect;
export type LessonProgress = typeof lessonProgress.$inferSelect;
