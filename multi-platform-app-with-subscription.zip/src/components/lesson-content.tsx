import type { LessonBlock } from "@/db/schema";
import { Lightbulb, Quote } from "lucide-react";
import { SpeakButton } from "@/components/learning-client";

export function LessonContent({ blocks }: { blocks: LessonBlock[] }) {
  return (
    <div className="space-y-5">
      {blocks.map((block, index) => {
        switch (block.type) {
          case "lead":
            return (
              <p
                key={index}
                className="border-l-2 border-clay/70 pl-4 font-display text-[clamp(1.15rem,1.8vw,1.4rem)] leading-snug text-ink"
              >
                {block.text}
              </p>
            );
          case "heading":
            return (
              <h3 key={index} className="pt-1 font-display text-xl text-ink">
                {block.text}
              </h3>
            );
          case "paragraph":
            return (
              <p key={index} className="text-[14px] leading-[1.9] text-ink/75">
                {block.text}
              </p>
            );
          case "quote":
            return (
              <figure key={index} className="relative rounded-2xl bg-forest px-5 py-6 text-cream">
                <div className="grain absolute inset-0 rounded-2xl opacity-20" />
                <Quote className="relative h-4 w-4 text-gold/70" />
                <blockquote className="relative mt-2 font-display text-[16px] leading-relaxed">
                  {block.text}
                </blockquote>
                <figcaption className="relative mt-2 text-[10.5px] uppercase tracking-[0.18em] text-cream/40">
                  {block.source}
                </figcaption>
              </figure>
            );
          case "tip":
            return (
              <div key={index} className="rounded-2xl border border-gold/40 bg-gold/[0.08] p-4">
                <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a6a2c]">
                  <Lightbulb className="h-3.5 w-3.5" />
                  {block.title}
                </p>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink/70">{block.text}</p>
              </div>
            );
          case "phrases":
            return (
              <div key={index} className="rounded-2xl border border-line bg-parchment/25 p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-moss/70">
                  {block.title}
                </p>
                <ul className="mt-2.5 space-y-2.5">
                  {block.items.map((item) => (
                    <li key={item.en} className="border-b border-line/50 pb-2.5 last:border-0 last:pb-0">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-display text-[14px] text-ink">{item.en}</span>
                        <SpeakButton text={item.en} label="" />
                      </div>
                      <p className="mt-0.5 text-[11.5px] leading-relaxed text-ink/50">{item.zh}</p>
                    </li>
                  ))}
                </ul>
              </div>
            );
          case "note":
            return (
              <p
                key={index}
                className="rounded-xl border border-dashed border-line px-4 py-3 text-[12px] leading-relaxed text-ink/50"
              >
                {block.text}
              </p>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}
