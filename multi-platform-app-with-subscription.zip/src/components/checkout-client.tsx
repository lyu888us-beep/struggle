"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Check,
  CreditCard,
  Loader2,
  Lock,
  Loader,
  ShieldCheck,
  Sparkles,
  Tag,
  X,
} from "lucide-react";
import { submitPaymentAction, validateCouponAction } from "@/app/actions";
import {
  PAYMENT_METHODS,
  PLANS,
  addPlanPeriod,
  formatCNY,
  priceBreakdown,
  type PlanId,
} from "@/lib/plans";

type Props = {
  initialPlan: PlanId;
  currentPlan: string;
  email: string | null;
  entitlementState: string;
  trialNote: string;
  basePath: string;
};

const paymentIcons: Record<string, string> = {
  wechat: "微",
  alipay: "支",
  applepay: "",
  card: "卡",
};

export function CheckoutFlow({
  initialPlan,
  currentPlan,
  email,
  entitlementState,
  trialNote,
  basePath,
}: Props) {
  const router = useRouter();
  const [planId, setPlanId] = useState<PlanId>(initialPlan);
  const [method, setMethod] = useState<string>("wechat");
  const [couponInput, setCouponInput] = useState("");
  const [coupon, setCoupon] = useState<{ code: string; percentOff: number; label: string } | null>(
    null,
  );
  const [couponMessage, setCouponMessage] = useState<string | null>(null);
  const [couponError, setCouponError] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const [processing, setProcessing] = useState(false);
  const [agreed, setAgreed] = useState(true);

  const pricing = priceBreakdown(planId, coupon?.code);
  const isLifetime = planId === "lifetime";
  const renewalDate = addPlanPeriod(new Date(), planId);

  const applyCoupon = () => {
    if (!couponInput.trim()) return;
    startTransition(async () => {
      const result = await validateCouponAction(couponInput);
      if (!result.ok) {
        setCouponError(true);
        setCouponMessage(result.message);
        setCoupon(null);
        return;
      }
      setCoupon({ code: couponInput.trim().toUpperCase(), percentOff: result.percentOff, label: result.label });
      setCouponError(false);
      setCouponMessage(`${result.label} · 已优惠 ${result.percentOff}%`);
    });
  };

  const pay = () => {
    if (!agreed) {
      setError("请先阅读并同意订阅条款");
      return;
    }
    setError(null);
    setProcessing(true);
    startTransition(async () => {
      const result = await submitPaymentAction({
        plan: planId,
        method,
        coupon: coupon?.code,
      });
      if (!result.ok) {
        setProcessing(false);
        setError(result.message);
        return;
      }
      window.setTimeout(() => {
        router.push(`/checkout/success?order=${result.orderNo}`);
      }, 1100);
    });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <Link href={basePath} className="inline-flex items-center gap-1.5 text-[12px] text-ink/55 hover:text-ink">
            <ArrowLeft className="h-3.5 w-3.5" />
            返回应用
          </Link>
          <span className="chip">
            <Lock className="h-3 w-3" />
            安全结账 · 演示环境
          </span>
        </div>

        {entitlementState === "expired" && (
          <div className="rounded-2xl border border-clay/25 bg-clay/[0.06] px-4 py-3 text-[12px] text-clay">
            免费试用已结束。完成订阅后全部课程与学习记录立即恢复。
          </div>
        )}
        {entitlementState === "trialing" && (
          <div className="flex items-start gap-2 rounded-2xl border border-forest/20 bg-forest/[0.05] px-4 py-3 text-[12px] text-forest">
            <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>
              {trialNote}。现在订阅，7 天试用期间的进度会全部保留，正式会员从今天开始计算。
            </span>
          </div>
        )}

        <section className="card p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl">1 · 选择方案</h2>
            <span className="text-[11px] text-ink/40">可随时切换或取消</span>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {PLANS.map((plan) => {
              const active = plan.id === planId;
              return (
                <button
                  key={plan.id}
                  type="button"
                  onClick={() => setPlanId(plan.id)}
                  className={`relative rounded-2xl border p-4 text-left transition-all ${
                    active
                      ? "border-forest bg-forest/[0.04] shadow-[0_0_0_3px_rgba(30,58,44,0.08)]"
                      : "border-line bg-[#fffdf8] hover:border-moss/50"
                  }`}
                >
                  {plan.badge && (
                    <span className="absolute -top-2 right-3 rounded-full bg-clay px-2 py-0.5 text-[9px] font-semibold text-white">
                      {plan.badge}
                    </span>
                  )}
                  {currentPlan === plan.id && (
                    <span className="absolute -top-2 left-3 rounded-full bg-forest px-2 py-0.5 text-[9px] font-semibold text-cream">
                      当前
                    </span>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-[12.5px] font-semibold text-ink">{plan.name}</span>
                    <span
                      className={`grid h-4 w-4 place-items-center rounded-full border ${
                        active ? "border-forest bg-forest text-cream" : "border-line text-transparent"
                      }`}
                    >
                      <Check className="h-2.5 w-2.5" />
                    </span>
                  </div>
                  <p className="mt-2 font-display text-2xl leading-none">
                    {formatCNY(plan.priceCents)}
                    <span className="text-[10px] font-normal text-ink/40"> {plan.per}</span>
                  </p>
                  {plan.originalCents && (
                    <p className="mt-1 text-[10px] text-ink/35 line-through">
                      原价 {formatCNY(plan.originalCents)}
                    </p>
                  )}
                  <p className="mt-2 text-[10.5px] leading-relaxed text-ink/50">{plan.tagline}</p>
                </button>
              );
            })}
          </div>
        </section>

        <section className="card p-5">
          <h2 className="font-display text-xl">2 · 优惠码</h2>
          <div className="mt-3 flex gap-2">
            <div className="relative flex-1">
              <Tag className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink/35" />
              <input
                value={couponInput}
                onChange={(event) => {
                  setCouponInput(event.target.value.toUpperCase());
                  setCouponMessage(null);
                }}
                placeholder="输入优惠码，如 NUANCE30"
                className="w-full rounded-full border border-line bg-[#fffdf8] py-2.5 pl-9 pr-3 text-[12px] uppercase tracking-wider outline-none focus:border-moss/60"
              />
            </div>
            <button
              type="button"
              onClick={applyCoupon}
              disabled={pending || !couponInput.trim()}
              className="btn btn-ghost text-[12px]"
            >
              使用
            </button>
          </div>
          {coupon && (
            <div className="mt-3 flex items-center justify-between rounded-xl border border-forest/20 bg-forest/[0.05] px-3 py-2">
              <span className="flex items-center gap-1.5 text-[11.5px] text-forest">
                <Check className="h-3.5 w-3.5" />
                {coupon.code} · {coupon.label}
              </span>
              <button
                type="button"
                onClick={() => {
                  setCoupon(null);
                  setCouponInput("");
                  setCouponMessage(null);
                }}
                className="text-ink/40 hover:text-clay"
                aria-label="移除优惠码"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
          {couponMessage && !coupon && (
            <p className={`mt-2 text-[11px] ${couponError ? "text-clay" : "text-forest"}`}>
              {couponMessage}
            </p>
          )}
          <p className="mt-2 text-[10.5px] text-ink/40">
            演示可用：<span className="font-semibold text-ink/60">NUANCE30</span>（7 折）或{" "}
            <span className="font-semibold text-ink/60">WELCOME15</span>（85 折）。
          </p>
        </section>

        <section className="card p-5">
          <h2 className="font-display text-xl">3 · 支付方式</h2>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {PAYMENT_METHODS.map((item) => {
              const active = method === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setMethod(item.id)}
                  className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-all ${
                    active
                      ? "border-forest bg-forest/[0.04]"
                      : "border-line bg-[#fffdf8] hover:border-moss/50"
                  }`}
                >
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-parchment/70 text-[12px] font-semibold text-forest">
                    {paymentIcons[item.id] ?? item.glyph}
                  </span>
                  <span className="flex-1">
                    <span className="block text-[12px] font-semibold text-ink">{item.name}</span>
                    <span className="block text-[10px] text-ink/40">{item.hint}</span>
                  </span>
                  <span
                    className={`grid h-4 w-4 place-items-center rounded-full border ${
                      active ? "border-forest bg-forest text-cream" : "border-line text-transparent"
                    }`}
                  >
                    <Check className="h-2.5 w-2.5" />
                  </span>
                </button>
              );
            })}
          </div>

          {method === "card" && (
            <div className="mt-3 grid gap-2 rounded-xl border border-line/70 bg-parchment/25 p-3 sm:grid-cols-2">
              <input
                placeholder="卡号 · 4242 4242 4242 4242"
                className="rounded-lg border border-line bg-white px-3 py-2 text-[11.5px] outline-none focus:border-moss/60"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  placeholder="MM / YY"
                  className="rounded-lg border border-line bg-white px-3 py-2 text-[11.5px] outline-none focus:border-moss/60"
                />
                <input
                  placeholder="CVC"
                  className="rounded-lg border border-line bg-white px-3 py-2 text-[11.5px] outline-none focus:border-moss/60"
                />
              </div>
              <p className="text-[10px] text-ink/40 sm:col-span-2">
                演示环境不会真实扣款，也不会保存卡号。
              </p>
            </div>
          )}

          <label className="mt-4 flex cursor-pointer items-start gap-2 text-[11px] leading-relaxed text-ink/55">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(event) => setAgreed(event.target.checked)}
              className="mt-0.5 h-3.5 w-3.5 accent-[#1e3a2c]"
            />
            <span>
              我已阅读并同意《会员服务条款》与《自动续费规则》。虚拟内容开通即生效，7 天内可申请退款。
            </span>
          </label>
          {error && <p className="mt-2 text-[11px] text-clay">{error}</p>}
        </section>
      </div>

      <aside className="lg:sticky lg:top-6 lg:self-start">
        <div className="overflow-hidden rounded-[26px] border border-forest/20 bg-forest text-cream">
          <div className="grain relative p-5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-cream/50">
              Order summary
            </p>
            <h2 className="mt-1 font-display text-2xl">订单确认</h2>

            <div className="mt-4 space-y-2.5 text-[12px]">
              <div className="flex justify-between text-cream/70">
                <span>{pricing.plan.name}</span>
                <span>{formatCNY(pricing.subtotalCents)}</span>
              </div>
              {pricing.discountCents > 0 && (
                <div className="flex justify-between text-gold">
                  <span>优惠（{pricing.coupon?.code}）</span>
                  <span>-{formatCNY(pricing.discountCents)}</span>
                </div>
              )}
              <div className="flex justify-between text-cream/70">
                <span>税费</span>
                <span className="text-cream/50">已包含</span>
              </div>
              <div className="hairline my-1 opacity-30" />
              <div className="flex items-end justify-between">
                <span className="text-cream/60">应付总额</span>
                <span className="font-display text-3xl">{formatCNY(pricing.totalCents)}</span>
              </div>
              <p className="text-[10.5px] text-cream/45">
                {isLifetime
                  ? "一次性付款，永久有效"
                  : `今日支付 ${formatCNY(pricing.totalCents)}，${renewalDate ? `下次续费 ${renewalDate.toLocaleDateString("zh-CN")}` : ""}`}
              </p>
            </div>

            <ul className="mt-4 space-y-1.5">
              {pricing.plan.features.slice(0, 4).map((feature) => (
                <li key={feature} className="flex items-start gap-1.5 text-[11px] text-cream/70">
                  <Check className="mt-0.5 h-3 w-3 shrink-0 text-gold" />
                  {feature}
                </li>
              ))}
            </ul>

            <button
              type="button"
              onClick={pay}
              disabled={pending || processing}
              className="btn mt-5 w-full bg-cream text-[13px] text-forest hover:bg-white disabled:opacity-60"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  正在处理支付
                </>
              ) : (
                <>
                  <CreditCard className="h-4 w-4" />
                  支付 {formatCNY(pricing.totalCents)}
                </>
              )}
            </button>
            <p className="mt-2.5 flex items-center justify-center gap-1.5 text-[10px] text-cream/40">
              <ShieldCheck className="h-3 w-3" />
              256 位加密 · 支持 7 天无理由退款
            </p>
          </div>
        </div>

        <div className="mt-3 rounded-2xl border border-line bg-[#fffdf8] p-4">
          <p className="text-[11px] font-semibold text-ink">订阅说明</p>
          <ul className="mt-1.5 space-y-1 text-[10.5px] leading-relaxed text-ink/50">
            <li>· 试用期间不会自动扣款，需你主动确认购买。</li>
            <li>· 月度 / 年度会员默认开启自动续费，可随时关闭。</li>
            <li>· 关闭后权益保留至本期结束，学习记录永久保存。</li>
            <li>· 演示环境为模拟收银台，不会产生真实扣款。</li>
          </ul>
          {email && <p className="mt-2 text-[10px] text-ink/40">收据将发送至 {email}</p>}
        </div>
      </aside>

      {processing && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-forest/40 px-6 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl border border-line bg-[#fffdf8] p-6 text-center shadow-2xl">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-forest/10">
              <Loader className="h-5 w-5 animate-spin text-forest" />
            </div>
            <p className="mt-4 font-display text-xl">正在确认支付</p>
            <p className="mt-1 text-[11.5px] text-ink/50">
              请稍候，正在与 {PAYMENT_METHODS.find((item) => item.id === method)?.name} 完成交易…
            </p>
            <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-line/60">
              <div className="h-full w-2/3 animate-pulse rounded-full bg-forest" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
