"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, RefreshCcw, X } from "lucide-react";
import { cancelSubscriptionAction, resumeSubscriptionAction } from "@/app/actions";

export function SubscriptionActions({
  hasActivePaidPlan,
  planId,
  compact = false,
}: {
  hasActivePaidPlan: boolean;
  planId: string;
  compact?: boolean;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const run = (action: () => Promise<{ ok: boolean; message: string }>) => {
    startTransition(async () => {
      const result = await action();
      setMessage({ ok: result.ok, text: result.message });
      router.refresh();
    });
  };

  if (planId === "lifetime") {
    return (
      <p className="flex items-center gap-1.5 text-[11px] text-cream/60">
        <Check className="h-3.5 w-3.5 text-gold" />
        终身会员 · 无需续费
      </p>
    );
  }

  return (
    <div className={compact ? "space-y-2" : "space-y-2"}>
      <div className="flex flex-wrap gap-2">
        {hasActivePaidPlan ? (
          <button
            type="button"
            onClick={() => run(cancelSubscriptionAction)}
            disabled={pending}
            className="inline-flex items-center gap-1.5 rounded-full border border-cream/25 px-3 py-1.5 text-[11px] font-medium text-cream/80 transition-colors hover:bg-cream/10"
          >
            {pending ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}
            取消自动续费
          </button>
        ) : (
          <button
            type="button"
            onClick={() => run(resumeSubscriptionAction)}
            disabled={pending || planId === "trial"}
            className="inline-flex items-center gap-1.5 rounded-full border border-cream/25 px-3 py-1.5 text-[11px] font-medium text-cream/80 transition-colors hover:bg-cream/10 disabled:opacity-40"
          >
            {pending ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCcw className="h-3 w-3" />}
            恢复自动续费
          </button>
        )}
      </div>
      {message && (
        <p className={`text-[10.5px] ${message.ok ? "text-cream/60" : "text-[#f0b9a4]"}`}>
          {message.text}
        </p>
      )}
    </div>
  );
}
