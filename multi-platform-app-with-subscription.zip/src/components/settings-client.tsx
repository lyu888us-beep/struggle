"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Check,
  Clock,
  Loader2,
  MonitorSmartphone,
  PlayCircle,
  RotateCcw,
  ShieldCheck,
  X,
} from "lucide-react";
import {
  cancelSubscriptionAction,
  restartTrialAction,
  resumeSubscriptionAction,
  simulateTrialExpiryAction,
  updateProfileAction,
} from "@/app/actions";

type Props = {
  displayName: string;
  email: string | null;
  preferredDevice: string;
  autoRenew: boolean;
  planName: string;
  statusLabel: string;
  nextChargeNote: string;
  planId: string;
  hasActivePaidPlan: boolean;
  billingHref: string;
};

export function SettingsPanel({
  displayName,
  email,
  preferredDevice,
  autoRenew,
  planName,
  statusLabel,
  nextChargeNote,
  planId,
  hasActivePaidPlan,
  billingHref,
}: Props) {
  const router = useRouter();
  const [name, setName] = useState(displayName);
  const [mail, setMail] = useState(email ?? "");
  const [device, setDevice] = useState(preferredDevice === "mobile" ? "mobile" : "desktop");
  const [renew, setRenew] = useState(autoRenew);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);

  const run = (
    key: string,
    action: () => Promise<{ ok: boolean; message: string }>,
  ) => {
    setBusy(key);
    setMessage(null);
    startTransition(async () => {
      const result = await action();
      setMessage({ ok: result.ok, text: result.message });
      setBusy(null);
      router.refresh();
    });
  };

  const saveProfile = () => {
    run("profile", () =>
      updateProfileAction({ displayName: name, email: mail, preferredDevice: device, autoRenew: renew }),
    );
  };

  return (
    <div className="space-y-4">
      {message && (
        <div
          className={`flex items-start gap-2 rounded-xl border px-3.5 py-2.5 text-[11.5px] ${
            message.ok
              ? "border-forest/25 bg-forest/[0.05] text-forest"
              : "border-clay/30 bg-clay/[0.06] text-clay"
          }`}
        >
          {message.ok ? <Check className="mt-0.5 h-3.5 w-3.5" /> : <X className="mt-0.5 h-3.5 w-3.5" />}
          {message.text}
        </div>
      )}

      <section className="card p-5">
        <h2 className="font-display text-xl">学习档案</h2>
        <p className="mt-0.5 text-[11.5px] text-ink/45">
          档案与当前设备绑定，电脑端与手机端共享同一份学习数据。
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wider text-ink/45">
              昵称
            </span>
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={24}
              className="w-full rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5 text-[12.5px] outline-none focus:border-moss/60"
            />
          </label>
          <label className="block">
            <span className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wider text-ink/45">
              收据邮箱
            </span>
            <input
              value={mail}
              onChange={(event) => setMail(event.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5 text-[12.5px] outline-none focus:border-moss/60"
            />
          </label>
        </div>

        <div className="mt-4">
          <span className="mb-1.5 block text-[10.5px] font-semibold uppercase tracking-wider text-ink/45">
            默认打开版本
          </span>
          <div className="grid gap-2 sm:grid-cols-2">
            {(
              [
                ["desktop", "电脑端工作台", "大屏阅读、写作与测验"],
                ["mobile", "手机端随身学", "通勤复习与每日一句"],
              ] as const
            ).map(([value, label, hint]) => (
              <button
                key={value}
                type="button"
                onClick={() => setDevice(value)}
                className={`flex items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                  device === value
                    ? "border-forest bg-forest/[0.04]"
                    : "border-line bg-[#fffdf8] hover:border-moss/40"
                }`}
              >
                <MonitorSmartphone className="mt-0.5 h-4 w-4 text-moss" />
                <span>
                  <span className="block text-[12px] font-semibold text-ink">{label}</span>
                  <span className="block text-[10px] text-ink/45">{hint}</span>
                </span>
              </button>
            ))}
          </div>
        </div>

        <label className="mt-4 flex cursor-pointer items-center justify-between rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5">
          <span>
            <span className="block text-[12px] font-semibold text-ink">自动续费</span>
            <span className="block text-[10px] text-ink/45">{nextChargeNote}</span>
          </span>
          <input
            type="checkbox"
            checked={renew}
            onChange={(event) => setRenew(event.target.checked)}
            className="h-4 w-4 accent-[#1e3a2c]"
          />
        </label>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={saveProfile}
            disabled={pending}
            className="btn btn-primary text-[12px]"
          >
            {busy === "profile" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
            保存设置
          </button>
          <Link href={billingHref} className="btn btn-ghost text-[12px]">
            订阅与账单
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </section>

      <section className="card p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-xl">订阅管理</h2>
            <p className="mt-0.5 text-[11.5px] text-ink/45">
              {planName} · {statusLabel}
            </p>
          </div>
          <ShieldCheck className="h-5 w-5 text-moss/60" />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {hasActivePaidPlan ? (
            <button
              type="button"
              onClick={() => run("cancel", cancelSubscriptionAction)}
              disabled={pending}
              className="btn btn-ghost text-[12px]"
            >
              {busy === "cancel" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
              取消自动续费
            </button>
          ) : (
            <button
              type="button"
              onClick={() => run("resume", resumeSubscriptionAction)}
              disabled={pending || planId === "lifetime"}
              className="btn btn-ghost text-[12px]"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              恢复自动续费
            </button>
          )}
          <Link href="/checkout?plan=annual" className="btn btn-primary text-[12px]">
            续订 / 升级
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </section>

      <section className="rounded-[22px] border border-dashed border-line bg-parchment/30 p-5">
        <h2 className="flex items-center gap-2 font-display text-lg">
          <Clock className="h-4 w-4 text-clay" />
          演示工具 · 试用与付费墙
        </h2>
        <p className="mt-1 text-[11px] leading-relaxed text-ink/50">
          本项目按真实订阅产品实现：新用户自动获得 7 天试用，到期后课程与复习功能锁定。下面两个按钮用于快速演示两种状态。
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => run("expire", simulateTrialExpiryAction)}
            disabled={pending}
            className="btn btn-clay text-[12px]"
          >
            {busy === "expire" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
            模拟试用到期
          </button>
          <button
            type="button"
            onClick={() => run("restart", restartTrialAction)}
            disabled={pending}
            className="btn btn-ghost text-[12px]"
          >
            {busy === "restart" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
            重置 7 天试用
          </button>
        </div>
      </section>
    </div>
  );
}
