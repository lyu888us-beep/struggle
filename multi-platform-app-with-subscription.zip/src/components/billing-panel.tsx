import Link from "next/link";
import {
  ArrowRight,
  Check,
  CreditCard,
  Crown,
  Download,
  Receipt,
  ShieldCheck,
  Sparkles,
  Tag,
} from "lucide-react";
import type { Payment, User } from "@/db/schema";
import { formatDate, type Entitlement } from "@/lib/session";
import { PLANS, formatCNY, paymentMethodName } from "@/lib/plans";
import { PlanMiniCard, ProgressRing } from "@/components/ui";
import { SubscriptionActions } from "@/components/subscription-actions";

export function BillingPanel({
  user,
  entitlement,
  payments,
  compact = false,
}: {
  user: User;
  entitlement: Entitlement;
  payments: Payment[];
  compact?: boolean;
}) {
  const hasActivePaidPlan =
    (user.plan === "monthly" || user.plan === "annual") &&
    entitlement.state === "active" &&
    user.status === "active";
  const totalPaid = payments.reduce((sum, payment) => sum + payment.amountCents, 0);

  return (
    <div className="space-y-4">
      <div className="relative overflow-hidden rounded-[26px] border border-forest/20 bg-forest p-5 text-cream md:p-6">
        <div className="grain absolute inset-0 opacity-30" />
        <div className="absolute -right-10 -top-12 h-40 w-40 rounded-full bg-gold/15 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-cream/40">
              Current plan
            </p>
            <div className="mt-1.5 flex items-center gap-2">
              <h2 className="font-display text-2xl">{entitlement.planName}</h2>
              <span className="rounded-full border border-cream/25 bg-cream/10 px-2 py-0.5 text-[10px]">
                {entitlement.statusLabel}
              </span>
            </div>
            <p className="mt-1.5 max-w-sm text-[11.5px] leading-relaxed text-cream/55">
              {entitlement.nextChargeNote}
            </p>
            <div className="mt-3">
              <SubscriptionActions
                hasActivePaidPlan={hasActivePaidPlan}
                planId={user.plan}
                compact={compact}
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <ProgressRing
              percent={entitlement.state === "trialing" ? entitlement.trialProgress : 100}
              size={92}
            >
              <span className="font-display text-xl leading-none text-ink">
                {entitlement.state === "trialing"
                  ? entitlement.trialDaysLeft
                  : entitlement.state === "expired"
                    ? 0
                    : "∞"}
              </span>
              <span className="mt-0.5 block text-[9px] text-ink/40">
                {entitlement.state === "trialing" ? "天剩余" : entitlement.state === "expired" ? "已到期" : "会员有效"}
              </span>
            </ProgressRing>
            <div className="hidden text-[10.5px] text-cream/50 sm:block">
              <p className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-gold" />
                7 天无理由退款
              </p>
              <p className="mt-1 flex items-center gap-1.5">
                <CreditCard className="h-3.5 w-3.5 text-gold" />
                已支付 {formatCNY(totalPaid)}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        {PLANS.map((plan) => (
          <PlanMiniCard
            key={plan.id}
            planId={plan.id}
            current={user.plan === plan.id && entitlement.state !== "expired"}
            highlight={plan.highlight}
            href={`/checkout?plan=${plan.id}`}
          />
        ))}
      </div>

      <div className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/70 px-5 py-3.5">
          <h2 className="flex items-center gap-2 font-display text-lg">
            <Receipt className="h-4 w-4 text-moss" />
            账单与收据
          </h2>
          <span className="text-[10.5px] text-ink/40">
            共 {payments.length} 笔 · 合计 {formatCNY(totalPaid)}
          </span>
        </div>

        {payments.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <Receipt className="mx-auto h-6 w-6 text-ink/20" />
            <p className="mt-2 text-[12px] font-medium text-ink/60">还没有账单</p>
            <p className="mt-1 text-[11px] text-ink/40">
              试用结束前不会产生任何费用。订阅后可在此下载收据。
            </p>
            <Link href="/checkout?plan=annual" className="btn btn-primary mt-3 text-[11.5px]">
              查看会员方案
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        ) : (
          <>
            <div className="hidden grid-cols-[1.3fr_1fr_0.8fr_0.7fr_0.6fr] gap-2 border-b border-line/60 bg-parchment/25 px-5 py-2 text-[9.5px] font-semibold uppercase tracking-wider text-ink/35 md:grid">
              <span>订单号 / 方案</span>
              <span>周期</span>
              <span>支付方式</span>
              <span>金额</span>
              <span className="text-right">状态</span>
            </div>
            <div className="divide-y divide-line/60">
              {payments.map((payment) => (
                <div
                  key={payment.id}
                  className="grid gap-1 px-5 py-3 md:grid-cols-[1.3fr_1fr_0.8fr_0.7fr_0.6fr] md:items-center md:gap-2"
                >
                  <div>
                    <p className="font-mono text-[10.5px] text-ink/70">{payment.orderNo}</p>
                    <p className="text-[11px] font-medium text-ink">{payment.planName}</p>
                  </div>
                  <div className="text-[10.5px] text-ink/45">
                    <p>{formatDate(payment.createdAt)}</p>
                    <p className="text-ink/30">
                      {payment.periodEnd ? `至 ${formatDate(payment.periodEnd)}` : "永久"}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 text-[10.5px] text-ink/55">
                    {paymentMethodName(payment.method)}
                  </div>
                  <div>
                    <p className="text-[11.5px] font-semibold text-ink">{formatCNY(payment.amountCents)}</p>
                    {payment.discountCents > 0 && (
                      <p className="text-[9.5px] text-clay">
                        {payment.coupon} -{formatCNY(payment.discountCents)}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 md:justify-end">
                    <span className="rounded-full bg-forest/[0.07] px-2 py-0.5 text-[9.5px] font-semibold text-forest">
                      已支付
                    </span>
                    <Link
                      href={`/checkout/success?order=${payment.orderNo}`}
                      className="text-[9.5px] text-moss underline-offset-2 hover:underline"
                    >
                      收据
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="card-quiet p-4">
          <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
            <Tag className="h-3.5 w-3.5 text-clay" />
            优惠码
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-ink/50">
            结账时输入 <span className="font-semibold text-ink">NUANCE30</span> 享 7 折，
            <span className="font-semibold text-ink"> WELCOME15</span> 享 85 折。优惠券不可叠加。
          </p>
        </div>
        <div className="card-quiet p-4">
          <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
            <Sparkles className="h-3.5 w-3.5 text-gold" />
            退款与规则
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-ink/50">
            开通 7 天内可申请全额退款；取消自动续费后权益保留至本期结束，学习记录永久保存。
          </p>
        </div>
      </div>

      {!compact && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-line bg-[#fffdf8] px-4 py-3">
          <p className="flex items-center gap-1.5 text-[11px] text-ink/50">
            <Crown className="h-3.5 w-3.5 text-gold" />
            订阅同时解锁电脑端与手机端，无需重复购买。
          </p>
          <div className="flex items-center gap-3 text-[10.5px] text-ink/40">
            <span className="flex items-center gap-1">
              <Check className="h-3 w-3 text-forest" /> 双端同步
            </span>
            <span className="flex items-center gap-1">
              <Download className="h-3 w-3 text-forest" /> 可下载收据
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
