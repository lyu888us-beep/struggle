import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRight, Check, Crown, Lock, Sparkles } from "lucide-react";
import type { Entitlement } from "@/lib/session";
import { PLANS, formatCNY, type PlanId } from "@/lib/plans";

export function Logo({
  tone = "dark",
  href = "/",
  compact = false,
}: {
  tone?: "dark" | "light";
  href?: string;
  compact?: boolean;
}) {
  return (
    <Link href={href} className="group flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-[12px] bg-forest font-display text-lg text-cream shadow-sm transition-transform group-hover:-rotate-3">
        N
      </span>
      {!compact && (
        <span className="leading-none">
          <span
            className={`block font-display text-[17px] ${tone === "light" ? "text-cream" : "text-ink"}`}
          >
            Nuance
          </span>
          <span
            className={`mt-1 block text-[9px] tracking-[0.34em] ${
              tone === "light" ? "text-cream/60" : "text-moss/70"
            }`}
          >
            细 语 英 语
          </span>
        </span>
      )}
    </Link>
  );
}

export function ProgressBar({
  value,
  tone = "forest",
  className = "",
}: {
  value: number;
  tone?: "forest" | "clay" | "gold" | "cream";
  className?: string;
}) {
  const colors: Record<string, string> = {
    forest: "bg-forest",
    clay: "bg-clay",
    gold: "bg-gold",
    cream: "bg-cream",
  };
  return (
    <div className={`h-1.5 w-full overflow-hidden rounded-full bg-line/60 ${className}`}>
      <div
        className={`h-full rounded-full transition-all duration-500 ${colors[tone]}`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export function ProgressRing({
  percent,
  size = 96,
  children,
}: {
  percent: number;
  size?: number;
  children?: ReactNode;
}) {
  return (
    <div
      className="ring-progress grid shrink-0 place-items-center rounded-full"
      style={
        {
          width: size,
          height: size,
          "--ring": `${Math.max(0, Math.min(100, percent))}%`,
        } as React.CSSProperties
      }
    >
      <div
        className="grid place-items-center rounded-full bg-[#fffdf8] text-center"
        style={{ width: size - 14, height: size - 14 }}
      >
        {children}
      </div>
    </div>
  );
}

export function StatusPill({ entitlement }: { entitlement: Entitlement }) {
  const tone =
    entitlement.state === "trialing"
      ? "border-clay/30 bg-clay/10 text-clay"
      : entitlement.state === "expired"
        ? "border-ink/20 bg-ink/5 text-ink/70"
        : "border-forest/20 bg-forest/10 text-forest";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${tone}`}
    >
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-current opacity-60" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-current" />
      </span>
      {entitlement.statusLabel}
    </span>
  );
}

export function TrialMeter({ entitlement }: { entitlement: Entitlement }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-[11px] font-medium text-moss">
        <span>7 天免费试用进度</span>
        <span>{entitlement.trialProgress}%</span>
      </div>
      <ProgressBar value={entitlement.trialProgress} tone="clay" />
      <p className="text-[11px] text-ink/50">{entitlement.trialNote}</p>
    </div>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="card-quiet flex items-center gap-3 px-4 py-3.5">
      {icon && (
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-parchment/70 text-forest">
          {icon}
        </span>
      )}
      <div className="min-w-0">
        <p className="text-[11px] font-medium tracking-wide text-ink/45">{label}</p>
        <p className="font-display text-xl leading-tight text-ink">{value}</p>
        {hint && <p className="truncate text-[10px] text-ink/40">{hint}</p>}
      </div>
    </div>
  );
}

export function PlanMiniCard({
  planId,
  current,
  href,
  highlight,
}: {
  planId: PlanId;
  current?: boolean;
  href: string;
  highlight?: boolean;
}) {
  const plan = PLANS.find((item) => item.id === planId);
  if (!plan) return null;
  return (
    <div
      className={`relative flex flex-col rounded-2xl border p-4 ${
        highlight ? "border-forest bg-forest text-cream" : "border-line bg-[#fffdf8]"
      }`}
    >
      {plan.badge && (
        <span className="absolute -top-2.5 right-4 rounded-full bg-clay px-2 py-0.5 text-[10px] font-semibold text-white">
          {plan.badge}
        </span>
      )}
      {current && (
        <span
          className={`absolute -top-2.5 left-4 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
            highlight ? "bg-cream text-forest" : "bg-forest text-cream"
          }`}
        >
          当前方案
        </span>
      )}
      <div className="flex items-baseline justify-between">
        <p className={`text-sm font-semibold ${highlight ? "text-cream" : "text-ink"}`}>
          {plan.name}
        </p>
        <p className={`font-display text-lg ${highlight ? "text-cream" : "text-ink"}`}>
          {formatCNY(plan.priceCents)}
          <span className={`text-[11px] ${highlight ? "text-cream/60" : "text-ink/40"}`}>
            {plan.per}
          </span>
        </p>
      </div>
      <p className={`mt-0.5 text-[11px] ${highlight ? "text-cream/60" : "text-ink/45"}`}>
        {plan.tagline}
      </p>
      <ul className="mt-3 flex-1 space-y-1.5">
        {plan.features.slice(0, 3).map((feature) => (
          <li
            key={feature}
            className={`flex items-start gap-1.5 text-[11px] ${
              highlight ? "text-cream/80" : "text-ink/65"
            }`}
          >
            <Check className="mt-0.5 h-3 w-3 shrink-0" />
            {feature}
          </li>
        ))}
      </ul>
      <Link
        href={href}
        className={`btn mt-4 w-full justify-center text-[12px] ${
          highlight ? "bg-cream text-forest hover:bg-white" : "btn-ghost"
        }`}
      >
        选择{plan.name}
        <ArrowRight className="h-3.5 w-3.5" />
      </Link>
    </div>
  );
}

export function AccessLocked({
  title = "7 天试用已结束",
  description = "你的学习记录都被安全保存。订阅任意方案，即可继续全部课程、复习卡与语音评估。",
  compact = false,
}: {
  title?: string;
  description?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-[28px] border border-forest/15 bg-forest text-cream ${
        compact ? "p-5" : "p-7 md:p-9"
      }`}
    >
      <div className="grain absolute inset-0 opacity-30" />
      <div className="relative">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-cream/20 bg-cream/10 px-2.5 py-1 text-[11px] font-medium">
          <Lock className="h-3 w-3" />
          试用已结束 · 内容已锁定
        </span>
        <h3 className={`mt-3 font-display ${compact ? "text-2xl" : "text-3xl md:text-4xl"}`}>
          {title}
        </h3>
        <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-cream/70">{description}</p>
        <div className="mt-5 grid gap-2.5 sm:grid-cols-3">
          {PLANS.map((plan) => (
            <Link
              key={plan.id}
              href={`/checkout?plan=${plan.id}`}
              className={`group flex flex-col rounded-2xl border p-3.5 transition-all ${
                plan.highlight
                  ? "border-gold/60 bg-cream/10 hover:bg-cream/15"
                  : "border-cream/15 hover:border-cream/35 hover:bg-cream/5"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[12px] font-semibold">{plan.name}</span>
                {plan.highlight && <Crown className="h-3.5 w-3.5 text-gold" />}
              </div>
              <span className="mt-1 font-display text-xl">
                {formatCNY(plan.priceCents)}
                <span className="text-[10px] text-cream/50"> {plan.per}</span>
              </span>
              <span className="mt-1 flex items-center gap-1 text-[10px] text-cream/55">
                立即开通 <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-cream/50">
          <Sparkles className="h-3 w-3 text-gold" />
          结账时可使用优惠码 <span className="font-semibold text-cream/80">NUANCE30</span> 立减 30%
        </p>
      </div>
    </div>
  );
}

export function DeviceLinks({ current }: { current?: "desktop" | "mobile" }) {
  return (
    <div className="flex items-center gap-1.5 rounded-full border border-line bg-[#fffdf8] p-1">
      <Link
        href="/desktop"
        className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${
          current === "desktop" ? "bg-forest text-cream" : "text-ink/60 hover:text-ink"
        }`}
      >
        电脑端
      </Link>
      <Link
        href="/mobile"
        className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition-colors ${
          current === "mobile" ? "bg-forest text-cream" : "text-ink/60 hover:text-ink"
        }`}
      >
        手机端
      </Link>
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-moss/70">
      <span className="h-px w-6 bg-clay/60" />
      {children}
    </p>
  );
}
