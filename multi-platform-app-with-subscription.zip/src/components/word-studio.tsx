"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Check,
  ChevronDown,
  Eye,
  Loader2,
  RotateCcw,
  Search,
  Sparkles,
} from "lucide-react";
import { reviewWordAction } from "@/app/actions";
import { SaveWordButton, SpeakButton } from "./learning-client";
import type { WordItem } from "@/lib/data";

type Props = {
  items: WordItem[];
  canAccess: boolean;
  compact?: boolean;
};

const statusLabels: Record<string, string> = {
  learning: "学习中",
  review: "待复习",
  mastered: "已掌握",
};

export function WordStudio({ items, canAccess, compact = false }: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [tab, setTab] = useState<"review" | "bank">("review");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "saved" | "mastered" | "new">("all");
  const [revealed, setRevealed] = useState(false);
  const [index, setIndex] = useState(0);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [celebrate, setCelebrate] = useState<string | null>(null);

  const dueItems = useMemo(
    () => items.filter((item) => item.progress && item.progress.status !== "mastered"),
    [items],
  );

  const current = dueItems[index % Math.max(1, dueItems.length)] ?? null;

  const visibleItems = useMemo(() => {
    const lowered = query.trim().toLowerCase();
    return items.filter((item) => {
      const matchesQuery =
        lowered.length === 0 ||
        item.word.word.toLowerCase().includes(lowered) ||
        item.word.meaningZh.includes(lowered);
      const matchesFilter =
        filter === "all" ||
        (filter === "saved" && Boolean(item.progress)) ||
        (filter === "mastered" && item.progress?.status === "mastered") ||
        (filter === "new" && !item.progress);
      return matchesQuery && matchesFilter;
    });
  }, [items, query, filter]);

  const review = (status: "review" | "mastered") => {
    if (!current) return;
    startTransition(async () => {
      const result = await reviewWordAction(current.word.id, status);
      if (!result.ok) return;
      setCelebrate(status === "mastered" ? "已标记为掌握 🎉" : "已排入下轮复习");
      setRevealed(false);
      setIndex((value) => value + 1);
      router.refresh();
      window.setTimeout(() => setCelebrate(null), 2200);
    });
  };

  const savedCount = items.filter((item) => item.progress).length;
  const masteredCount = items.filter((item) => item.progress?.status === "mastered").length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 rounded-full border border-line bg-[#fffdf8] p-1">
          {(
            [
              ["review", `复习卡 ${dueItems.length}`],
              ["bank", `词汇本 ${savedCount}`],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`rounded-full px-3.5 py-1.5 text-[12px] font-semibold transition-colors ${
                tab === key ? "bg-forest text-cream" : "text-ink/55 hover:text-ink"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3 text-[11px] text-ink/50">
          <span>已收藏 {savedCount}</span>
          <span className="h-3 w-px bg-line" />
          <span>已掌握 {masteredCount}</span>
        </div>
      </div>

      {tab === "review" ? (
        <div className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
          <div className="relative overflow-hidden rounded-[26px] border border-forest/20 bg-forest p-6 text-cream">
            <div className="grain absolute inset-0 opacity-30" />
            <div className="relative">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-cream/20 bg-cream/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em]">
                  间隔复习 · SRS
                </span>
                <span className="text-[11px] text-cream/55">
                  {dueItems.length === 0 ? "0 张待复习" : `${(index % dueItems.length) + 1} / ${dueItems.length}`}
                </span>
              </div>

              {!canAccess ? (
                <div className="py-12 text-center">
                  <p className="font-display text-2xl">试用已结束</p>
                  <p className="mx-auto mt-2 max-w-xs text-[12px] text-cream/60">
                    订阅后可继续每日复习卡，学习数据不会丢失。
                  </p>
                  <a href="/checkout?plan=annual" className="btn btn-clay mt-4 text-[12px]">
                    立即订阅
                    <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                </div>
              ) : current ? (
                <div className="py-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-4xl leading-tight md:text-5xl">{current.word.word}</p>
                      <p className="mt-1.5 flex items-center gap-2 text-[12px] text-cream/55">
                        {current.word.phonetic}
                        <span className="rounded-full border border-cream/20 px-1.5 py-0.5 text-[9px]">
                          {current.word.partOfSpeech}
                        </span>
                        <span className="rounded-full border border-cream/20 px-1.5 py-0.5 text-[9px]">
                          {current.word.level}
                        </span>
                      </p>
                    </div>
                    <SpeakButton text={current.word.exampleEn} tone="light" label="例句" />
                  </div>

                  {revealed ? (
                    <div className="animate-rise mt-5 space-y-3">
                      <p className="text-[15px] font-medium text-cream">{current.word.meaningZh}</p>
                      <p className="rounded-xl border border-cream/15 bg-cream/5 p-3 text-[12px] leading-relaxed text-cream/75">
                        {current.word.nuance}
                      </p>
                      <div className="rounded-xl border border-cream/15 bg-cream/[0.07] p-3">
                        <p className="text-[12.5px] italic leading-relaxed text-cream/90">
                          {current.word.exampleEn}
                        </p>
                        <p className="mt-1 text-[11px] text-cream/50">{current.word.exampleZh}</p>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setRevealed(true)}
                      className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-cream/25 py-8 text-[12px] text-cream/60 transition-colors hover:border-cream/50 hover:text-cream"
                    >
                      <Eye className="h-4 w-4" />
                      先自己回忆，再点击查看释义
                    </button>
                  )}

                  <div className="mt-5 flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={pending || !revealed}
                      onClick={() => review("review")}
                      className="btn flex-1 border border-cream/25 bg-transparent text-[12px] text-cream hover:bg-cream/10 disabled:opacity-40"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      还不熟
                    </button>
                    <button
                      type="button"
                      disabled={pending || !revealed}
                      onClick={() => review("mastered")}
                      className="btn flex-1 bg-cream text-[12px] text-forest hover:bg-white disabled:opacity-40"
                    >
                      {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                      已掌握
                    </button>
                  </div>
                  {celebrate && (
                    <p className="mt-3 flex items-center gap-1.5 text-[11px] text-gold">
                      <Sparkles className="h-3.5 w-3.5" />
                      {celebrate}
                    </p>
                  )}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <p className="font-display text-2xl">
                    {savedCount === 0 ? "词汇本还是空的" : "今日复习完成 🎉"}
                  </p>
                  <p className="mx-auto mt-2 max-w-xs text-[12px] leading-relaxed text-cream/60">
                    {savedCount === 0
                      ? "在课程正文或右侧词汇本中收藏生词，系统会按间隔重复安排复习。"
                      : "继续到词汇本收藏新词，明天会有新的复习卡。"}
                  </p>
                  <button
                    type="button"
                    onClick={() => setTab("bank")}
                    className="btn mt-4 bg-cream text-[12px] text-forest hover:bg-white"
                  >
                    去词汇本
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="card p-5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-moss/60">今日安排</p>
            <h3 className="mt-1 font-display text-xl">复习队列</h3>
            <p className="mt-1 text-[11.5px] text-ink/50">
              掌握度越高，下次出现越晚。这是记忆曲线在替你安排时间。
            </p>
            <div className="mt-4 space-y-2">
              {dueItems.slice(0, 6).map((item, itemIndex) => (
                <button
                  key={item.word.id}
                  type="button"
                  onClick={() => {
                    setIndex(itemIndex);
                    setRevealed(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-xl border px-3 py-2 text-left transition-colors ${
                    itemIndex === index % Math.max(1, dueItems.length)
                      ? "border-forest/30 bg-forest/[0.05]"
                      : "border-line bg-[#fffdf8] hover:border-moss/40"
                  }`}
                >
                  <span>
                    <span className="block text-[12.5px] font-medium text-ink">{item.word.word}</span>
                    <span className="block text-[10px] text-ink/45">{item.word.meaningZh}</span>
                  </span>
                  <span className="text-[10px] text-moss/70">
                    {statusLabels[item.progress?.status ?? "learning"]}
                  </span>
                </button>
              ))}
              {dueItems.length === 0 && (
                <p className="rounded-xl border border-dashed border-line px-3 py-6 text-center text-[11.5px] text-ink/40">
                  暂无待复习词汇
                </p>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-line/70 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink/35" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="搜索单词或中文释义"
                className="w-full rounded-full border border-line bg-[#fffdf8] py-2 pl-9 pr-3 text-[12px] outline-none transition-colors placeholder:text-ink/35 focus:border-moss/60"
              />
            </div>
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
              {(
                [
                  ["all", "全部"],
                  ["saved", "已收藏"],
                  ["mastered", "已掌握"],
                  ["new", "未收藏"],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setFilter(key)}
                  className={`shrink-0 rounded-full border px-3 py-1.5 text-[11px] font-medium transition-colors ${
                    filter === key
                      ? "border-forest bg-forest text-cream"
                      : "border-line bg-[#fffdf8] text-ink/55 hover:border-moss/40"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-line/60">
            {visibleItems.map((item) => {
              const isOpen = expanded === item.word.id;
              return (
                <div key={item.word.id} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => setExpanded(isOpen ? null : item.word.id)}
                      className="flex flex-1 items-start gap-3 text-left"
                    >
                      <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-parchment/70 font-display text-[11px] text-forest">
                        {item.word.word.slice(0, 1).toUpperCase()}
                      </span>
                      <span className="min-w-0">
                        <span className="flex flex-wrap items-baseline gap-2">
                          <span className="text-[13.5px] font-semibold text-ink">{item.word.word}</span>
                          <span className="text-[10.5px] text-ink/40">{item.word.phonetic}</span>
                          {item.progress && (
                            <span
                              className={`rounded-full px-1.5 py-0.5 text-[9px] font-semibold ${
                                item.progress.status === "mastered"
                                  ? "bg-forest/10 text-forest"
                                  : "bg-clay/10 text-clay"
                              }`}
                            >
                              {statusLabels[item.progress.status]}
                            </span>
                          )}
                        </span>
                        <span className="mt-0.5 block truncate text-[11.5px] text-ink/55">
                          {item.word.meaningZh}
                        </span>
                        {isOpen && (
                          <span className="animate-rise mt-2 block space-y-1.5">
                            <span className="block rounded-lg bg-parchment/45 px-2.5 py-2 text-[11px] leading-relaxed text-ink/70">
                              {item.word.nuance}
                            </span>
                            <span className="block border-l-2 border-gold/60 pl-2.5 text-[11.5px] italic leading-relaxed text-ink/70">
                              {item.word.exampleEn}
                            </span>
                            <span className="block pl-2.5 text-[10.5px] text-ink/45">
                              {item.word.exampleZh}
                            </span>
                          </span>
                        )}
                      </span>
                    </button>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <SpeakButton text={item.word.word} label="" />
                      <SaveWordButton wordId={item.word.id} saved={Boolean(item.progress)} compact />
                      <ChevronDown
                        className={`h-3.5 w-3.5 text-ink/30 transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
            {visibleItems.length === 0 && (
              <p className="px-4 py-10 text-center text-[12px] text-ink/40">没有符合条件的词汇</p>
            )}
          </div>
          {compact && (
            <p className="border-t border-line/60 px-4 py-3 text-[10.5px] text-ink/40">
              共 {items.length} 个高阶词汇 · 数据与电脑端实时同步
            </p>
          )}
        </div>
      )}
    </div>
  );
}
