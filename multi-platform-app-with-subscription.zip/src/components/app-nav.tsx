"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BookOpen,
  CreditCard,
  GraduationCap,
  Home,
  Library,
  Settings,
  Sparkles,
  UserRound,
} from "lucide-react";

const desktopItems = [
  { href: "/desktop", label: "学习台", icon: Home, exact: true },
  { href: "/desktop/courses", label: "课程库", icon: Library },
  { href: "/desktop/vocab", label: "词汇本", icon: BookOpen },
  { href: "/desktop/billing", label: "订阅与账单", icon: CreditCard },
  { href: "/desktop/settings", label: "设置", icon: Settings },
];

const mobileItems = [
  { href: "/mobile", label: "首页", icon: Home, exact: true },
  { href: "/mobile/courses", label: "课程", icon: GraduationCap },
  { href: "/mobile/vocab", label: "词汇", icon: BookOpen },
  { href: "/mobile/me", label: "我的", icon: UserRound },
];

export function DesktopNav() {
  const pathname = usePathname();
  return (
    <nav className="space-y-1">
      {desktopItems.map((item) => {
        const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`group flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[12.5px] font-medium transition-all ${
              active
                ? "bg-cream/12 text-cream shadow-sm"
                : "text-cream/55 hover:bg-cream/5 hover:text-cream/85"
            }`}
          >
            <item.icon className={`h-4 w-4 ${active ? "text-gold" : "text-cream/40 group-hover:text-cream/70"}`} />
            {item.label}
            {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-gold" />}
          </Link>
        );
      })}
    </nav>
  );
}

export function MobileTabBar() {
  const pathname = usePathname();
  return (
    <nav className="shrink-0 border-t border-line/80 bg-[#fffdf8]/95 px-2 pb-[max(env(safe-area-inset-bottom),0.4rem)] pt-1.5 backdrop-blur">
      <div className="grid grid-cols-4">
        {mobileItems.map((item) => {
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`relative flex flex-col items-center gap-1 rounded-xl py-1.5 transition-colors ${
                active ? "text-forest" : "text-ink/40"
              }`}
            >
              <span
                className={`grid h-8 w-11 place-items-center rounded-full transition-colors ${
                  active ? "bg-forest/10" : ""
                }`}
              >
                <item.icon className={`h-[18px] w-[18px] ${active ? "stroke-[2.2]" : ""}`} />
              </span>
              <span className={`text-[10px] ${active ? "font-semibold" : ""}`}>{item.label}</span>
              {active && <span className="absolute -top-1.5 h-1 w-6 rounded-full bg-clay" />}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function UpgradeLink({ compact = false }: { compact?: boolean }) {
  return (
    <Link
      href="/checkout?plan=annual"
      className={`${compact ? "" : "btn"} flex items-center justify-center gap-1.5 rounded-full bg-gradient-to-r from-gold to-[#dcc084] px-3 py-2 text-[11.5px] font-semibold text-[#2a1f08] transition-transform hover:-translate-y-0.5`}
    >
      <Sparkles className="h-3.5 w-3.5" />
      升级会员
    </Link>
  );
}
