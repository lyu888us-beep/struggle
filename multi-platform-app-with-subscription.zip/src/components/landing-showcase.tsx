"use client";

import { useState } from "react";
import { Flame, Monitor, Smartphone, Sparkles, Volume2 } from "lucide-react";

export function LandingShowcase() {
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");

  return (
    <div className="relative">
      <div className="relative overflow-hidden rounded-[32px] border border-forest/25 bg-forest p-4 shadow-[0_40px_80px_-50px_rgba(21,34,27,0.8)] sm:p-6">
        <div className="grain absolute inset-0 opacity-30" />
        <div className="absolute -left-16 -top-16 h-48 w-48 rounded-full bg-gold/15 blur-3xl" />
        <div className="absolute -bottom-20 right-0 h-56 w-56 rounded-full bg-clay/20 blur-3xl" />

        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-cream/25" />
            <span className="h-2 w-2 rounded-full bg-cream/20" />
            <span className="h-2 w-2 rounded-full bg-cream/15" />
          </div>
          <div className="flex items-center gap-1 rounded-full border border-cream/15 bg-cream/[0.06] p-0.5">
            <button
              type="button"
              onClick={() => setDevice("desktop")}
              className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold transition-colors ${
                device === "desktop" ? "bg-cream text-forest" : "text-cream/60 hover:text-cream"
              }`}
            >
              <Monitor className="h-3 w-3" />
              桌面版
            </button>
            <button
              type="button"
              onClick={() => setDevice("mobile")}
              className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold transition-colors ${
                device === "mobile" ? "bg-cream text-forest" : "text-cream/60 hover:text-cream"
              }`}
            >
              <Smartphone className="h-3 w-3" />
              手机版
            </button>
          </div>
        </div>

        {/* Desktop mock */}
        <div
          className={`relative mt-4 transition-all duration-500 ${
            device === "desktop" ? "scale-100 opacity-100" : "scale-[0.97] opacity-45"
          }`}
        >
          <div className="overflow-hidden rounded-2xl border border-cream/15 bg-[#fffdf8] shadow-xl">
            <div className="flex items-center gap-2 border-b border-line/70 bg-parchment/50 px-3 py-2">
              <div className="flex gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-clay/60" />
                <span className="h-1.5 w-1.5 rounded-full bg-gold/70" />
                <span className="h-1.5 w-1.5 rounded-full bg-moss/40" />
              </div>
              <div className="mx-auto rounded-full border border-line bg-white px-3 py-0.5 text-[7px] text-ink/40">
                nuance.study / desktop
              </div>
            </div>
            <div className="flex">
              <div className="hidden w-[78px] shrink-0 flex-col bg-forest p-2.5 sm:flex">
                <div className="flex items-center gap-1.5">
                  <span className="grid h-4 w-4 place-items-center rounded bg-cream/15 font-display text-[7px] text-cream">
                    N
                  </span>
                  <span className="text-[7px] font-semibold text-cream">Nuance</span>
                </div>
                <div className="mt-3 space-y-1">
                  {["学习台", "课程库", "词汇本", "订阅"].map((item, index) => (
                    <div
                      key={item}
                      className={`rounded px-1.5 py-1 text-[6.5px] ${
                        index === 0 ? "bg-cream/15 text-cream" : "text-cream/45"
                      }`}
                    >
                      {item}
                    </div>
                  ))}
                </div>
                <div className="mt-auto rounded-lg border border-gold/30 bg-gold/10 p-1.5">
                  <p className="text-[6px] font-semibold text-gold">试用剩余 5 天</p>
                  <div className="mt-1 h-0.5 overflow-hidden rounded-full bg-cream/15">
                    <div className="h-full w-2/3 rounded-full bg-gold" />
                  </div>
                </div>
              </div>
              <div className="flex-1 space-y-2 bg-[#f7f2e7] p-3">
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-[6px] uppercase tracking-[0.2em] text-moss/60">Wednesday, 08:40</p>
                    <p className="font-display text-[12px] leading-tight text-ink">早上好，继续昨天的那一课</p>
                  </div>
                  <div className="rounded-full border border-line bg-white px-1.5 py-0.5 text-[6px] text-ink/50">
                    🔥 连续 12 天
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    ["已完成", "18"],
                    ["词汇", "246"],
                    ["本周 XP", "420"],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-lg border border-line bg-white px-1.5 py-1">
                      <p className="text-[5.5px] text-ink/40">{label}</p>
                      <p className="font-display text-[10px] text-ink">{value}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-xl border border-line bg-white p-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[6px] text-clay">继续学习 · C1 词汇</p>
                      <p className="font-display text-[9px] text-ink">Plausible, Possible, Probable</p>
                      <p className="text-[5.5px] text-ink/40">三种「可能」，三种立场 · 14 分钟</p>
                    </div>
                    <span className="rounded-full bg-forest px-2 py-1 text-[6px] font-semibold text-cream">
                      继续 →
                    </span>
                  </div>
                  <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-line/60">
                    <div className="h-full w-[38%] rounded-full bg-clay" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div className="rounded-xl border border-line bg-white p-2">
                    <p className="text-[5.5px] text-ink/40">每日一词</p>
                    <div className="flex items-center gap-1">
                      <p className="font-display text-[10px] text-ink">nuance</p>
                      <Volume2 className="h-2 w-2 text-moss" />
                    </div>
                    <p className="text-[5.5px] text-ink/45">细微差别；语气层次</p>
                  </div>
                  <div className="rounded-xl border border-line bg-white p-2">
                    <p className="text-[5.5px] text-ink/40">课程进度</p>
                    {["词义的边界", "论证的骨架", "会议室英语"].map((course, index) => (
                      <div key={course} className="mt-1">
                        <div className="flex justify-between text-[5px] text-ink/50">
                          <span>{course}</span>
                          <span>{[72, 45, 18][index]}%</span>
                        </div>
                        <div className="mt-0.5 h-0.5 overflow-hidden rounded-full bg-line/70">
                          <div
                            className="h-full rounded-full bg-forest"
                            style={{ width: `${[72, 45, 18][index]}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Phone mock */}
        <div
          className={`absolute bottom-3 right-4 w-[34%] max-w-[168px] transition-all duration-500 ${
            device === "mobile"
              ? "translate-y-0 rotate-0 scale-105 opacity-100"
              : "translate-y-3 -rotate-3 scale-95 opacity-95"
          }`}
        >
          <div className="overflow-hidden rounded-[22px] border-[3px] border-[#0f1a14] bg-[#f7f2e7] shadow-2xl">
            <div className="relative bg-[#fffdf8] px-2 pb-1.5 pt-1">
              <div className="mx-auto h-1 w-8 rounded-full bg-ink/20" />
              <div className="mt-2 flex items-center justify-between">
                <div>
                  <p className="text-[5px] text-ink/40">晚上好，Lina</p>
                  <p className="font-display text-[8px] text-ink">今日一句</p>
                </div>
                <span className="grid h-3.5 w-3.5 place-items-center rounded-full bg-forest text-[5px] text-cream">
                  L
                </span>
              </div>
            </div>
            <div className="space-y-1.5 p-1.5">
              <div className="relative overflow-hidden rounded-xl bg-forest p-2 text-cream">
                <div className="grain absolute inset-0 opacity-30" />
                <p className="relative text-[5px] uppercase tracking-[0.15em] text-cream/50">
                  Quote of the day
                </p>
                <p className="relative mt-0.5 font-display text-[8px] leading-snug">
                  Fluency is knowing what to say. Sophistication is knowing how much to leave out.
                </p>
                <div className="relative mt-1 flex items-center gap-1">
                  <span className="rounded-full border border-cream/25 px-1 py-0.5 text-[4.5px]">
                    ▶ 朗读
                  </span>
                  <span className="rounded-full bg-clay/80 px-1 py-0.5 text-[4.5px]">加入词汇本</span>
                </div>
              </div>
              <div className="rounded-xl border border-line bg-white p-1.5">
                <div className="flex items-center justify-between">
                  <p className="text-[5px] text-clay">继续学习</p>
                  <Sparkles className="h-1.5 w-1.5 text-gold" />
                </div>
                <p className="font-display text-[7px] text-ink">Understatement &amp; Hedging</p>
                <div className="mt-1 h-0.5 overflow-hidden rounded-full bg-line/70">
                  <div className="h-full w-1/2 rounded-full bg-clay" />
                </div>
              </div>
              <div className="rounded-xl border border-line bg-white p-1.5">
                <p className="text-[5px] text-ink/40">今日复习 · 4 张卡</p>
                <div className="mt-0.5 flex items-baseline gap-1">
                  <p className="font-display text-[8px] text-ink">reticent</p>
                  <span className="text-[4.5px] text-ink/40">C2</span>
                </div>
                <p className="text-[5px] text-ink/55">寡言的，不愿多说的</p>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-clay/30 bg-clay/[0.07] p-1.5">
                <p className="text-[5px] text-clay">试用剩余 5 天</p>
                <span className="rounded-full bg-clay px-1 py-0.5 text-[4.5px] text-white">升级</span>
              </div>
              <div className="flex items-center justify-around rounded-lg border border-line bg-white py-1 text-[4.5px] text-ink/40">
                <span className="flex flex-col items-center gap-0.5 text-forest">
                  <span className="h-1 w-1 rounded-full bg-forest" />
                  首页
                </span>
                <span>课程</span>
                <span>词汇</span>
                <span>我的</span>
              </div>
            </div>
          </div>
        </div>

        <div className="relative mt-4 flex items-center justify-between rounded-xl border border-cream/15 bg-cream/[0.06] px-3 py-2">
          <p className="text-[10px] text-cream/60">
            同一份学习档案 · <span className="text-cream">自动同步</span>
          </p>
          <p className="flex items-center gap-1 text-[10px] text-cream/50">
            <Flame className="h-3 w-3 text-gold" />
            连续学习会累积
          </p>
        </div>
      </div>
    </div>
  );
}
