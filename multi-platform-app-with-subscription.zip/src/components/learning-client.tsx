"use client";

import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  Check,
  Loader2,
  Lock,
  RotateCcw,
  Sparkles,
  Volume2,
  X,
} from "lucide-react";
import { completeLessonAction, toggleSavedWordAction } from "@/app/actions";
import type { QuizQuestion } from "@/db/schema";

export function SpeakButton({
  text,
  label = "朗读",
  tone = "dark",
}: {
  text: string;
  label?: string;
  tone?: "dark" | "light";
}) {
  const [speaking, setSpeaking] = useState(false);

  const speak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.rate = 0.92;
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <button
      type="button"
      onClick={speak}
      aria-label={label}
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
        tone === "light"
          ? "border-cream/25 bg-cream/10 text-cream hover:bg-cream/20"
          : "border-line bg-[#fffdf8] text-moss hover:border-moss/50 hover:text-forest"
      }`}
    >
      <Volume2 className={`h-3.5 w-3.5 ${speaking ? "animate-pulse text-clay" : ""}`} />
      {label}
    </button>
  );
}

export function SaveWordButton({
  wordId,
  saved,
  compact = false,
}: {
  wordId: number;
  saved: boolean;
  compact?: boolean;
}) {
  const router = useRouter();
  const [isSaved, setIsSaved] = useState(saved);
  const [pending, startTransition] = useTransition();

  const toggle = () => {
    startTransition(async () => {
      const result = await toggleSavedWordAction(wordId);
      if (result.ok) {
        setIsSaved(result.saved);
        router.refresh();
      }
    });
  };

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
        isSaved
          ? "border-forest/25 bg-forest/10 text-forest"
          : "border-line bg-[#fffdf8] text-ink/50 hover:border-forest/30 hover:text-forest"
      }`}
    >
      {pending ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : isSaved ? (
        <BookmarkCheck className="h-3.5 w-3.5" />
      ) : (
        <Bookmark className="h-3.5 w-3.5" />
      )}
      {!compact && (isSaved ? "已收藏" : "加入词汇本")}
    </button>
  );
}

export function LessonQuiz({
  lessonId,
  questions,
  canAccess,
  nextLesson,
  basePath,
}: {
  lessonId: number;
  questions: QuizQuestion[];
  canAccess: boolean;
  nextLesson: { slug: string; title: string } | null;
  basePath: string;
}) {
  const router = useRouter();
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const answeredCount = Object.keys(answers).length;
  const allAnswered = answeredCount === questions.length;

  const reset = () => {
    setAnswers({});
    setSubmitted(false);
    setResult(null);
    setError(null);
  };

  const submit = () => {
    if (!allAnswered) return;
    const correct = questions.reduce(
      (total, question, index) => (answers[index] === question.answer ? total + 1 : total),
      0,
    );
    const score = Math.round((correct / questions.length) * 100);
    setSubmitted(true);
    setResult(score);

    if (!canAccess) return;

    startTransition(async () => {
      const response = await completeLessonAction({ lessonId, score });
      if (!response.ok) {
        setError(response.message);
        return;
      }
      router.refresh();
    });
  };

  return (
    <div id="quiz" className="card overflow-hidden">
      <div className="flex items-center justify-between border-b border-line/70 px-5 py-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-moss/60">
            Checkpoint
          </p>
          <h3 className="mt-0.5 font-display text-lg text-ink">理解检查</h3>
        </div>
        <span className="chip">
          {answeredCount}/{questions.length} 已作答
        </span>
      </div>

      <div className="space-y-5 p-5">
        {questions.map((question, questionIndex) => {
          const selected = answers[questionIndex];
          const isCorrect = selected === question.answer;
          return (
            <div key={question.question} className="space-y-2.5">
              <p className="text-[13px] font-medium leading-relaxed text-ink">
                <span className="mr-1.5 font-display text-clay">{questionIndex + 1}.</span>
                {question.question}
              </p>
              <div className="grid gap-2">
                {question.options.map((option, optionIndex) => {
                  const chosen = selected === optionIndex;
                  const showCorrect = submitted && optionIndex === question.answer;
                  const showWrong = submitted && chosen && !showCorrect;
                  return (
                    <button
                      key={option}
                      type="button"
                      disabled={submitted}
                      onClick={() =>
                        setAnswers((current) => ({ ...current, [questionIndex]: optionIndex }))
                      }
                      className={`flex items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left text-[12.5px] transition-all ${
                        showCorrect
                          ? "border-forest/40 bg-forest/[0.07] text-forest"
                          : showWrong
                            ? "border-clay/40 bg-clay/[0.06] text-clay"
                            : chosen
                              ? "border-forest/40 bg-forest/[0.04] text-ink"
                              : "border-line bg-white text-ink/70 hover:border-moss/40 hover:bg-parchment/30"
                      }`}
                    >
                      <span
                        className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border text-[9px] font-bold ${
                          showCorrect
                            ? "border-forest bg-forest text-cream"
                            : showWrong
                              ? "border-clay bg-clay text-white"
                              : chosen
                                ? "border-forest text-forest"
                                : "border-line text-ink/40"
                        }`}
                      >
                        {showCorrect ? (
                          <Check className="h-2.5 w-2.5" />
                        ) : showWrong ? (
                          <X className="h-2.5 w-2.5" />
                        ) : (
                          String.fromCharCode(65 + optionIndex)
                        )}
                      </span>
                      <span>{option}</span>
                    </button>
                  );
                })}
              </div>
              {submitted && (
                <p className="rounded-lg bg-parchment/50 px-3 py-2 text-[11.5px] leading-relaxed text-ink/65">
                  <span className={isCorrect ? "font-semibold text-forest" : "font-semibold text-clay"}>
                    {isCorrect ? "回答正确 · " : "再看一眼 · "}
                  </span>
                  {question.explanation}
                </p>
              )}
            </div>
          );
        })}

        {submitted && result !== null && (
          <div
            className={`rounded-2xl border p-4 ${
              result >= 80
                ? "border-forest/25 bg-forest/[0.06]"
                : "border-gold/40 bg-gold/[0.08]"
            }`}
          >
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-clay" />
              <p className="font-display text-lg text-ink">
                {result} 分 · {result >= 80 ? "掌握得很好" : result >= 50 ? "基本理解" : "建议复习后再试"}
              </p>
            </div>
            <p className="mt-1 text-[11.5px] text-ink/60">
              {canAccess
                ? "本次成绩已写入学习档案，连续学习会累积学习天数。"
                : "试用已结束，订阅后成绩才会被保存。"}
            </p>
            {error && <p className="mt-1 text-[11.5px] text-clay">{error}</p>}
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" onClick={reset} className="btn btn-ghost text-[12px]">
                <RotateCcw className="h-3.5 w-3.5" />
                再做一次
              </button>
              {nextLesson ? (
                <Link
                  href={`${basePath}/lessons/${nextLesson.slug}`}
                  className="btn btn-primary text-[12px]"
                >
                  下一课：{nextLesson.title.slice(0, 26)}
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              ) : (
                <Link href={`${basePath}/courses`} className="btn btn-primary text-[12px]">
                  回到课程库
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              )}
            </div>
          </div>
        )}

        {!submitted && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line/70 pt-4">
            {canAccess ? (
              <p className="text-[11px] text-ink/45">答完所有题目即可提交，成绩会记入学习档案。</p>
            ) : (
              <p className="flex items-center gap-1.5 text-[11px] text-clay">
                <Lock className="h-3 w-3" />
                试用已结束，可预览题目但无法保存成绩
              </p>
            )}
            <button
              type="button"
              onClick={submit}
              disabled={!allAnswered || pending}
              className="btn btn-primary text-[12px]"
            >
              {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              提交答案
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
