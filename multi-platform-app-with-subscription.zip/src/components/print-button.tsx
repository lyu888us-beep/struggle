"use client";

import { Printer } from "lucide-react";

export function PrintButton() {
  return (
    <button type="button" onClick={() => window.print()} className="btn btn-ghost text-[12px]">
      <Printer className="h-3.5 w-3.5" />
      打印 / 保存收据
    </button>
  );
}
