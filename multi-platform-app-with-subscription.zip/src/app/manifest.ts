import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Nuance 细语 · 高阶英语",
    short_name: "Nuance",
    description: "高阶英语学习工作室 · 电脑端与手机端同步 · 7 天免费试用",
    start_url: "/mobile",
    display: "standalone",
    orientation: "portrait",
    background_color: "#f7f2e7",
    theme_color: "#1e3a2c",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
    ],
  };
}
