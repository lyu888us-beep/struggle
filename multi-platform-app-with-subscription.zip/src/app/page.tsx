import Image from "next/image";
import Link from "next/link";
import { eq, sql } from "drizzle-orm";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Clock,
  CreditCard,
  Download,
  Flame,
  Layers,
  Lock,
  Monitor,
  Quote,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Star,
  Volume2,
  Wifi,
} from "lucide-react";
import { db } from "@/db";
import { courses, lessons } from "@/db/schema";
import { ensureSeed } from "@/lib/seed";
import { PLANS, formatCNY } from "@/lib/plans";
import { Logo, SectionLabel } from "@/components/ui";
import { LandingShowcase } from "@/components/landing-showcase";

export const dynamic = "force-dynamic";

async function getLandingCourses() {
  await ensureSeed();
  return db
    .select({
      course: courses,
      lessonCount: sql<number>`count(${lessons.id})::int`,
    })
    .from(courses)
    .leftJoin(lessons, eq(lessons.courseId, courses.id))
    .groupBy(courses.id)
    .orderBy(courses.sortOrder);
}

const faqs = [
  {
    q: "7 天免费试用需要绑定信用卡吗？",
    a: "不需要。进入应用即自动开启 7 天完整体验，试用期间不会自动扣款，也不会产生任何费用。到期后你可以自行决定是否订阅。",
  },
  {
    q: "试用结束后我的学习记录会被删除吗？",
    a: "不会。课程进度、词汇本、复习记录都保存在你的学习档案中。订阅完成后立刻恢复，并从上次的位置继续。",
  },
  {
    q: "电脑端和手机端是两份收费吗？",
    a: "不是。一次订阅同时解锁电脑端工作台与手机端 App，两个端的课程、词汇与进度实时同步。你也可以把手机端添加到主屏幕，像原生 App 一样使用。",
  },
  {
    q: "可以随时取消订阅吗？",
    a: "可以。在「订阅与账单」中一键关闭自动续费，权益保留至当前周期结束，不会立即失效。7 天内也可申请全额退款。",
  },
  {
    q: "课程适合什么水平？",
    a: "面向 B2 以上学习者，主体内容为 C1 与 C2。如果你能阅读英文长文但在写作和口语中缺少分寸感，这套课程正合适。",
  },
];

export default async function LandingPage() {
  const courseRows = await getLandingCourses();
  const totalLessons = courseRows.reduce((sum, row) => sum + row.lessonCount, 0);

  return (
    <div className="min-h-screen bg-cream">
      <header className="sticky top-0 z-40 border-b border-line/70 bg-cream/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
          <Logo />
          <nav className="hidden items-center gap-7 text-[12.5px] text-ink/60 md:flex">
            <a href="#courses" className="transition-colors hover:text-ink">课程体系</a>
            <a href="#devices" className="transition-colors hover:text-ink">双端应用</a>
            <a href="#pricing" className="transition-colors hover:text-ink">价格</a>
            <a href="#faq" className="transition-colors hover:text-ink">常见问题</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/mobile" className="hidden text-[12.5px] font-medium text-ink/60 hover:text-ink sm:block">
              手机端
            </Link>
            <Link href="/desktop" className="btn btn-primary text-[12.5px]">
              开始 7 天试用
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="pointer-events-none absolute -left-32 top-10 h-72 w-72 rounded-full bg-gold/15 blur-3xl" />
          <div className="pointer-events-none absolute -right-20 top-40 h-72 w-72 rounded-full bg-clay/10 blur-3xl" />
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-14 pt-12 lg:grid-cols-[1.05fr_1fr] lg:gap-12 lg:pb-20 lg:pt-16">
            <div className="animate-rise">
              <SectionLabel>C1 · C2 高阶英语工作室</SectionLabel>
              <h1 className="mt-4 font-display text-[clamp(2.5rem,5.6vw,4.2rem)] leading-[1.04] text-ink">
                把英语，
                <br />
                练成你的
                <span className="relative mx-1 inline-block">
                  <span className="relative z-10">第二母语</span>
                  <span className="absolute inset-x-0 bottom-1 z-0 h-3 bg-gold/35" />
                </span>
                。
              </h1>
              <p className="mt-5 max-w-lg text-[14px] leading-relaxed text-ink/60">
                不再背单词表。我们从词义的边界、论证的骨架到会议室里的每一次停顿，
                训练你在真实场景中做出精确、体面、有分量的英文表达。
              </p>
              <div className="mt-7 flex flex-wrap items-center gap-2.5">
                <Link href="/desktop" className="btn btn-primary px-5 py-3 text-[13px]">
                  <Monitor className="h-4 w-4" />
                  进入电脑端工作台
                </Link>
                <Link href="/mobile" className="btn btn-ghost px-5 py-3 text-[13px]">
                  <Smartphone className="h-4 w-4" />
                  打开手机端 App
                </Link>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] text-ink/50">
                <span className="flex items-center gap-1.5">
                  <Check className="h-3.5 w-3.5 text-forest" /> 7 天免费试用
                </span>
                <span className="flex items-center gap-1.5">
                  <CreditCard className="h-3.5 w-3.5 text-forest" /> 无需绑定信用卡
                </span>
                <span className="flex items-center gap-1.5">
                  <Wifi className="h-3.5 w-3.5 text-forest" /> 双端实时同步
                </span>
              </div>
            </div>
            <div className="animate-rise [animation-delay:120ms]">
              <LandingShowcase />
            </div>
          </div>

          <div className="border-y border-line/70 bg-parchment/30">
            <div className="mx-auto grid max-w-6xl grid-cols-2 gap-px px-5 py-5 sm:grid-cols-4">
              {[
                ["6", "门高阶课程"],
                [`${totalLessons}`, "个精读课时"],
                ["C1–C2", "CEFR 难度覆盖"],
                ["2 端", "电脑 + 手机同步"],
              ].map(([value, label]) => (
                <div key={label} className="px-2 text-center">
                  <p className="font-display text-2xl text-forest">{value}</p>
                  <p className="mt-0.5 text-[11px] text-ink/45">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Editorial band */}
        <section className="mx-auto max-w-6xl px-5 py-16">
          <div className="grid items-stretch gap-0 overflow-hidden rounded-[32px] border border-forest/20 bg-forest text-cream lg:grid-cols-2">
            <div className="relative min-h-[280px]">
              <Image
                src="/images/study.jpg"
                alt="阅读中的英文词典与钢笔"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
                priority={false}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-forest/20 to-forest/70 lg:bg-gradient-to-r lg:from-transparent lg:to-forest" />
            </div>
            <div className="relative p-7 md:p-10">
              <div className="grain absolute inset-0 opacity-20" />
              <div className="relative">
                <Quote className="h-7 w-7 text-gold/70" />
                <p className="mt-4 font-display text-[clamp(1.5rem,2.6vw,2.1rem)] leading-snug">
                  语言的高级感，来自分寸感。
                  <span className="mt-2 block text-cream/55">
                    不是说得更多，而是知道在哪里停下。
                  </span>
                </p>
                <p className="mt-5 max-w-md text-[12.5px] leading-relaxed text-cream/60">
                  Nuance 细语只做一件事：把中文母语者最容易忽略的语义层次，
                  拆解成可以练习的动作。每节课 12–18 分钟，读完、听懂、用出去。
                </p>
                <div className="mt-6 grid gap-2 sm:grid-cols-2">
                  {[
                    ["近义词辨析", "选择更精确的那个词"],
                    ["语气与保留", "写出可以被引用的句子"],
                    ["语音与停顿", "让别人愿意听完"],
                    ["真实场景", "会议室里的博弈语言"],
                  ].map(([title, hint]) => (
                    <div key={title} className="rounded-xl border border-cream/15 bg-cream/[0.05] px-3 py-2.5">
                      <p className="text-[12px] font-semibold">{title}</p>
                      <p className="text-[10.5px] text-cream/50">{hint}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Devices */}
        <section id="devices" className="mx-auto max-w-6xl scroll-mt-20 px-5 pb-16">
          <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <SectionLabel>One account, two apps</SectionLabel>
              <h2 className="mt-3 font-display text-[clamp(1.9rem,3.4vw,2.7rem)] leading-tight">
                一套体系，落在你的每一个屏幕
              </h2>
            </div>
            <p className="max-w-sm text-[12.5px] leading-relaxed text-ink/50">
              电脑端沉浸阅读与写作，手机端利用通勤时间复习。
              学习档案实时同步，7 天试用一次解锁两端全部功能。
            </p>
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="card group relative overflow-hidden p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-forest text-cream">
                    <Monitor className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-moss/60">
                      Desktop application
                    </p>
                    <h3 className="font-display text-2xl">电脑端工作台</h3>
                  </div>
                </div>
                <span className="chip">推荐大屏</span>
              </div>
              <p className="mt-3 max-w-md text-[12.5px] leading-relaxed text-ink/55">
                三栏式学习界面：正文、语言注释与理解检查同屏展开。
                适合 15 分钟以上的精读、写作与词汇整理。
              </p>
              <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
                {["沉浸式精读排版", "侧栏语言注释", "词汇本与复习队列", "订阅与账单管理"].map((item) => (
                  <li key={item} className="flex items-center gap-1.5 text-[11.5px] text-ink/60">
                    <Check className="h-3.5 w-3.5 text-forest" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Link href="/desktop" className="btn btn-primary text-[12px]">
                  打开电脑端
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <span className="flex items-center gap-1.5 text-[10.5px] text-ink/40">
                  <Download className="h-3 w-3" />
                  浏览器中可安装为桌面应用
                </span>
              </div>
              <div className="pointer-events-none absolute -bottom-8 -right-6 hidden w-44 rotate-2 rounded-xl border border-line bg-[#fffdf8] p-2 shadow-lg transition-transform duration-500 group-hover:-translate-y-1 sm:block">
                <div className="h-1.5 w-12 rounded bg-forest/80" />
                <div className="mt-1.5 space-y-1">
                  <div className="h-1 w-full rounded bg-line" />
                  <div className="h-1 w-4/5 rounded bg-line" />
                  <div className="h-1 w-2/3 rounded bg-line" />
                </div>
              </div>
            </div>

            <div className="card group relative overflow-hidden p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-clay text-white">
                    <Smartphone className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-clay/60">
                      Mobile application
                    </p>
                    <h3 className="font-display text-2xl">手机端随身学</h3>
                  </div>
                </div>
                <span className="chip">可加桌面</span>
              </div>
              <p className="mt-3 max-w-md text-[12.5px] leading-relaxed text-ink/55">
                为单手设计的 App 界面：今日一句、复习卡、5 分钟微课时。
                添加到手机主屏幕，像原生应用一样打开。
              </p>
              <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
                {["今日一句与朗读", "间隔复习闪卡", "底部四栏导航", "订阅状态随时查看"].map((item) => (
                  <li key={item} className="flex items-center gap-1.5 text-[11.5px] text-ink/60">
                    <Check className="h-3.5 w-3.5 text-clay" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Link href="/mobile" className="btn btn-clay text-[12px]">
                  打开手机端
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <span className="flex items-center gap-1.5 text-[10.5px] text-ink/40">
                  <Download className="h-3 w-3" />
                  Safari / Chrome 添加到主屏幕
                </span>
              </div>
              <div className="pointer-events-none absolute -bottom-6 right-4 hidden w-20 rotate-6 sm:block">
                <div className="rounded-2xl border-2 border-ink/20 bg-[#fffdf8] p-1.5 shadow-xl transition-transform duration-500 group-hover:-translate-y-1">
                  <div className="mx-auto h-0.5 w-5 rounded bg-ink/20" />
                  <div className="mt-1 space-y-1">
                    <div className="h-3 rounded bg-forest/80" />
                    <div className="h-1 rounded bg-line" />
                    <div className="h-1 w-3/4 rounded bg-line" />
                    <div className="h-4 rounded bg-parchment" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Courses */}
        <section id="courses" className="scroll-mt-20 border-y border-line/70 bg-[#fffdf8]">
          <div className="mx-auto max-w-6xl px-5 py-16">
            <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <SectionLabel>Curriculum</SectionLabel>
                <h2 className="mt-3 font-display text-[clamp(1.9rem,3.4vw,2.7rem)] leading-tight">
                  六条路径，构成高阶英语的完整骨架
                </h2>
              </div>
              <Link
                href="/desktop/courses"
                className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-forest hover:text-clay"
              >
                查看全部课程
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {courseRows.map(({ course, lessonCount }, index) => (
                <Link
                  key={course.id}
                  href={`/desktop/courses/${course.slug}`}
                  className="group relative flex flex-col overflow-hidden rounded-[22px] border border-line bg-cream/60 p-5 transition-all hover:-translate-y-0.5 hover:border-forest/30 hover:shadow-[0_20px_40px_-30px_rgba(21,34,27,0.5)]"
                >
                  <div className="flex items-start justify-between">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-forest/[0.07] text-[16px] text-forest">
                      {course.emoji}
                    </span>
                    <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[10px] font-semibold text-moss">
                      {course.level}
                    </span>
                  </div>
                  <p className="mt-3 text-[10px] uppercase tracking-[0.18em] text-ink/35">
                    0{index + 1} · {course.titleEn}
                  </p>
                  <h3 className="mt-1 font-display text-xl text-ink">{course.title}</h3>
                  <p className="mt-1 text-[11.5px] text-clay/80">{course.tagline}</p>
                  <p className="mt-2 line-clamp-3 flex-1 text-[11.5px] leading-relaxed text-ink/50">
                    {course.description}
                  </p>
                  <div className="mt-3 flex items-center justify-between border-t border-line/70 pt-3 text-[10.5px] text-ink/45">
                    <span className="flex items-center gap-1">
                      <Layers className="h-3 w-3" />
                      {lessonCount} 课时
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {course.minutes} 分钟
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-forest">
                      进入
                      <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Method */}
        <section className="mx-auto max-w-6xl px-5 py-16">
          <SectionLabel>How it works</SectionLabel>
          <div className="mt-3 grid gap-8 lg:grid-cols-[1fr_1.35fr] lg:gap-12">
            <div>
              <h2 className="font-display text-[clamp(1.9rem,3.4vw,2.7rem)] leading-tight">
                每一次学习，都留下可复习的痕迹
              </h2>
              <p className="mt-4 max-w-md text-[13px] leading-relaxed text-ink/55">
                读完一节课，理解检查会立刻写回你的学习档案；
                收藏的词汇自动进入间隔复习队列；学习天数与 XP 累积成你的连续记录。
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <div className="flex items-center gap-2 rounded-xl border border-line bg-[#fffdf8] px-3 py-2">
                  <Flame className="h-4 w-4 text-clay" />
                  <span className="text-[11.5px] text-ink/60">连续学习天数</span>
                </div>
                <div className="flex items-center gap-2 rounded-xl border border-line bg-[#fffdf8] px-3 py-2">
                  <Volume2 className="h-4 w-4 text-forest" />
                  <span className="text-[11.5px] text-ink/60">例句朗读</span>
                </div>
                <div className="flex items-center gap-2 rounded-xl border border-line bg-[#fffdf8] px-3 py-2">
                  <Star className="h-4 w-4 text-gold" />
                  <span className="text-[11.5px] text-ink/60">理解检查评分</span>
                </div>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {[
                ["01", "输入", "精读母语级文本，标注语气、结构与潜台词。"],
                ["02", "精练", "用理解检查逼自己做出判断，而不只是读完。"],
                ["03", "输出", "把词汇送入复习队列，把句式带进真实对话。"],
              ].map(([number, title, text]) => (
                <div key={number} className="card flex flex-col p-5">
                  <span className="font-display text-3xl text-clay/30">{number}</span>
                  <h3 className="mt-3 font-display text-xl">{title}</h3>
                  <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink/50">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="scroll-mt-20 border-y border-line/70 bg-parchment/35">
          <div className="mx-auto max-w-6xl px-5 py-16">
            <div className="text-center">
              <SectionLabel>
                <span className="mx-auto">Pricing</span>
              </SectionLabel>
              <h2 className="mt-3 font-display text-[clamp(2rem,3.6vw,2.9rem)] leading-tight">
                先免费学 7 天，再决定要不要继续
              </h2>
              <p className="mx-auto mt-3 max-w-xl text-[13px] leading-relaxed text-ink/55">
                完整功能试用 7 天，无需信用卡。试用结束后课程与复习卡会锁定，
                你的学习记录始终保留。随时可取消，7 天内可退款。
              </p>
            </div>

            <div className="mt-8 grid gap-4 lg:grid-cols-3">
              {PLANS.map((plan) => (
                <div
                  key={plan.id}
                  className={`relative flex flex-col rounded-[26px] border p-6 ${
                    plan.highlight
                      ? "border-forest bg-forest text-cream shadow-[0_30px_60px_-40px_rgba(21,34,27,0.8)] lg:-mt-2 lg:mb-2"
                      : "border-line bg-[#fffdf8]"
                  }`}
                >
                  {plan.badge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold px-3 py-1 text-[10px] font-bold text-[#2a1f08]">
                      最受欢迎 · 省 43%
                    </span>
                  )}
                  <p className={`text-[11px] font-semibold uppercase tracking-[0.2em] ${plan.highlight ? "text-gold" : "text-moss/60"}`}>
                    {plan.nameEn}
                  </p>
                  <h3 className="mt-1 font-display text-2xl">{plan.name}</h3>
                  <div className="mt-3 flex items-end gap-1.5">
                    <span className="font-display text-4xl">{formatCNY(plan.priceCents)}</span>
                    <span className={`pb-1 text-[11px] ${plan.highlight ? "text-cream/50" : "text-ink/40"}`}>
                      {plan.per}
                    </span>
                    {plan.originalCents && (
                      <span className={`pb-1 text-[11px] line-through ${plan.highlight ? "text-cream/35" : "text-ink/30"}`}>
                        {formatCNY(plan.originalCents)}
                      </span>
                    )}
                  </div>
                  <p className={`mt-1 text-[11.5px] ${plan.highlight ? "text-cream/55" : "text-ink/45"}`}>
                    {plan.tagline}
                  </p>
                  <ul className="mt-4 flex-1 space-y-2">
                    {plan.features.map((feature) => (
                      <li
                        key={feature}
                        className={`flex items-start gap-2 text-[12px] ${plan.highlight ? "text-cream/80" : "text-ink/60"}`}
                      >
                        <Check
                          className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${plan.highlight ? "text-gold" : "text-forest"}`}
                        />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href={`/checkout?plan=${plan.id}`}
                    className={`btn mt-5 w-full text-[12.5px] ${
                      plan.highlight ? "bg-cream text-forest hover:bg-white" : "btn-primary"
                    }`}
                  >
                    选择{plan.name}
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  <p className={`mt-2 text-center text-[10px] ${plan.highlight ? "text-cream/40" : "text-ink/35"}`}>
                    {plan.periodDays ? "自动续费 · 可随时取消" : "一次性付款 · 长期有效"}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-5 flex flex-col items-center justify-between gap-3 rounded-2xl border border-clay/25 bg-[#fffdf8] px-5 py-4 sm:flex-row">
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-clay/10 text-clay">
                  <Sparkles className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-[12.5px] font-semibold text-ink">想先看看？直接开启 7 天试用</p>
                  <p className="text-[11px] text-ink/45">
                    结账时输入 <span className="font-semibold text-clay">NUANCE30</span> 立减 30%
                  </p>
                </div>
              </div>
              <Link href="/desktop" className="btn btn-primary text-[12px]">
                免费开始
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[10.5px] text-ink/40">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5" /> 7 天无理由退款
              </span>
              <span className="flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5" /> 加密支付
              </span>
              <span className="flex items-center gap-1.5">
                <CreditCard className="h-3.5 w-3.5" /> 微信支付 / 支付宝 / Apple Pay
              </span>
              <span className="flex items-center gap-1.5">
                <Wifi className="h-3.5 w-3.5" /> 双端同步不额外收费
              </span>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mx-auto max-w-3xl scroll-mt-20 px-5 py-16">
          <div className="text-center">
            <SectionLabel>
              <span className="mx-auto">FAQ</span>
            </SectionLabel>
            <h2 className="mt-3 font-display text-[clamp(1.8rem,3.2vw,2.5rem)]">关于试用与订阅</h2>
          </div>
          <div className="mt-6 divide-y divide-line/70 overflow-hidden rounded-[22px] border border-line bg-[#fffdf8]">
            {faqs.map((item) => (
              <details key={item.q} className="group px-5 py-4">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-[13px] font-medium text-ink">
                  {item.q}
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full border border-line text-ink/40 transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-2 pr-6 text-[12px] leading-relaxed text-ink/55">{item.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* Final CTA */}
        <section className="mx-auto max-w-6xl px-5 pb-16">
          <div className="relative overflow-hidden rounded-[32px] border border-forest/20 bg-forest px-6 py-10 text-center text-cream md:px-12 md:py-14">
            <div className="grain absolute inset-0 opacity-25" />
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-gold/15 blur-3xl" />
            <div className="absolute -bottom-12 right-0 h-48 w-48 rounded-full bg-clay/20 blur-3xl" />
            <div className="relative">
              <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold/80">
                Start today
              </p>
              <h2 className="mx-auto mt-3 max-w-2xl font-display text-[clamp(1.8rem,3.6vw,2.8rem)] leading-tight">
                今天开始，把英语变成你真正的第二语言
              </h2>
              <p className="mx-auto mt-3 max-w-lg text-[12.5px] leading-relaxed text-cream/60">
                7 天完整体验 · 无需信用卡 · 电脑端与手机端同时解锁。
                试用结束后，你的学习档案会完整保留。
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-2.5">
                <Link href="/desktop" className="btn bg-cream px-5 py-3 text-[13px] text-forest hover:bg-white">
                  <Monitor className="h-4 w-4" />
                  电脑端免费试用
                </Link>
                <Link
                  href="/mobile"
                  className="btn border border-cream/25 bg-cream/10 px-5 py-3 text-[13px] text-cream hover:bg-cream/15"
                >
                  <Smartphone className="h-4 w-4" />
                  手机端免费试用
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-line/70 bg-[#fffdf8]">
        <div className="mx-auto max-w-6xl px-5 py-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div className="max-w-xs">
              <Logo />
              <p className="mt-3 text-[11.5px] leading-relaxed text-ink/45">
                为中文母语者设计的高阶英语工作室。电脑端、手机端与订阅系统均为可运行演示。
              </p>
            </div>
            <div className="grid grid-cols-2 gap-8 text-[11.5px] sm:grid-cols-3">
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-ink/35">应用</p>
                <ul className="space-y-1.5 text-ink/55">
                  <li><Link href="/desktop" className="hover:text-forest">电脑端工作台</Link></li>
                  <li><Link href="/mobile" className="hover:text-forest">手机端 App</Link></li>
                  <li><Link href="/desktop/settings" className="hover:text-forest">安装与设置</Link></li>
                </ul>
              </div>
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-ink/35">学习</p>
                <ul className="space-y-1.5 text-ink/55">
                  <li><Link href="/desktop/courses" className="hover:text-forest">课程体系</Link></li>
                  <li><Link href="/desktop/vocab" className="hover:text-forest">词汇与复习</Link></li>
                  <li><a href="#pricing" className="hover:text-forest">价格</a></li>
                </ul>
              </div>
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-ink/35">订阅</p>
                <ul className="space-y-1.5 text-ink/55">
                  <li><Link href="/desktop/billing" className="hover:text-forest">订阅与账单</Link></li>
                  <li><Link href="/checkout?plan=annual" className="hover:text-forest">开通年度会员</Link></li>
                  <li><a href="#faq" className="hover:text-forest">退款政策</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-7 flex flex-col gap-2 border-t border-line/70 pt-4 text-[10.5px] text-ink/35 sm:flex-row sm:items-center sm:justify-between">
            <p>© {new Date().getFullYear()} Nuance 细语 English Studio · 演示产品</p>
            <p>支付为模拟流程，不会产生真实扣款。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
