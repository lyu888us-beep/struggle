import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nuance 细语 · 高阶英语学习",
  description:
    "面向 C1 / C2 学习者的高阶英语工作室：词义边界、学术写作、习语语感与会议室英语。电脑端与手机端同步，7 天免费试用。",
  applicationName: "Nuance 细语",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Nuance 细语",
    statusBarStyle: "black-translucent",
  },
};

export const viewport: Viewport = {
  themeColor: "#1e3a2c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
