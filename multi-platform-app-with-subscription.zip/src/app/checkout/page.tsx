import Link from "next/link";
import { ArrowLeft, Lock, ShieldCheck, Sparkles } from "lucide-react";
import { getViewer } from "@/lib/session";
import { isPlanId } from "@/lib/plans";
import { CheckoutFlow } from "@/components/checkout-client";
import { DeviceLinks, Logo } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function CheckoutPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string; from?: string }>;
}) {
  const { user, entitlement } = await getViewer();
  const { plan, from } = await searchParams;
  const initialPlan = plan && isPlanId(plan) ? plan : "annual";
  const basePath = from === "mobile" ? "/mobile" : "/desktop";

  return (
    <div className="min-h-screen bg-cream">
      <header className="border-b border-line/70 bg-cream/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3.5">
          <Logo href={basePath} />
          <div className="flex items-center gap-2">
            <div className="hidden sm:block">
              <DeviceLinks current={basePath === "/mobile" ? "mobile" : "desktop"} />
            </div>
            <Link href={basePath} className="btn btn-ghost text-[11.5px]">
              <ArrowLeft className="h-3.5 w-3.5" />
              返回应用
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-6 md:py-8">
        <div className="mb-5">
          <p className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
            <span className="h-px w-6 bg-clay/60" />
            Secure checkout
          </p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,3vw,2.4rem)] leading-tight">
            开通你的 Nuance 会员
          </h1>
          <p className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11.5px] text-ink/50">
            <span className="flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-forest" />
              加密支付 · 演示环境不会真实扣款
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-forest" />7 天无理由退款
            </span>
            <span className="flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-gold" />
              一次订阅，电脑端 + 手机端
            </span>
          </p>
        </div>

        <CheckoutFlow
          initialPlan={initialPlan}
          currentPlan={user.plan}
          email={user.email}
          entitlementState={entitlement.state}
          trialNote={entitlement.trialNote}
          basePath={basePath}
        />

        <div className="mt-6 flex flex-wrap items-center justify-between gap-2 border-t border-line/70 pt-4 text-[10.5px] text-ink/35">
          <p>Nuance 细语 English Studio · 会员服务演示收银台</p>
          <div className="flex items-center gap-3">
            <Link href="/#faq" className="hover:text-ink">
              服务条款
            </Link>
            <Link href="/#pricing" className="hover:text-ink">
              价格说明
            </Link>
            <Link href="/" className="hover:text-ink">
              官网
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
