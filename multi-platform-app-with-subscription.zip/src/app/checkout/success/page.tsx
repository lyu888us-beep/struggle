import Link from "next/link";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Crown,
  Mail,
  Monitor,
  Receipt,
  Smartphone,
  Sparkles,
} from "lucide-react";
import { formatDate, getViewer } from "@/lib/session";
import { getPaymentByOrder } from "@/lib/data";
import { formatCNY, paymentMethodName, planDisplayName } from "@/lib/plans";
import { Logo } from "@/components/ui";
import { PrintButton } from "@/components/print-button";

export const dynamic = "force-dynamic";

export default async function CheckoutSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const { order } = await searchParams;
  const { user, entitlement } = await getViewer();
  const payment = order ? await getPaymentByOrder(order, user.id) : null;

  if (!payment) {
    return (
      <div className="grid min-h-screen place-items-center bg-cream px-5">
        <div className="card w-full max-w-md p-7 text-center">
          <Receipt className="mx-auto h-7 w-7 text-ink/25" />
          <h1 className="mt-3 font-display text-2xl">没有找到这笔订单</h1>
          <p className="mt-2 text-[12px] leading-relaxed text-ink/50">
            订单号可能已失效，或该订单不属于当前学习档案。你可以在订阅与账单中查看历史支付。
          </p>
          <div className="mt-5 flex flex-col gap-2">
            <Link href="/desktop/billing" className="btn btn-primary text-[12px]">
              查看我的账单
            </Link>
            <Link href="/" className="btn btn-ghost text-[12px]">
              返回官网
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <header className="border-b border-line/70 bg-cream/90">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-3.5">
          <Logo />
          <span className="chip">
            <CheckCircle2 className="h-3 w-3" />
            支付成功
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-5 py-8">
        <div className="relative overflow-hidden rounded-[28px] border border-forest/20 bg-forest p-6 text-cream md:p-8">
          <div className="grain absolute inset-0 opacity-30" />
          <div className="absolute -right-10 -top-14 h-48 w-48 rounded-full bg-gold/20 blur-3xl" />
          <div className="relative">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-cream text-forest">
              <Check className="h-6 w-6" />
            </span>
            <p className="mt-4 text-[10px] font-semibold uppercase tracking-[0.24em] text-cream/45">
              Payment complete
            </p>
            <h1 className="mt-1.5 font-display text-[clamp(1.8rem,3.4vw,2.6rem)] leading-tight">
              {payment.planName} 已开通
            </h1>
            <p className="mt-2 max-w-lg text-[12.5px] leading-relaxed text-cream/60">
              电脑端与手机端已同时解锁。{entitlement.nextChargeNote}
              {user.email ? ` 收据已生成，将发送至 ${user.email}。` : " 你可以在设置中补填收据邮箱。"}
            </p>
            <div className="mt-5 flex flex-wrap gap-2.5">
              <Link href="/desktop" className="btn bg-cream text-[12.5px] text-forest hover:bg-white">
                <Monitor className="h-3.5 w-3.5" />
                开始电脑端学习
              </Link>
              <Link
                href="/mobile"
                className="btn border border-cream/25 bg-cream/10 text-[12.5px] text-cream hover:bg-cream/15"
              >
                <Smartphone className="h-3.5 w-3.5" />
                打开手机端
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-4 card overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/70 px-5 py-3.5">
            <h2 className="flex items-center gap-2 font-display text-lg">
              <Receipt className="h-4 w-4 text-moss" />
              订单收据
            </h2>
            <span className="rounded-full bg-forest/[0.07] px-2.5 py-1 text-[10px] font-semibold text-forest">
              已支付
            </span>
          </div>
          <div className="grid gap-x-6 gap-y-3 px-5 py-4 sm:grid-cols-2">
            {[
              ["订单号", payment.orderNo, true],
              ["会员方案", planDisplayName(payment.plan)],
              ["支付方式", paymentMethodName(payment.method)],
              ["支付时间", formatDate(payment.createdAt)],
              ["生效周期", payment.periodEnd ? `至 ${formatDate(payment.periodEnd)}` : "永久有效"],
              ["优惠", payment.coupon ? `${payment.coupon} · -${formatCNY(payment.discountCents)}` : "无"],
            ].map(([label, value, mono]) => (
              <div key={label as string} className="flex items-center justify-between gap-3 border-b border-line/50 pb-2">
                <span className="text-[11px] text-ink/40">{label}</span>
                <span className={`text-[11.5px] font-medium text-ink ${mono ? "font-mono text-[10.5px]" : ""}`}>
                  {value}
                </span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line/70 bg-parchment/25 px-5 py-3">
            <div>
              <p className="text-[10.5px] text-ink/45">实付金额</p>
              <p className="font-display text-2xl text-ink">{formatCNY(payment.amountCents)}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <PrintButton />
              <Link href="/desktop/billing" className="btn btn-primary text-[12px]">
                订阅与账单
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {[
            ["全部 6 门高阶课程", "词义、写作、口语、发音、商务与阅读"],
            ["双端同步", "电脑端与手机端共享同一份档案"],
            ["7 天退款保障", "如需退款可在账单页联系我们"],
          ].map(([title, hint]) => (
            <div key={title} className="card-quiet p-4">
              <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
                <Crown className="h-3.5 w-3.5 text-gold" />
                {title}
              </p>
              <p className="mt-1 text-[10.5px] leading-relaxed text-ink/45">{hint}</p>
            </div>
          ))}
        </div>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-[10px] text-ink/35">
          <Sparkles className="h-3 w-3 text-gold" />
          演示环境：这笔订单为模拟支付，不会产生真实扣款
        </p>
        {user.email ? (
          <p className="mt-1 flex items-center justify-center gap-1.5 text-[10px] text-ink/35">
            <Mail className="h-3 w-3" />
            收据邮箱：{user.email}
          </p>
        ) : null}
      </main>
    </div>
  );
}
