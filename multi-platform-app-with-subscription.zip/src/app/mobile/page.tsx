import Link from "next/link";
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Flame,
  Play,
  Sparkles,
  Target,
} from "lucide-react";
import { getViewer } from "@/lib/session";
import { getLearningOverview, getWordBank } from "@/lib/data";
import { AccessLocked, ProgressBar } from "@/components/ui";
import { SaveWordButton, SpeakButton } from "@/components/learning-client";

export const dynamic = "force-dynamic";

export default async function MobileHome() {
  const { user, entitlement } = await getViewer();
  const [overview, wordBank] = await Promise.all([
    getLearningOverview(user.id),
    getWordBank(user.id),
  ]);

  const hour = Number(
    new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hour12: false, timeZone: "Asia/Shanghai" }).format(
      new Date(),
    ),
  );
  const greeting = hour < 6 ? "夜深了" : hour < 12 ? "早上好" : hour < 18 ? "下午好" : "晚上好";
  const wordOfDay = overview.wordOfDay;
  const savedWord = wordOfDay
    ? wordBank.items.find((item) => item.word.id === wordOfDay.id)?.progress
    : null;

  return (
    <div className="space-y-4">
      <div>
        <p className="text-[10.5px] text-ink/40">
          {new Intl.DateTimeFormat("zh-CN", {
            month: "long",
            day: "numeric",
            weekday: "long",
          }).format(new Date())}
        </p>
        <h1 className="mt-0.5 font-display text-[26px] leading-tight text-ink">
          {greeting}，{user.displayName}
          <span className="text-clay">.</span>
        </h1>
        <div className="mt-2 flex items-center gap-1.5">
          <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[10px] text-ink/55">
            🔥 连续 {overview.streak} 天
          </span>
          <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[10px] text-ink/55">
            {overview.completedLessons}/{overview.totalLessons} 课时
          </span>
          <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[10px] text-ink/55">
            {overview.wordsMastered} 已掌握
          </span>
        </div>
      </div>

      {entitlement.state === "expired" && <AccessLocked compact />}

      {entitlement.state === "trialing" && (
        <Link
          href="/checkout?plan=annual"
          className="relative block overflow-hidden rounded-[22px] border border-clay/30 bg-gradient-to-br from-[#c2542f] to-[#a44326] p-4 text-white"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[9.5px] uppercase tracking-[0.2em] text-white/60">Free trial</p>
              <p className="mt-0.5 font-display text-lg leading-tight">
                试用还剩 {entitlement.trialDaysLeft} 天
              </p>
              <p className="mt-1 text-[10.5px] text-white/70">
                年付 ¥39/月，试用期内升级可保留全部进度
              </p>
            </div>
            <span className="grid h-7 w-7 place-items-center rounded-full bg-white/20">
              <Sparkles className="h-3.5 w-3.5" />
            </span>
          </div>
          <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/25">
            <div className="h-full rounded-full bg-white/85" style={{ width: `${entitlement.trialProgress}%` }} />
          </div>
        </Link>
      )}

      {wordOfDay && (
        <div className="relative overflow-hidden rounded-[24px] border border-forest/20 bg-forest p-4 text-cream">
          <div className="grain absolute inset-0 opacity-30" />
          <div className="relative">
            <div className="flex items-center justify-between">
              <p className="text-[9px] font-semibold uppercase tracking-[0.22em] text-cream/45">
                Today&apos;s word
              </p>
              <span className="rounded-full border border-cream/20 px-1.5 py-0.5 text-[9px] text-cream/60">
                {wordOfDay.level}
              </span>
            </div>
            <div className="mt-1.5 flex items-end justify-between gap-2">
              <div>
                <p className="font-display text-[26px] leading-none">{wordOfDay.word}</p>
                <p className="mt-1 text-[10px] text-cream/45">
                  {wordOfDay.phonetic} · {wordOfDay.partOfSpeech}
                </p>
              </div>
              <SpeakButton text={`${wordOfDay.word}. ${wordOfDay.exampleEn}`} tone="light" />
            </div>
            <p className="mt-2 text-[12px] text-cream">{wordOfDay.meaningZh}</p>
            <p className="mt-1.5 text-[11px] italic leading-relaxed text-cream/60">
              {wordOfDay.exampleEn}
            </p>
            <div className="mt-3 flex items-center justify-between">
              <SaveWordButton wordId={wordOfDay.id} saved={Boolean(savedWord)} />
              <Link href="/mobile/vocab" className="flex items-center gap-0.5 text-[10.5px] text-cream/60">
                打开词汇本
                <ChevronRight className="h-3 w-3" />
              </Link>
            </div>
          </div>
        </div>
      )}

      {overview.continueLesson && (
        <Link
          href={`/mobile/lessons/${overview.continueLesson.slug}`}
          className="card block p-4 transition-transform active:scale-[0.99]"
        >
          <div className="flex items-center justify-between">
            <p className="text-[9.5px] uppercase tracking-[0.18em] text-clay/70">继续学习</p>
            <span className="text-[10px] text-ink/35">
              {overview.continueLesson.level} · {overview.continueLesson.minutes} 分钟
            </span>
          </div>
          <p className="mt-1 text-[10.5px] text-ink/40">{overview.continueLesson.courseTitle}</p>
          <p className="font-display text-lg leading-snug text-ink">{overview.continueLesson.title}</p>
          <p className="text-[11px] text-ink/45">{overview.continueLesson.titleZh}</p>
          <div className="mt-3 flex items-center gap-2">
            <span className="flex flex-1 items-center gap-1.5 rounded-full bg-forest px-3 py-2 text-[11px] font-semibold text-cream">
              <Play className="h-3 w-3" />
              继续这一课
            </span>
            <span className="flex items-center gap-1 text-[10px] text-ink/40">
              <Target className="h-3 w-3" />+{overview.continueLesson.xp} XP
            </span>
          </div>
        </Link>
      )}

      <div className="card p-4">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-1.5 font-display text-lg">
            <CheckCircle2 className="h-4 w-4 text-forest" />
            今日三件事
          </h2>
          <span className="text-[10px] text-ink/35">{overview.completedMinutes} 分钟已学</span>
        </div>
        <div className="mt-3 space-y-2">
          {[
            {
              title: "精读一节课",
              hint: overview.continueLesson ? `${overview.continueLesson.minutes} 分钟` : "全部完成",
              done: !overview.continueLesson,
              href: overview.continueLesson ? `/mobile/lessons/${overview.continueLesson.slug}` : "/mobile/courses",
            },
            {
              title: `复习 ${wordBank.dueToday.length} 张词汇卡`,
              hint: wordBank.dueToday.length > 0 ? "间隔重复队列" : "今日已完成",
              done: wordBank.dueToday.length === 0,
              href: "/mobile/vocab",
            },
            {
              title: "收藏 1 个新词",
              hint: `已收藏 ${overview.wordsSaved} 个`,
              done: overview.wordsSaved > 0,
              href: "/mobile/vocab",
            },
          ].map((task) => (
            <Link
              key={task.title}
              href={task.href}
              className="flex items-center gap-2.5 rounded-xl border border-line/80 bg-[#fffdf8] px-3 py-2.5"
            >
              <span
                className={`grid h-5 w-5 place-items-center rounded-full border text-[9px] ${
                  task.done ? "border-forest bg-forest text-cream" : "border-line text-transparent"
                }`}
              >
                ✓
              </span>
              <span className="min-w-0 flex-1">
                <span className={`block text-[11.5px] font-medium ${task.done ? "text-ink/40 line-through" : "text-ink"}`}>
                  {task.title}
                </span>
                <span className="block text-[9.5px] text-ink/40">{task.hint}</span>
              </span>
              <ChevronRight className="h-3.5 w-3.5 text-ink/25" />
            </Link>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-lg">继续课程</h2>
          <Link href="/mobile/courses" className="flex items-center gap-0.5 text-[10.5px] text-moss">
            全部
            <ChevronRight className="h-3 w-3" />
          </Link>
        </div>
        <div className="space-y-2">
          {overview.courses.slice(0, 3).map(({ course, progress, completedCount, lessonCount }) => (
            <Link
              key={course.id}
              href={`/mobile/courses/${course.slug}`}
              className="flex items-center gap-3 rounded-2xl border border-line bg-[#fffdf8] px-3.5 py-3"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-forest/[0.07] text-[15px] text-forest">
                {course.emoji}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="text-[12px] font-semibold text-ink">{course.title}</span>
                  <span className="text-[9.5px] text-ink/35">{progress}%</span>
                </span>
                <span className="mt-0.5 block text-[10px] text-ink/40">
                  {course.level} · {completedCount}/{lessonCount} 课时
                </span>
                <span className="mt-1.5 block">
                  <ProgressBar value={progress} tone={progress === 100 ? "gold" : "forest"} />
                </span>
              </span>
            </Link>
          ))}
        </div>
      </div>

      <Link
        href="/desktop"
        className="flex items-center justify-between rounded-2xl border border-line bg-parchment/40 px-4 py-3"
      >
        <span className="flex items-center gap-2 text-[11.5px] text-ink/60">
          <BookOpen className="h-3.5 w-3.5 text-moss" />
          需要精读和写作？切换到电脑端
        </span>
        <ArrowRight className="h-3.5 w-3.5 text-ink/35" />
      </Link>

      <p className="flex items-center justify-center gap-1.5 pb-1 text-[9.5px] text-ink/30">
        <Flame className="h-3 w-3" />
        学习档案与电脑端实时同步 · {entitlement.nextChargeNote}
      </p>
    </div>
  );
}
