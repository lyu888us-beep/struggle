import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, CheckCircle2, Clock, Lock } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getLessonDetail } from "@/lib/data";
import { AccessLocked } from "@/components/ui";
import { LessonContent } from "@/components/lesson-content";
import { LessonQuiz, SpeakButton } from "@/components/learning-client";

export const dynamic = "force-dynamic";

export default async function MobileLessonPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const { user, entitlement } = await getViewer();
  const detail = await getLessonDetail(slug, user.id);
  if (!detail) notFound();

  const { lesson, course, completed, score, previous, next } = detail;
  const canAccess = entitlement.canAccess;
  const visibleBlocks = canAccess ? lesson.content : lesson.content.slice(0, 2);

  return (
    <div className="space-y-3.5">
      <div className="flex items-center justify-between">
        <Link
          href={`/mobile/courses/${course.slug}`}
          className="inline-flex items-center gap-1 text-[11px] text-ink/50"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          {course.title}
        </Link>
        {completed && (
          <span className="rounded-full border border-forest/25 bg-forest/[0.06] px-2 py-0.5 text-[9.5px] text-forest">
            已完成{score !== null ? ` · ${score}分` : ""}
          </span>
        )}
      </div>

      <div>
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="rounded-full bg-forest/[0.07] px-2 py-0.5 text-[9px] font-semibold text-forest">
            {lesson.level}
          </span>
          <span className="flex items-center gap-1 text-[9.5px] text-ink/40">
            <Clock className="h-2.5 w-2.5" />
            {lesson.minutes} 分钟
          </span>
          <span className="text-[9.5px] text-ink/40">+{lesson.xp} XP</span>
        </div>
        <h1 className="mt-2 font-display text-[24px] leading-tight">{lesson.title}</h1>
        <p className="text-[11.5px] text-clay/80">{lesson.titleZh}</p>
        <div className="mt-2 flex items-start justify-between gap-2">
          <p className="text-[11px] leading-relaxed text-ink/50">{lesson.summary}</p>
          <SpeakButton text={lesson.summary} label="" />
        </div>
      </div>

      <div className="hairline" />

      <LessonContent blocks={visibleBlocks} />

      {!canAccess && (
        <div className="space-y-3">
          <div className="relative overflow-hidden rounded-2xl border border-line bg-[#fffdf8] p-3">
            <div className="select-none space-y-1.5 opacity-35 blur-[3px]">
              {lesson.content.slice(2, 5).map((block, index) => (
                <p key={index} className="text-[12px] leading-relaxed text-ink/70">
                  {"text" in block ? block.text : "关键表达与例句将在订阅后展开。"}
                </p>
              ))}
            </div>
            <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-clay/[0.07] px-2.5 py-2 text-[10.5px] text-clay">
              <Lock className="h-3 w-3" />
              正文后半部分与测验解析需要订阅解锁
            </p>
          </div>
          <AccessLocked compact />
        </div>
      )}

      <LessonQuiz
        lessonId={lesson.id}
        questions={lesson.quiz}
        canAccess={canAccess}
        nextLesson={next}
        basePath="/mobile"
      />

      <div className="flex gap-2">
        {previous ? (
          <Link
            href={`/mobile/lessons/${previous.slug}`}
            className="flex flex-1 items-center gap-1.5 rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5"
          >
            <ArrowLeft className="h-3 w-3 shrink-0 text-ink/30" />
            <span className="min-w-0">
              <span className="block text-[9px] text-ink/35">上一课</span>
              <span className="block truncate text-[10.5px] text-ink">{previous.title}</span>
            </span>
          </Link>
        ) : (
          <span className="flex-1" />
        )}
        {next ? (
          <Link
            href={`/mobile/lessons/${next.slug}`}
            className="flex flex-1 items-center justify-end gap-1.5 rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5 text-right"
          >
            <span className="min-w-0">
              <span className="block text-[9px] text-ink/35">下一课</span>
              <span className="block truncate text-[10.5px] text-ink">{next.title}</span>
            </span>
            <ArrowRight className="h-3 w-3 shrink-0 text-ink/30" />
          </Link>
        ) : (
          <Link
            href={`/mobile/courses/${course.slug}`}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-line bg-[#fffdf8] px-3 py-2.5 text-[10.5px] text-ink"
          >
            完成课程
            <CheckCircle2 className="h-3 w-3 text-forest" />
          </Link>
        )}
      </div>
    </div>
  );
}
