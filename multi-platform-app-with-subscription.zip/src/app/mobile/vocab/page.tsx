import { getViewer } from "@/lib/session";
import { getWordBank } from "@/lib/data";
import { WordStudio } from "@/components/word-studio";

export const dynamic = "force-dynamic";

export default async function MobileVocabPage() {
  const { user, entitlement } = await getViewer();
  const wordBank = await getWordBank(user.id);

  return (
    <div className="space-y-4">
      <div>
        <p className="text-[9.5px] uppercase tracking-[0.2em] text-moss/60">Vocabulary · SRS</p>
        <h1 className="mt-1 font-display text-[26px] leading-tight">词汇本</h1>
        <p className="mt-1 text-[11.5px] leading-relaxed text-ink/50">
          收藏 {wordBank.saved} 个 · 已掌握 {wordBank.mastered} 个 · 今日待复习 {wordBank.dueToday.length} 张
        </p>
      </div>

      <WordStudio items={wordBank.items} canAccess={entitlement.canAccess} compact />
    </div>
  );
}
