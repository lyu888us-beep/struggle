import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowUpRight, Check, Monitor, Smartphone } from "lucide-react";
import { getViewer } from "@/lib/session";
import { Logo } from "@/components/ui";
import { MobileTabBar } from "@/components/app-nav";

export const dynamic = "force-dynamic";

export default async function MobileLayout({ children }: { children: ReactNode }) {
  const { user, entitlement } = await getViewer();

  return (
    <div className="min-h-[100dvh] bg-parchment/60 lg:bg-[radial-gradient(ellipse_at_top,#e9e0cd_0%,#f7f2e7_55%,#efe7d6_100%)]">
      <div className="mx-auto flex min-h-[100dvh] max-w-[1400px] items-center justify-center gap-10 px-0 py-0 lg:px-8 lg:py-8">
        <div className="hidden w-[300px] shrink-0 xl:block">
          <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-moss/60">
            Nuance mobile
          </p>
          <h1 className="mt-3 font-display text-4xl leading-tight text-ink">
            口袋里的
            <br />
            高阶英语工作室
          </h1>
          <p className="mt-3 text-[12.5px] leading-relaxed text-ink/55">
            手机端为单手操作设计：今日一句、复习卡与微课时。
            与电脑端共享同一份学习档案，进度实时同步。
          </p>
          <ul className="mt-5 space-y-2">
            {["添加到主屏幕，像原生 App 一样打开", "复习卡利用碎片时间巩固记忆", "试用状态与订阅随时可查"].map(
              (item) => (
                <li key={item} className="flex items-start gap-2 text-[11.5px] text-ink/60">
                  <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-forest" />
                  {item}
                </li>
              ),
            )}
          </ul>
          <div className="mt-6 rounded-2xl border border-line bg-[#fffdf8] p-4">
            <p className="text-[11px] font-semibold text-ink">当前档案</p>
            <p className="mt-0.5 text-[11px] text-ink/50">
              {entitlement.planName} · {entitlement.statusLabel}
            </p>
            <p className="mt-1 text-[10.5px] text-ink/40">{entitlement.nextChargeNote}</p>
            <div className="mt-3 flex flex-col gap-2">
              <Link href="/desktop" className="btn btn-primary w-full text-[11.5px]">
                <Monitor className="h-3.5 w-3.5" />
                打开电脑端工作台
              </Link>
              <Link href="/" className="btn btn-ghost w-full text-[11.5px]">
                返回官网
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
          <p className="mt-4 flex items-center gap-1.5 text-[10px] text-ink/35">
            <Smartphone className="h-3 w-3" />
            在手机上打开即为全屏应用体验
          </p>
        </div>

        <div className="relative flex h-[100dvh] w-full flex-col overflow-hidden bg-cream md:h-[860px] md:max-h-[calc(100dvh-64px)] md:w-[416px] md:shrink-0 md:rounded-[44px] md:border-[9px] md:border-[#122018] md:shadow-[0_50px_90px_-50px_rgba(21,34,27,0.75)]">
          <div className="pointer-events-none absolute left-1/2 top-2 z-50 hidden h-5 w-24 -translate-x-1/2 rounded-full bg-[#122018] md:block" />

          <header className="shrink-0 border-b border-line/70 bg-cream/95 px-4 pb-2.5 pt-3 backdrop-blur md:pt-8">
            <div className="flex items-center justify-between">
              <Logo compact href="/mobile" />
              <div className="flex items-center gap-2">
                <Link
                  href={
                    entitlement.state === "trialing" || entitlement.state === "expired"
                      ? "/checkout?plan=annual"
                      : "/mobile/me/subscription"
                  }
                  className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold ${
                    entitlement.state === "expired"
                      ? "border-clay/30 bg-clay/10 text-clay"
                      : "border-forest/20 bg-forest/[0.06] text-forest"
                  }`}
                >
                  {entitlement.state === "trialing"
                    ? `试用 ${entitlement.trialDaysLeft} 天`
                    : entitlement.state === "expired"
                      ? "试用已结束"
                      : entitlement.planName}
                </Link>
                <Link
                  href="/mobile/me"
                  className="grid h-7 w-7 place-items-center rounded-full bg-forest text-[10px] font-semibold text-cream"
                >
                  {user.displayName.slice(0, 1)}
                </Link>
              </div>
            </div>
          </header>

          <main className="no-scrollbar flex-1 overflow-y-auto overscroll-contain px-4 pb-6 pt-3.5">
            {children}
          </main>

          <MobileTabBar />
        </div>
      </div>
    </div>
  );
}
