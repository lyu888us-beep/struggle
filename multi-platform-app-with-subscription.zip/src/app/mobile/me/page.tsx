import Link from "next/link";
import {
  ArrowRight,
  ChevronRight,
  CreditCard,
  Crown,
  Globe,
  Monitor,
  Receipt,
  Settings,
  Sparkles,
} from "lucide-react";
import { getViewer } from "@/lib/session";
import { getLearningOverview, getPayments } from "@/lib/data";
import { ProgressBar } from "@/components/ui";
import { formatCNY } from "@/lib/plans";

export const dynamic = "force-dynamic";

export default async function MobileMePage() {
  const { user, entitlement } = await getViewer();
  const [overview, payments] = await Promise.all([
    getLearningOverview(user.id),
    getPayments(user.id),
  ]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-forest font-display text-2xl text-cream">
          {user.displayName.slice(0, 1)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-xl leading-tight text-ink">{user.displayName}</p>
          <p className="text-[10.5px] text-ink/45">
            {user.email ?? "尚未设置收据邮箱"} · 版本切换随时可行
          </p>
          <div className="mt-1.5 flex items-center gap-1.5">
            <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[9.5px] text-ink/55">
              🔥 {overview.streak} 天连续
            </span>
            <span className="rounded-full border border-line bg-[#fffdf8] px-2 py-0.5 text-[9.5px] text-ink/55">
              {overview.totalXp} XP
            </span>
          </div>
        </div>
        <Link
          href="/mobile/me/settings"
          className="grid h-8 w-8 place-items-center rounded-full border border-line bg-[#fffdf8]"
        >
          <Settings className="h-3.5 w-3.5 text-ink/50" />
        </Link>
      </div>

      <div className="relative overflow-hidden rounded-[24px] border border-forest/20 bg-forest p-4 text-cream">
        <div className="grain absolute inset-0 opacity-30" />
        <div className="relative">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[9px] uppercase tracking-[0.22em] text-cream/40">Your plan</p>
              <p className="mt-1 font-display text-xl">{entitlement.planName}</p>
              <p className="text-[10.5px] text-cream/50">{entitlement.statusLabel}</p>
            </div>
            <Crown className={`h-5 w-5 ${entitlement.canAccess ? "text-gold" : "text-cream/30"}`} />
          </div>

          <p className="mt-2.5 text-[10.5px] leading-relaxed text-cream/55">
            {entitlement.nextChargeNote}
          </p>

          <div className="mt-2.5">
            <ProgressBar
              value={entitlement.state === "trialing" ? entitlement.trialProgress : 100}
              tone={entitlement.state === "expired" ? "clay" : "gold"}
              className="bg-cream/15"
            />
            <p className="mt-1 text-[9.5px] text-cream/40">
              {entitlement.state === "trialing"
                ? `7 天试用已使用 ${entitlement.trialProgress}%`
                : entitlement.state === "expired"
                  ? "订阅后立即恢复全部内容"
                  : "会员权益已解锁双端全部内容"}
            </p>
          </div>

          <div className="mt-3 flex gap-2">
            <Link
              href={entitlement.state === "expired" ? "/checkout?plan=annual" : "/mobile/me/subscription"}
              className="btn flex-1 bg-cream text-[11.5px] text-forest hover:bg-white"
            >
              <Sparkles className="h-3.5 w-3.5" />
              {entitlement.state === "expired" ? "立即订阅" : entitlement.state === "trialing" ? "升级会员" : "管理订阅"}
            </Link>
            <Link
              href="/mobile/me/subscription"
              className="btn border border-cream/25 bg-transparent px-3 text-[11.5px] text-cream"
            >
              账单
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {[
          ["完成课时", `${overview.completedLessons}/${overview.totalLessons}`, "累计分钟 " + overview.completedMinutes],
          ["收藏词汇", `${overview.wordsSaved}`, "已掌握 " + overview.wordsMastered],
          ["连续学习", `${overview.streak} 天`, "本周 +" + overview.weeklyXp + " XP"],
          ["本周学习", `${overview.recent.length} 节`, "最近一次已完成"],
        ].map(([label, value, hint]) => (
          <div key={label} className="card-quiet px-3.5 py-3">
            <p className="text-[9.5px] text-ink/40">{label}</p>
            <p className="font-display text-xl text-ink">{value}</p>
            <p className="truncate text-[9px] text-ink/35">{hint}</p>
          </div>
        ))}
      </div>

      <div className="card overflow-hidden">
        <p className="border-b border-line/70 px-4 py-2.5 text-[11px] font-semibold text-ink">最近账单</p>
        {payments.length === 0 ? (
          <div className="px-4 py-6 text-center">
            <Receipt className="mx-auto h-5 w-5 text-ink/20" />
            <p className="mt-1.5 text-[10.5px] text-ink/45">试用期间不会产生费用</p>
          </div>
        ) : (
          <div className="divide-y divide-line/60">
            {payments.slice(0, 2).map((payment) => (
              <Link
                key={payment.id}
                href={`/checkout/success?order=${payment.orderNo}`}
                className="flex items-center justify-between px-4 py-2.5"
              >
                <div>
                  <p className="text-[11px] font-medium text-ink">{payment.planName}</p>
                  <p className="font-mono text-[9px] text-ink/35">{payment.orderNo}</p>
                </div>
                <div className="text-right">
                  <p className="text-[11px] font-semibold text-ink">{formatCNY(payment.amountCents)}</p>
                  <p className="text-[9px] text-forest">已支付</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="card divide-y divide-line/60 overflow-hidden">
        {[
          { href: "/mobile/me/subscription", label: "订阅与账单", hint: "方案、发票与退款", icon: CreditCard },
          { href: "/mobile/me/settings", label: "设置", hint: "档案、设备与试用演示", icon: Settings },
          { href: "/desktop", label: "切换到电脑端", hint: "大屏精读与写作", icon: Monitor },
          { href: "/", label: "返回官网", hint: "课程体系与价格", icon: Globe },
        ].map((item) => (
          <Link key={item.href} href={item.href} className="flex items-center gap-3 px-4 py-3">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-forest/[0.06] text-forest">
              <item.icon className="h-4 w-4" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[12px] font-medium text-ink">{item.label}</span>
              <span className="block text-[9.5px] text-ink/40">{item.hint}</span>
            </span>
            <ChevronRight className="h-3.5 w-3.5 text-ink/25" />
          </Link>
        ))}
      </div>

      <Link
        href="/checkout?plan=annual"
        className="flex items-center justify-between rounded-2xl border border-gold/40 bg-gold/[0.08] px-4 py-3"
      >
        <span>
          <span className="block text-[11.5px] font-semibold text-[#8a6a2c]">年度会员 ¥468 · 相当于 ¥39/月</span>
          <span className="block text-[9.5px] text-ink/45">含写作批改与语调评估，随时可取消</span>
        </span>
        <ArrowRight className="h-4 w-4 text-[#8a6a2c]" />
      </Link>
    </div>
  );
}
