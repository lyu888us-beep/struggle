import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { getViewer } from "@/lib/session";
import { SettingsPanel } from "@/components/settings-client";

export const dynamic = "force-dynamic";

export default async function MobileSettingsPage() {
  const { user, entitlement } = await getViewer();

  return (
    <div className="space-y-3.5">
      <Link href="/mobile/me" className="inline-flex items-center gap-1 text-[11px] text-ink/50">
        <ArrowLeft className="h-3.5 w-3.5" />
        我的
      </Link>
      <div>
        <h1 className="font-display text-[26px] leading-tight">设置</h1>
        <p className="mt-1 text-[11.5px] leading-relaxed text-ink/50">
          档案与电脑端共享。演示工具可快速查看试用到期后的付费墙。
        </p>
      </div>
      <SettingsPanel
        displayName={user.displayName}
        email={user.email}
        preferredDevice={user.preferredDevice}
        autoRenew={user.autoRenew}
        planName={entitlement.planName}
        statusLabel={entitlement.statusLabel}
        nextChargeNote={entitlement.nextChargeNote}
        planId={user.plan}
        hasActivePaidPlan={entitlement.state === "active" && user.status === "active"}
        billingHref="/mobile/me/subscription"
      />
    </div>
  );
}
