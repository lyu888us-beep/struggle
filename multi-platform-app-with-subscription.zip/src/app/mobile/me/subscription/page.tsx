import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getPayments } from "@/lib/data";
import { BillingPanel } from "@/components/billing-panel";

export const dynamic = "force-dynamic";

export default async function MobileSubscriptionPage() {
  const { user, entitlement } = await getViewer();
  const payments = await getPayments(user.id);

  return (
    <div className="space-y-3.5">
      <Link href="/mobile/me" className="inline-flex items-center gap-1 text-[11px] text-ink/50">
        <ArrowLeft className="h-3.5 w-3.5" />
        我的
      </Link>
      <div>
        <h1 className="font-display text-[26px] leading-tight">订阅与账单</h1>
        <p className="mt-1 text-[11.5px] leading-relaxed text-ink/50">
          管理方案、续费与收据。取消后权益保留至本期结束。
        </p>
      </div>
      <BillingPanel user={user} entitlement={entitlement} payments={payments} compact />
    </div>
  );
}
