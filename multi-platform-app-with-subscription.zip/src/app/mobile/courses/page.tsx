import Link from "next/link";
import { ChevronRight, Lock } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getLearningOverview } from "@/lib/data";
import { ProgressBar } from "@/components/ui";

export const dynamic = "force-dynamic";

const categories = ["全部", "词汇", "写作", "口语", "发音", "商务", "阅读"];

export default async function MobileCoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ cat?: string }>;
}) {
  const { user, entitlement } = await getViewer();
  const overview = await getLearningOverview(user.id);
  const { cat } = await searchParams;
  const active = cat && categories.includes(cat) ? cat : "全部";
  const list =
    active === "全部"
      ? overview.courses
      : overview.courses.filter((item) => item.course.category === active);

  return (
    <div className="space-y-4">
      <div>
        <p className="text-[9.5px] uppercase tracking-[0.2em] text-moss/60">Curriculum</p>
        <h1 className="mt-1 font-display text-[26px] leading-tight">课程库</h1>
        <p className="mt-1 text-[11.5px] leading-relaxed text-ink/50">
          6 条高阶路径 · 已完成 {overview.completedLessons}/{overview.totalLessons} 课时
        </p>
      </div>

      {entitlement.state === "expired" && (
        <Link
          href="/checkout?plan=annual"
          className="flex items-center justify-between rounded-2xl border border-clay/25 bg-clay/[0.07] px-3.5 py-3"
        >
          <span className="text-[11px] leading-relaxed text-clay">
            试用已结束：课时可浏览，正文与测验需订阅解锁。
          </span>
          <span className="rounded-full bg-clay px-2 py-1 text-[10px] font-semibold text-white">订阅</span>
        </Link>
      )}

      <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1">
        {categories.map((category) => (
          <Link
            key={category}
            href={category === "全部" ? "/mobile/courses" : `/mobile/courses?cat=${encodeURIComponent(category)}`}
            className={`shrink-0 rounded-full border px-3 py-1.5 text-[11px] font-medium ${
              active === category
                ? "border-forest bg-forest text-cream"
                : "border-line bg-[#fffdf8] text-ink/55"
            }`}
          >
            {category}
          </Link>
        ))}
      </div>

      <div className="space-y-2.5">
        {list.map(({ course, progress, completedCount, lessonCount, nextLesson }) => (
          <Link
            key={course.id}
            href={`/mobile/courses/${course.slug}`}
            className="card block p-4 transition-transform active:scale-[0.99]"
          >
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-forest/[0.07] text-[16px] text-forest">
                {course.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-[13px] font-semibold text-ink">{course.title}</p>
                  <span className="flex shrink-0 items-center gap-1">
                    <span className="rounded-full border border-line px-1.5 py-0.5 text-[9px] text-moss">
                      {course.level}
                    </span>
                    {!entitlement.canAccess && <Lock className="h-3 w-3 text-clay/50" />}
                  </span>
                </div>
                <p className="mt-0.5 truncate text-[10px] uppercase tracking-[0.14em] text-ink/30">
                  {course.titleEn}
                </p>
                <p className="mt-1 text-[10.5px] text-clay/80">{course.tagline}</p>
                <div className="mt-2">
                  <ProgressBar value={progress} tone={progress === 100 ? "gold" : "forest"} />
                  <div className="mt-1 flex items-center justify-between text-[9.5px] text-ink/35">
                    <span>
                      {completedCount}/{lessonCount} 课时 · {course.category}
                    </span>
                    <span className="flex items-center font-medium text-forest">
                      {progress === 0 ? "开始" : progress === 100 ? "复习" : "继续"}
                      <ChevronRight className="h-3 w-3" />
                    </span>
                  </div>
                  {nextLesson && (
                    <p className="mt-1 truncate text-[9.5px] text-ink/30">下一课：{nextLesson.title}</p>
                  )}
                </div>
              </div>
            </div>
          </Link>
        ))}
        {list.length === 0 && (
          <p className="rounded-2xl border border-dashed border-line px-4 py-10 text-center text-[11px] text-ink/40">
            该分类下暂无课程
          </p>
        )}
      </div>
    </div>
  );
}
