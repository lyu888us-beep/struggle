import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CheckCircle2, ChevronRight, Clock, Lock, Play } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getCourseDetail } from "@/lib/data";
import { ProgressBar } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function MobileCourseDetail({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const { user, entitlement } = await getViewer();
  const detail = await getCourseDetail(slug, user.id);
  if (!detail) notFound();

  const { course, lessons, completedCount, progress } = detail;
  const nextLesson = lessons.find((lesson) => !lesson.completed) ?? lessons[0];

  return (
    <div className="space-y-3.5">
      <Link href="/mobile/courses" className="inline-flex items-center gap-1 text-[11px] text-ink/50">
        <ArrowLeft className="h-3.5 w-3.5" />
        课程库
      </Link>

      <div className="relative overflow-hidden rounded-[24px] border border-forest/20 bg-forest p-4 text-cream">
        <div className="grain absolute inset-0 opacity-30" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl border border-cream/15 bg-cream/10 text-[15px]">
              {course.emoji}
            </span>
            <div className="flex flex-wrap gap-1.5">
              <span className="rounded-full border border-cream/20 px-2 py-0.5 text-[9px]">{course.level}</span>
              <span className="rounded-full border border-cream/20 px-2 py-0.5 text-[9px]">{course.category}</span>
            </div>
          </div>
          <h1 className="mt-3 font-display text-[24px] leading-tight">{course.title}</h1>
          <p className="text-[11px] text-gold/80">{course.tagline}</p>
          <p className="mt-2 text-[11px] leading-relaxed text-cream/60">{course.description}</p>
          <div className="mt-3">
            <div className="flex items-center justify-between text-[10px] text-cream/55">
              <span>
                {completedCount}/{lessons.length} 课时 · 约 {course.minutes} 分钟
              </span>
              <span>{progress}%</span>
            </div>
            <div className="mt-1">
              <ProgressBar value={progress} tone="gold" className="bg-cream/15" />
            </div>
          </div>
          <Link
            href={`/mobile/lessons/${nextLesson.slug}`}
            className="btn mt-3 w-full bg-cream text-[12px] text-forest hover:bg-white"
          >
            <Play className="h-3.5 w-3.5" />
            {progress === 0 ? "开始第一课" : progress === 100 ? "从头复习" : "继续学习"}
          </Link>
        </div>
      </div>

      <div className="card overflow-hidden">
        <p className="border-b border-line/70 px-4 py-2.5 text-[11px] font-semibold text-ink">课时目录</p>
        <div className="divide-y divide-line/60">
          {lessons.map((lesson, index) => (
            <Link
              key={lesson.id}
              href={`/mobile/lessons/${lesson.slug}`}
              className="flex items-center gap-2.5 px-4 py-3"
            >
              <span
                className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border text-[10px] font-semibold ${
                  lesson.completed
                    ? "border-forest bg-forest text-cream"
                    : "border-line text-ink/40"
                }`}
              >
                {lesson.completed ? <CheckCircle2 className="h-3.5 w-3.5" /> : String(index + 1).padStart(2, "0")}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[12px] font-medium text-ink">{lesson.title}</span>
                <span className="block truncate text-[10px] text-ink/40">{lesson.titleZh}</span>
              </span>
              {lesson.score !== null && (
                <span className="rounded-full bg-forest/[0.07] px-1.5 py-0.5 text-[9px] font-semibold text-forest">
                  {lesson.score}分
                </span>
              )}
              <span className="flex items-center gap-1 text-[9px] text-ink/30">
                <Clock className="h-2.5 w-2.5" />
                {lesson.minutes}′
              </span>
              {!entitlement.canAccess ? (
                <Lock className="h-3 w-3 text-clay/50" />
              ) : (
                <ChevronRight className="h-3 w-3 text-ink/25" />
              )}
            </Link>
          ))}
        </div>
      </div>

      {!entitlement.canAccess && (
        <Link
          href="/checkout?plan=annual"
          className="flex items-center justify-between rounded-2xl border border-clay/25 bg-clay/[0.07] px-4 py-3"
        >
          <span className="text-[11px] text-clay">订阅后解锁全部正文、关键表达与测验解析</span>
          <ChevronRight className="h-3.5 w-3.5 text-clay" />
        </Link>
      )}
    </div>
  );
}
