"use server";

import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { lessonProgress, payments, users, wordProgress } from "@/db/schema";
import { getViewer } from "@/lib/session";
import {
  PAYMENT_METHODS,
  addPlanPeriod,
  findCoupon,
  isPlanId,
  priceBreakdown,
} from "@/lib/plans";
import type {
  CouponResult,
  LessonResult,
  PaymentResult,
  ReviewResult,
  SaveWordResult,
  SimpleResult,
} from "@/lib/action-types";

const DAY_MS = 86_400_000;

function refreshAll() {
  revalidatePath("/", "layout");
}

function createOrderNo(): string {
  const stamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, "")
    .slice(0, 14);
  const random = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `NCE${stamp}${random}`;
}

export async function validateCouponAction(code: string): Promise<CouponResult> {
  const coupon = findCoupon(code);
  if (!coupon) {
    return { ok: false, message: "优惠码无效或已过期" };
  }
  return { ok: true, percentOff: coupon.percentOff, label: coupon.label };
}

export async function submitPaymentAction(input: {
  plan: string;
  method: string;
  coupon?: string;
}): Promise<PaymentResult> {
  const { user } = await getViewer();

  if (!isPlanId(input.plan)) {
    return { ok: false, message: "请选择有效的订阅方案" };
  }
  if (!PAYMENT_METHODS.some((method) => method.id === input.method)) {
    return { ok: false, message: "请选择支付方式" };
  }
  if (input.coupon && input.coupon.trim().length > 0 && !findCoupon(input.coupon)) {
    return { ok: false, message: "优惠码无效，请移除后重试" };
  }

  if (user.plan === "lifetime") {
    return { ok: false, message: "你已是终身会员，无需重复购买" };
  }

  const pricing = priceBreakdown(input.plan, input.coupon);
  const now = new Date();
  const base =
    user.currentPeriodEnd && user.currentPeriodEnd.getTime() > now.getTime()
      ? user.currentPeriodEnd
      : now;
  const periodEnd = addPlanPeriod(base, input.plan);
  const orderNo = createOrderNo();

  await db.insert(payments).values({
    userId: user.id,
    orderNo,
    plan: input.plan,
    planName: pricing.plan.name,
    amountCents: pricing.totalCents,
    subtotalCents: pricing.subtotalCents,
    discountCents: pricing.discountCents,
    coupon: pricing.coupon?.code ?? null,
    method: input.method,
    status: "paid",
    periodStart: now,
    periodEnd,
  });

  await db
    .update(users)
    .set({
      plan: input.plan,
      status: "active",
      currentPeriodEnd: periodEnd,
      autoRenew: input.plan === "lifetime" ? false : true,
      updatedAt: now,
    })
    .where(eq(users.id, user.id));

  refreshAll();

  return {
    ok: true,
    orderNo,
    planName: pricing.plan.name,
    totalCents: pricing.totalCents,
  };
}

export async function completeLessonAction(input: {
  lessonId: number;
  score: number;
}): Promise<LessonResult> {
  const { user, entitlement } = await getViewer();
  if (!entitlement.canAccess) {
    return { ok: false, message: "试用已结束，订阅后即可保存学习记录" };
  }
  if (!Number.isFinite(input.lessonId) || input.lessonId <= 0) {
    return { ok: false, message: "课时不存在" };
  }

  const score = Math.max(0, Math.min(100, Math.round(input.score)));
  const now = new Date();

  await db
    .insert(lessonProgress)
    .values({
      userId: user.id,
      lessonId: input.lessonId,
      score,
      attempts: 1,
      completedAt: now,
    })
    .onConflictDoUpdate({
      target: [lessonProgress.userId, lessonProgress.lessonId],
      set: {
        score: sql`greatest(${lessonProgress.score}, ${score})`,
        attempts: sql`${lessonProgress.attempts} + 1`,
        completedAt: now,
      },
    });

  refreshAll();
  return { ok: true, score };
}

export async function toggleSavedWordAction(wordId: number): Promise<SaveWordResult> {
  const { user } = await getViewer();
  if (!Number.isFinite(wordId) || wordId <= 0) {
    return { ok: false, message: "词汇不存在" };
  }

  const existing = await db
    .select()
    .from(wordProgress)
    .where(and(eq(wordProgress.userId, user.id), eq(wordProgress.wordId, wordId)))
    .limit(1);

  if (existing[0]) {
    await db
      .delete(wordProgress)
      .where(and(eq(wordProgress.userId, user.id), eq(wordProgress.wordId, wordId)));
    refreshAll();
    return { ok: true, saved: false, message: "已从词汇本移除" };
  }

  await db.insert(wordProgress).values({
    userId: user.id,
    wordId,
    status: "learning",
    reviewCount: 0,
  });
  refreshAll();
  return { ok: true, saved: true, message: "已加入词汇本，明天开始复习" };
}

export async function reviewWordAction(
  wordId: number,
  status: "learning" | "review" | "mastered",
): Promise<ReviewResult> {
  const { user, entitlement } = await getViewer();
  if (!entitlement.canAccess) {
    return { ok: false, message: "试用已结束，订阅后可继续词汇复习" };
  }
  if (!["learning", "review", "mastered"].includes(status)) {
    return { ok: false, message: "复习状态无效" };
  }

  const now = new Date();
  await db
    .insert(wordProgress)
    .values({
      userId: user.id,
      wordId,
      status,
      reviewCount: 1,
      lastReviewedAt: now,
    })
    .onConflictDoUpdate({
      target: [wordProgress.userId, wordProgress.wordId],
      set: {
        status,
        reviewCount: sql`${wordProgress.reviewCount} + 1`,
        lastReviewedAt: now,
      },
    });

  refreshAll();
  return { ok: true, status };
}

export async function updateProfileAction(input: {
  displayName: string;
  email: string;
  preferredDevice: string;
  autoRenew: boolean;
}): Promise<SimpleResult> {
  const { user } = await getViewer();
  const displayName = input.displayName.trim().slice(0, 24) || "学习者";
  const email = input.email.trim().slice(0, 120);
  if (email.length > 0 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false, message: "邮箱格式不正确" };
  }

  await db
    .update(users)
    .set({
      displayName,
      email: email.length > 0 ? email : null,
      preferredDevice: input.preferredDevice === "mobile" ? "mobile" : "desktop",
      autoRenew: input.autoRenew,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));

  refreshAll();
  return { ok: true, message: "设置已保存" };
}

export async function cancelSubscriptionAction(): Promise<SimpleResult> {
  const { user } = await getViewer();
  if (user.plan === "lifetime") {
    return { ok: false, message: "终身会员无需取消" };
  }

  const now = new Date();
  if (user.plan === "monthly" || user.plan === "annual") {
    await db
      .update(users)
      .set({ status: "canceled", autoRenew: false, updatedAt: now })
      .where(eq(users.id, user.id));
    refreshAll();
    return {
      ok: true,
      message: "已关闭自动续费，会员权益保留至当前周期结束",
    };
  }

  await db
    .update(users)
    .set({
      status: "expired",
      plan: "trial",
      autoRenew: false,
      trialEndsAt: now,
      currentPeriodEnd: null,
      updatedAt: now,
    })
    .where(eq(users.id, user.id));

  refreshAll();
  return { ok: true, message: "试用已结束，订阅后可继续学习" };
}

export async function resumeSubscriptionAction(): Promise<SimpleResult> {
  const { user, entitlement } = await getViewer();
  if (user.plan !== "monthly" && user.plan !== "annual") {
    return { ok: false, message: "当前没有可恢复的订阅" };
  }
  if (!entitlement.periodEnd || entitlement.periodEnd.getTime() < Date.now()) {
    return { ok: false, message: "订阅已过期，请重新订阅" };
  }
  await db
    .update(users)
    .set({ status: "active", autoRenew: true, updatedAt: new Date() })
    .where(eq(users.id, user.id));
  refreshAll();
  return { ok: true, message: "自动续费已恢复" };
}

export async function simulateTrialExpiryAction(): Promise<SimpleResult> {
  const { user } = await getViewer();
  const now = Date.now();
  await db
    .update(users)
    .set({
      plan: "trial",
      status: "expired",
      trialStartedAt: new Date(now - 8 * DAY_MS),
      trialEndsAt: new Date(now - 3_600_000),
      currentPeriodEnd: null,
      autoRenew: false,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));
  refreshAll();
  return { ok: true, message: "已模拟试用到期，付费墙已开启" };
}

export async function restartTrialAction(): Promise<SimpleResult> {
  const { user } = await getViewer();
  const now = new Date();
  await db
    .update(users)
    .set({
      plan: "trial",
      status: "trialing",
      trialStartedAt: now,
      trialEndsAt: new Date(now.getTime() + 7 * DAY_MS),
      currentPeriodEnd: null,
      autoRenew: true,
      updatedAt: now,
    })
    .where(eq(users.id, user.id));
  refreshAll();
  return { ok: true, message: "已重置为全新的 7 天试用" };
}
