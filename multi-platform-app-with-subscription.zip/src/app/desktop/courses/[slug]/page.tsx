import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock,
  Crown,
  Lock,
  Play,
  Sparkles,
} from "lucide-react";
import { getViewer } from "@/lib/session";
import { getCourseCards, getCourseDetail } from "@/lib/data";
import { ProgressBar } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function DesktopCourseDetail({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const { user, entitlement } = await getViewer();
  const detail = await getCourseDetail(slug, user.id);
  if (!detail) notFound();

  const allCourses = await getCourseCards(user.id);
  const { course, lessons, completedCount, progress } = detail;
  const nextLesson = lessons.find((lesson) => !lesson.completed) ?? lessons[0];
  const others = allCourses.filter((item) => item.course.slug !== course.slug).slice(0, 3);

  return (
    <div className="space-y-4">
      <Link
        href="/desktop/courses"
        className="inline-flex items-center gap-1.5 text-[11.5px] text-ink/50 hover:text-ink"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        返回课程库
      </Link>

      <div className="relative overflow-hidden rounded-[28px] border border-forest/20 bg-forest p-6 text-cream md:p-8">
        <div className="grain absolute inset-0 opacity-30" />
        <div className="absolute -right-10 -top-16 h-52 w-52 rounded-full bg-gold/15 blur-3xl" />
        <div className="relative grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="grid h-11 w-11 place-items-center rounded-xl border border-cream/15 bg-cream/10 text-xl">
                {course.emoji}
              </span>
              <span className="rounded-full border border-cream/20 px-2.5 py-1 text-[10px] font-semibold">
                {course.level}
              </span>
              <span className="rounded-full border border-cream/20 px-2.5 py-1 text-[10px]">
                {course.category}
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-cream/40">
                {course.titleEn}
              </span>
            </div>
            <h1 className="mt-4 font-display text-[clamp(1.8rem,3vw,2.6rem)] leading-tight">
              {course.title}
            </h1>
            <p className="mt-1 text-[13px] text-gold/80">{course.tagline}</p>
            <p className="mt-3 max-w-xl text-[12.5px] leading-relaxed text-cream/60">
              {course.description}
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Link
                href={`/desktop/lessons/${nextLesson.slug}`}
                className="btn bg-cream text-[12.5px] text-forest hover:bg-white"
              >
                <Play className="h-3.5 w-3.5" />
                {progress === 0 ? "开始第一课" : progress === 100 ? "从头复习" : "继续学习"}
              </Link>
              <span className="flex items-center gap-1.5 text-[11px] text-cream/45">
                <Clock className="h-3.5 w-3.5" />
                {lessons.length} 课时 · 约 {course.minutes} 分钟
              </span>
            </div>
          </div>

          <div className="rounded-2xl border border-cream/15 bg-cream/[0.06] p-4">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-semibold text-cream">课程进度</p>
              <span className="font-display text-2xl">{progress}%</span>
            </div>
            <div className="mt-2">
              <ProgressBar value={progress} tone="gold" className="bg-cream/15" />
            </div>
            <p className="mt-2 text-[10.5px] text-cream/45">
              已完成 {completedCount} / {lessons.length} 课时
            </p>
            <div className="mt-4 space-y-1.5">
              {lessons.slice(0, 4).map((lesson, index) => (
                <div key={lesson.id} className="flex items-center gap-2 text-[10.5px]">
                  <span
                    className={`grid h-4 w-4 place-items-center rounded-full text-[8px] ${
                      lesson.completed ? "bg-gold text-[#2a1f08]" : "border border-cream/25 text-cream/40"
                    }`}
                  >
                    {lesson.completed ? "✓" : index + 1}
                  </span>
                  <span className={lesson.completed ? "text-cream/70" : "text-cream/45"}>
                    {lesson.title.slice(0, 30)}
                  </span>
                </div>
              ))}
              {lessons.length > 4 && (
                <p className="pl-6 text-[10px] text-cream/30">还有 {lessons.length - 4} 节…</p>
              )}
            </div>
            {!entitlement.canAccess && (
              <Link
                href="/checkout?plan=annual"
                className="btn mt-4 w-full bg-clay text-[11px] text-white hover:bg-[#a94726]"
              >
                <Lock className="h-3 w-3" />
                订阅后解锁全部课时
              </Link>
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.65fr_1fr]">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line/70 px-5 py-3.5">
            <h2 className="font-display text-lg">课时目录</h2>
            <span className="text-[10.5px] text-ink/40">{lessons.length} 个课时</span>
          </div>
          <div className="divide-y divide-line/60">
            {lessons.map((lesson, index) => (
              <Link
                key={lesson.id}
                href={`/desktop/lessons/${lesson.slug}`}
                className="group flex items-center gap-3 px-5 py-3.5 transition-colors hover:bg-parchment/25"
              >
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border text-[11px] font-semibold ${
                    lesson.completed
                      ? "border-forest bg-forest text-cream"
                      : "border-line bg-[#fffdf8] text-ink/45"
                  }`}
                >
                  {lesson.completed ? <CheckCircle2 className="h-4 w-4" /> : String(index + 1).padStart(2, "0")}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="text-[13px] font-medium text-ink">{lesson.title}</span>
                    <span className="rounded-full bg-parchment/60 px-1.5 py-0.5 text-[9px] text-moss">
                      {lesson.level}
                    </span>
                    {lesson.score !== null && (
                      <span className="rounded-full bg-forest/[0.07] px-1.5 py-0.5 text-[9px] font-semibold text-forest">
                        {lesson.score} 分
                      </span>
                    )}
                  </span>
                  <span className="mt-0.5 block truncate text-[11px] text-ink/45">{lesson.titleZh}</span>
                </span>
                <span className="hidden shrink-0 items-center gap-1 text-[10px] text-ink/35 sm:flex">
                  <Clock className="h-3 w-3" />
                  {lesson.minutes} 分钟
                </span>
                {!entitlement.canAccess ? (
                  <Lock className="h-3.5 w-3.5 shrink-0 text-clay/50" />
                ) : (
                  <ArrowRight className="h-3.5 w-3.5 shrink-0 text-ink/25 transition-transform group-hover:translate-x-0.5" />
                )}
              </Link>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-5">
            <h2 className="flex items-center gap-2 font-display text-lg">
              <Sparkles className="h-4 w-4 text-gold" />
              学习建议
            </h2>
            <ol className="mt-2.5 space-y-2 text-[11.5px] leading-relaxed text-ink/55">
              <li>1. 先通读正文，不查词，抓住作者的判断与语气。</li>
              <li>2. 再回看关键表达，把词放进例句里记，而不是记中文。</li>
              <li>3. 完成理解检查，低于 80 分建议当天重读一遍。</li>
              <li>4. 将陌生词加入词汇本，系统会安排间隔复习。</li>
            </ol>
          </div>

          <div className="card p-5">
            <h2 className="font-display text-lg">同一路径的其他课程</h2>
            <div className="mt-2.5 space-y-2">
              {others.map(({ course: other, progress: otherProgress }) => (
                <Link
                  key={other.id}
                  href={`/desktop/courses/${other.slug}`}
                  className="flex items-center gap-2.5 rounded-xl border border-line/80 bg-[#fffdf8] px-3 py-2.5 transition-colors hover:border-forest/30"
                >
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-forest/[0.07] text-[12px] text-forest">
                    {other.emoji}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[12px] font-medium text-ink">{other.title}</span>
                    <span className="block text-[10px] text-ink/40">
                      {other.level} · 进度 {otherProgress}%
                    </span>
                  </span>
                  <ArrowRight className="h-3 w-3 text-ink/25" />
                </Link>
              ))}
            </div>
          </div>

          {entitlement.state !== "expired" && (
            <div className="rounded-[22px] border border-gold/40 bg-gold/[0.08] p-4">
              <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-[#8a6a2c]">
                <Crown className="h-3.5 w-3.5" />
                年度会员 · 相当于 ¥39/月
              </p>
              <p className="mt-1 text-[11px] leading-relaxed text-ink/55">
                含词汇精讲回放、每月 4 次写作批改与语调评估报告。
              </p>
              <Link href="/checkout?plan=annual" className="btn btn-primary mt-3 w-full text-[11.5px]">
                查看会员权益
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
