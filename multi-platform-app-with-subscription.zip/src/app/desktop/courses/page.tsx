import Link from "next/link";
import { ArrowRight, CheckCircle2, Clock, Layers, Lock } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getLearningOverview } from "@/lib/data";
import { AccessLocked, ProgressBar } from "@/components/ui";

export const dynamic = "force-dynamic";

const categories = ["全部", "词汇", "写作", "口语", "发音", "商务", "阅读"];

export default async function DesktopCoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ cat?: string }>;
}) {
  const { user, entitlement } = await getViewer();
  const { cat } = await searchParams;
  const overview = await getLearningOverview(user.id);
  const activeCategory = cat && categories.includes(cat) ? cat : "全部";
  const visible =
    activeCategory === "全部"
      ? overview.courses
      : overview.courses.filter((item) => item.course.category === activeCategory);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
            Curriculum · {overview.courses.length} courses
          </p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,2.6vw,2.3rem)]">课程库</h1>
          <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-ink/50">
            六条路径覆盖词义、写作、口语、发音与阅读。每节课 11–18 分钟，读完即练，成绩写入学习档案。
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-ink/45">
          <span className="chip">
            <CheckCircle2 className="h-3 w-3" />
            已完成 {overview.completedLessons}/{overview.totalLessons}
          </span>
          <span className="chip">
            <Clock className="h-3 w-3" />
            累计 {overview.completedMinutes} 分钟
          </span>
        </div>
      </div>

      {entitlement.state === "expired" && <AccessLocked compact />}

      <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
        {categories.map((category) => (
          <Link
            key={category}
            href={category === "全部" ? "/desktop/courses" : `/desktop/courses?cat=${encodeURIComponent(category)}`}
            className={`shrink-0 rounded-full border px-3.5 py-1.5 text-[11.5px] font-medium transition-colors ${
              activeCategory === category
                ? "border-forest bg-forest text-cream"
                : "border-line bg-[#fffdf8] text-ink/55 hover:border-moss/40"
            }`}
          >
            {category}
          </Link>
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {visible.map(({ course, lessonCount, completedCount, progress, nextLesson }) => (
          <div key={course.id} className="card group flex flex-col p-5">
            <div className="flex items-start justify-between">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-forest/[0.07] text-[17px] text-forest">
                {course.emoji}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="rounded-full border border-line px-2 py-0.5 text-[10px] font-semibold text-moss">
                  {course.level}
                </span>
                {!entitlement.canAccess && <Lock className="h-3.5 w-3.5 text-clay/60" />}
              </div>
            </div>
            <p className="mt-3 text-[9.5px] uppercase tracking-[0.2em] text-ink/35">{course.titleEn}</p>
            <h2 className="mt-0.5 font-display text-xl">{course.title}</h2>
            <p className="mt-0.5 text-[11.5px] text-clay/80">{course.tagline}</p>
            <p className="mt-2 line-clamp-2 flex-1 text-[11.5px] leading-relaxed text-ink/50">
              {course.description}
            </p>

            <div className="mt-3.5">
              <div className="flex items-center justify-between text-[10px] text-ink/40">
                <span>进度 {progress}%</span>
                <span>
                  {completedCount}/{lessonCount} 课时
                </span>
              </div>
              <div className="mt-1.5">
                <ProgressBar value={progress} tone={progress === 100 ? "gold" : "forest"} />
              </div>
            </div>

            <div className="mt-3.5 flex items-center justify-between border-t border-line/70 pt-3">
              <span className="flex items-center gap-1 text-[10.5px] text-ink/40">
                <Layers className="h-3 w-3" />
                {lessonCount} 节 · {course.category}
              </span>
              <Link
                href={`/desktop/courses/${course.slug}`}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-forest transition-colors hover:text-clay"
              >
                {progress === 0 ? "开始课程" : progress === 100 ? "复习课程" : "继续"}
                <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </div>
            {nextLesson && (
              <p className="mt-2 truncate text-[10px] text-ink/35">下一课：{nextLesson.title}</p>
            )}
          </div>
        ))}
      </div>

      {visible.length === 0 && (
        <p className="rounded-2xl border border-dashed border-line px-6 py-12 text-center text-[12px] text-ink/40">
          该分类下暂无课程
        </p>
      )}
    </div>
  );
}
