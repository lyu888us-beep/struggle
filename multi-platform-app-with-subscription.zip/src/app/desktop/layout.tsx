import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowUpRight, Crown, Sparkles } from "lucide-react";
import { getViewer } from "@/lib/session";
import { DesktopNav } from "@/components/app-nav";
import { DeviceLinks, Logo, ProgressBar, StatusPill } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function DesktopLayout({ children }: { children: ReactNode }) {
  const { user, entitlement } = await getViewer();

  return (
    <div className="min-h-screen bg-cream">
      <div className="mx-auto flex min-h-screen max-w-[1600px]">
        {/* Sidebar */}
        <aside className="sticky top-0 hidden h-screen w-[248px] shrink-0 flex-col overflow-y-auto bg-forest px-3.5 py-5 text-cream lg:flex">
          <div className="px-2">
            <Logo tone="light" href="/" />
          </div>

          <p className="mt-7 px-3 text-[9px] font-semibold uppercase tracking-[0.24em] text-cream/30">
            Workspace
          </p>
          <div className="mt-2">
            <DesktopNav />
          </div>

          <div className="mt-auto space-y-3 pt-6">
            <div className="rounded-2xl border border-cream/15 bg-cream/[0.06] p-3.5">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-semibold text-cream">
                  {entitlement.state === "expired" ? "试用已结束" : entitlement.planName}
                </p>
                {entitlement.state !== "expired" ? (
                  <Crown className="h-3.5 w-3.5 text-gold" />
                ) : (
                  <Sparkles className="h-3.5 w-3.5 text-clay" />
                )}
              </div>
              <div className="mt-2">
                <ProgressBar
                  value={entitlement.state === "trialing" ? entitlement.trialProgress : entitlement.canAccess ? 100 : 100}
                  tone={entitlement.state === "expired" ? "clay" : "gold"}
                  className="bg-cream/15"
                />
              </div>
              <p className="mt-1.5 text-[10px] leading-relaxed text-cream/45">
                {entitlement.nextChargeNote}
              </p>
              <Link
                href={
                  entitlement.state === "trialing" || entitlement.state === "expired"
                    ? "/checkout?plan=annual"
                    : "/desktop/billing"
                }
                className="mt-2.5 flex w-full items-center justify-center gap-1 rounded-full bg-cream px-2 py-1.5 text-[10.5px] font-semibold text-forest transition-colors hover:bg-white"
              >
                {entitlement.state === "trialing" ? "升级为年度会员" : entitlement.state === "expired" ? "立即订阅恢复学习" : "管理订阅"}
                <ArrowUpRight className="h-3 w-3" />
              </Link>
            </div>

            <div className="rounded-xl border border-cream/10 px-3 py-2.5">
              <p className="text-[10px] leading-relaxed text-cream/40">
                手机端同步可用
              </p>
              <Link
                href="/mobile"
                className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-cream/80 hover:text-cream"
              >
                切换到手机端
                <ArrowUpRight className="h-3 w-3" />
              </Link>
            </div>
          </div>
        </aside>

        {/* Main */}
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-30 border-b border-line/70 bg-cream/90 backdrop-blur-md">
            <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
              <div className="flex items-center gap-3">
                <div className="lg:hidden">
                  <Logo compact href="/" />
                </div>
                <div className="hidden sm:block">
                  <p className="text-[10px] uppercase tracking-[0.22em] text-moss/60">
                    Desktop workspace
                  </p>
                  <p className="text-[12.5px] font-medium text-ink/70">
                    {new Intl.DateTimeFormat("zh-CN", {
                      month: "long",
                      day: "numeric",
                      weekday: "long",
                    }).format(new Date())}
                    <span className="ml-2 text-ink/35">· 每日一词已更新</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="hidden items-center gap-2 md:flex">
                  <span className="chip">🔥 连续 {user.id % 7 + 1} 天</span>
                  <StatusPill entitlement={entitlement} />
                </div>
                <div className="hidden sm:block">
                  <DeviceLinks current="desktop" />
                </div>
                <div className="flex items-center gap-2 rounded-full border border-line bg-[#fffdf8] py-1 pl-1 pr-2.5">
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-forest text-[10px] font-semibold text-cream">
                    {user.displayName.slice(0, 1)}
                  </span>
                  <span className="text-[11px] font-medium text-ink/70">{user.displayName}</span>
                </div>
              </div>
            </div>
            <nav className="no-scrollbar flex items-center gap-1 overflow-x-auto px-4 pb-2 lg:hidden">
              {[
                ["/desktop", "学习台"],
                ["/desktop/courses", "课程库"],
                ["/desktop/vocab", "词汇本"],
                ["/desktop/billing", "订阅"],
                ["/desktop/settings", "设置"],
              ].map(([href, label]) => (
                <Link
                  key={href}
                  href={href}
                  className="shrink-0 rounded-full border border-line bg-[#fffdf8] px-3 py-1.5 text-[11px] font-medium text-ink/60"
                >
                  {label}
                </Link>
              ))}
            </nav>
          </header>

          {entitlement.state === "expired" && (
            <div className="border-b border-clay/20 bg-clay/[0.07] px-4 py-2.5 md:px-6">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-[11.5px] text-clay">
                  7 天试用已结束 · 课程正文与测验已锁定，你的学习记录仍然完整保留。
                </p>
                <Link href="/checkout?plan=annual" className="btn btn-clay text-[11px]">
                  立即订阅，恢复全部内容
                </Link>
              </div>
            </div>
          )}

          <main className="flex-1 px-4 py-5 md:px-6 md:py-6">
            <div className="mx-auto w-full max-w-[1180px]">{children}</div>
          </main>
        </div>
      </div>
    </div>
  );
}
