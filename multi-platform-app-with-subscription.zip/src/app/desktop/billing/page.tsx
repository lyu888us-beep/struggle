import { getViewer } from "@/lib/session";
import { getPayments } from "@/lib/data";
import { BillingPanel } from "@/components/billing-panel";

export const dynamic = "force-dynamic";

export default async function DesktopBillingPage() {
  const { user, entitlement } = await getViewer();
  const payments = await getPayments(user.id);

  return (
    <div className="space-y-5">
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
          Subscription & billing
        </p>
        <h1 className="mt-2 font-display text-[clamp(1.7rem,2.6vw,2.3rem)]">订阅与账单</h1>
        <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-ink/50">
          试用期结束后需要有效订阅才能继续课程与复习。一次订阅同时覆盖电脑端与手机端，
          可随时关闭自动续费，7 天内支持退款。
        </p>
      </div>

      <BillingPanel user={user} entitlement={entitlement} payments={payments} />
    </div>
  );
}
