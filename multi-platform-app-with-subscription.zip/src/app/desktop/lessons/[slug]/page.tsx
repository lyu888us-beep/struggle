import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock,
  ListChecks,
  Lock,
  Sparkles,
} from "lucide-react";
import type { LessonBlock } from "@/db/schema";
import { getViewer } from "@/lib/session";
import { getLessonDetail, getWordBank } from "@/lib/data";
import { AccessLocked, ProgressBar, StatusPill } from "@/components/ui";
import { LessonContent } from "@/components/lesson-content";
import { LessonQuiz, SaveWordButton, SpeakButton } from "@/components/learning-client";

export const dynamic = "force-dynamic";

export default async function DesktopLessonPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const { user, entitlement } = await getViewer();
  const detail = await getLessonDetail(slug, user.id);
  if (!detail) notFound();

  const wordBank = await getWordBank(user.id);
  const { lesson, course, completed, score, previous, next, siblings } = detail;
  const canAccess = entitlement.canAccess;
  const visibleBlocks = canAccess ? lesson.content : lesson.content.slice(0, 2);
  const phraseBlock = lesson.content.find((block): block is Extract<LessonBlock, { type: "phrases" }> =>
    block.type === "phrases",
  );
  const recommended = wordBank.items.filter((item) => !item.progress).slice(0, 3);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link
          href={`/desktop/courses/${course.slug}`}
          className="inline-flex items-center gap-1.5 text-[11.5px] text-ink/50 hover:text-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          {course.title}
        </Link>
        <div className="flex items-center gap-2">
          {completed && (
            <span className="chip border-forest/25 bg-forest/[0.06] text-forest">
              <CheckCircle2 className="h-3 w-3" />
              已完成{score !== null ? ` · ${score} 分` : ""}
            </span>
          )}
          <StatusPill entitlement={entitlement} />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-4">
          <article className="card p-5 md:p-7">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-forest/[0.07] px-2.5 py-1 text-[10px] font-semibold text-forest">
                {lesson.level}
              </span>
              <span className="flex items-center gap-1 text-[10.5px] text-ink/40">
                <Clock className="h-3 w-3" />
                {lesson.minutes} 分钟
              </span>
              <span className="text-[10.5px] text-ink/40">+{lesson.xp} XP</span>
              <span className="text-[10px] uppercase tracking-[0.16em] text-ink/30">
                {course.titleEn}
              </span>
            </div>
            <h1 className="mt-3 font-display text-[clamp(1.6rem,2.8vw,2.2rem)] leading-tight">
              {lesson.title}
            </h1>
            <p className="mt-1 text-[13px] text-clay/80">{lesson.titleZh}</p>
            <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
              <p className="max-w-xl text-[12.5px] leading-relaxed text-ink/55">{lesson.summary}</p>
              <SpeakButton text={`${lesson.title}. ${lesson.summary}`} label="朗读本课" />
            </div>
            <div className="hairline my-5" />
            <LessonContent blocks={visibleBlocks} />

            {!canAccess && (
              <div className="mt-5">
                <div className="relative overflow-hidden rounded-2xl">
                  <div className="pointer-events-none select-none space-y-2 opacity-40 blur-[3px]">
                    {lesson.content.slice(2, 5).map((block, index) => (
                      <p key={index} className="text-[13px] leading-relaxed text-ink/70">
                        {"text" in block ? block.text : "关键表达与例句将在订阅后展开。"}
                      </p>
                    ))}
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#fffdf8]/70 to-[#fffdf8]" />
                  <div className="relative mt-3 flex items-center gap-2 rounded-xl border border-clay/25 bg-clay/[0.06] px-3.5 py-2.5 text-[11.5px] text-clay">
                    <Lock className="h-3.5 w-3.5" />
                    以下正文、关键表达与测验解析需要订阅后解锁
                  </div>
                </div>
              </div>
            )}
          </article>

          {!canAccess && <AccessLocked />}

          <LessonQuiz
            lessonId={lesson.id}
            questions={lesson.quiz}
            canAccess={canAccess}
            nextLesson={next}
            basePath="/desktop"
          />

          <div className="flex items-center justify-between gap-2">
            {previous ? (
              <Link
                href={`/desktop/lessons/${previous.slug}`}
                className="card-quiet flex min-w-0 flex-1 items-center gap-2 px-4 py-3 transition-colors hover:border-forest/30"
              >
                <ArrowLeft className="h-3.5 w-3.5 shrink-0 text-ink/35" />
                <span className="min-w-0">
                  <span className="block text-[10px] text-ink/35">上一课</span>
                  <span className="block truncate text-[12px] font-medium text-ink">{previous.title}</span>
                </span>
              </Link>
            ) : (
              <span className="flex-1" />
            )}
            {next && (
              <Link
                href={`/desktop/lessons/${next.slug}`}
                className="card-quiet flex min-w-0 flex-1 items-center justify-end gap-2 px-4 py-3 text-right transition-colors hover:border-forest/30"
              >
                <span className="min-w-0">
                  <span className="block text-[10px] text-ink/35">下一课</span>
                  <span className="block truncate text-[12px] font-medium text-ink">{next.title}</span>
                </span>
                <ArrowRight className="h-3.5 w-3.5 shrink-0 text-ink/35" />
              </Link>
            )}
          </div>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <div className="card p-5">
            <h2 className="flex items-center gap-2 font-display text-lg">
              <ListChecks className="h-4 w-4 text-moss" />
              本课目录
            </h2>
            <div className="mt-2.5 space-y-1">
              {siblings.map((item, index) => (
                <Link
                  key={item.slug}
                  href={`/desktop/lessons/${item.slug}`}
                  className={`flex items-center gap-2 rounded-lg px-2.5 py-2 text-[11.5px] transition-colors ${
                    item.slug === lesson.slug
                      ? "bg-forest/[0.07] font-semibold text-forest"
                      : "text-ink/55 hover:bg-parchment/40"
                  }`}
                >
                  <span
                    className={`grid h-4 w-4 shrink-0 place-items-center rounded-full text-[8px] ${
                      item.completed
                        ? "bg-forest text-cream"
                        : item.slug === lesson.slug
                          ? "bg-forest/15 text-forest"
                          : "border border-line text-ink/30"
                    }`}
                  >
                    {item.completed ? "✓" : index + 1}
                  </span>
                  <span className="truncate">{item.title}</span>
                </Link>
              ))}
            </div>
            <div className="mt-3">
              <ProgressBar
                value={Math.round(
                  (siblings.filter((item) => item.completed).length / Math.max(1, siblings.length)) * 100,
                )}
              />
              <p className="mt-1.5 text-[10px] text-ink/40">
                本课程已完成 {siblings.filter((item) => item.completed).length}/{siblings.length} 课时
              </p>
            </div>
          </div>

          {phraseBlock && (
            <div className="card p-5">
              <h2 className="font-display text-lg">本课关键表达</h2>
              <div className="mt-2.5 space-y-2.5">
                {phraseBlock.items.map((item) => (
                  <div key={item.en}>
                    <p className="text-[12.5px] font-medium text-ink">{item.en}</p>
                    <p className="text-[10.5px] leading-relaxed text-ink/45">{item.zh}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="card p-5">
            <h2 className="flex items-center gap-2 font-display text-lg">
              <BookOpen className="h-4 w-4 text-clay" />
              推荐加入词汇本
            </h2>
            <div className="mt-2.5 space-y-2">
              {recommended.map((item) => (
                <div
                  key={item.word.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-line/80 bg-[#fffdf8] px-3 py-2.5"
                >
                  <div className="min-w-0">
                    <p className="text-[12px] font-medium text-ink">{item.word.word}</p>
                    <p className="truncate text-[10px] text-ink/45">{item.word.meaningZh}</p>
                  </div>
                  <SaveWordButton wordId={item.word.id} saved={false} compact />
                </div>
              ))}
              {recommended.length === 0 && (
                <p className="rounded-xl border border-dashed border-line px-3 py-4 text-center text-[10.5px] text-ink/40">
                  你已收藏全部词汇
                </p>
              )}
            </div>
            <Link href="/desktop/vocab" className="mt-3 inline-flex items-center gap-1 text-[10.5px] text-moss hover:text-forest">
              打开词汇本
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="rounded-[22px] border border-line bg-parchment/30 p-4">
            <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
              <Sparkles className="h-3.5 w-3.5 text-gold" />
              学习提示
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-ink/55">
              本课约 {lesson.minutes} 分钟。建议先朗读一遍正文，再做理解检查；低于 80 分时，隔一天重读效果最好。
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
