import { getViewer } from "@/lib/session";
import { SettingsPanel } from "@/components/settings-client";

export const dynamic = "force-dynamic";

export default async function DesktopSettingsPage() {
  const { user, entitlement } = await getViewer();

  return (
    <div className="space-y-5">
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
          Preferences
        </p>
        <h1 className="mt-2 font-display text-[clamp(1.7rem,2.6vw,2.3rem)]">设置</h1>
        <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-ink/50">
          管理你的学习档案、默认设备与订阅偏好。演示工具可以快速切换「试用中」与「试用到期」两种状态。
        </p>
      </div>

      <div className="max-w-3xl">
        <SettingsPanel
          displayName={user.displayName}
          email={user.email}
          preferredDevice={user.preferredDevice}
          autoRenew={user.autoRenew}
          planName={entitlement.planName}
          statusLabel={entitlement.statusLabel}
          nextChargeNote={entitlement.nextChargeNote}
          planId={user.plan}
          hasActivePaidPlan={entitlement.state === "active" && user.status === "active"}
          billingHref="/desktop/billing"
        />
      </div>
    </div>
  );
}
