import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Bookmark,
  CheckCircle2,
  Clock,
  Crown,
  Flame,
  Library,
  Play,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";
import { getViewer, formatDate } from "@/lib/session";
import { getLearningOverview, getWordBank } from "@/lib/data";
import { AccessLocked, ProgressBar, ProgressRing, StatusPill, StatCard } from "@/components/ui";
import { SaveWordButton, SpeakButton } from "@/components/learning-client";

export const dynamic = "force-dynamic";

function greeting(): string {
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hour12: false, timeZone: "Asia/Shanghai" }).format(
      new Date(),
    ),
  );
  if (hour < 6) return "夜深了";
  if (hour < 12) return "早上好";
  if (hour < 18) return "下午好";
  return "晚上好";
}

export default async function DesktopDashboard() {
  const { user, entitlement } = await getViewer();
  const [overview, wordBank] = await Promise.all([
    getLearningOverview(user.id),
    getWordBank(user.id),
  ]);

  const wordOfDay = overview.wordOfDay;
  const wordSaved = wordOfDay
    ? wordBank.items.find((item) => item.word.id === wordOfDay.id)?.progress
    : null;

  const completedToday = overview.recent.some(
    (item) =>
      formatDate(item.completedAt) === formatDate(new Date()),
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
            <span className="h-px w-6 bg-clay/60" />
            Your studio
          </p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,2.6vw,2.3rem)] leading-tight">
            {greeting()}，{user.displayName}
            <span className="text-clay">.</span>
          </h1>
          <p className="mt-1 text-[12.5px] text-ink/50">
            {entitlement.state === "expired"
              ? "试用已结束，订阅后可继续课程与复习。"
              : overview.completedLessons === 0
                ? "从第一节课开始，今天只需要 14 分钟。"
                : `已完成 ${overview.completedLessons} 节课，保持这个节奏。`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <StatusPill entitlement={entitlement} />
          <Link href="/desktop/courses" className="btn btn-ghost text-[12px]">
            <Library className="h-3.5 w-3.5" />
            课程库
          </Link>
        </div>
      </div>

      {entitlement.state === "expired" && <AccessLocked />}

      <div className="grid gap-4 lg:grid-cols-[1.55fr_1fr]">
        <div className="space-y-4">
          {overview.continueLesson ? (
            <div className="relative overflow-hidden rounded-[26px] border border-forest/20 bg-forest p-6 text-cream">
              <div className="grain absolute inset-0 opacity-30" />
              <div className="absolute -right-8 -top-10 h-40 w-40 rounded-full bg-gold/15 blur-3xl" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-cream/20 bg-cream/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em]">
                    Continue learning
                  </span>
                  <span className="text-[11px] text-cream/45">
                    {overview.continueLesson.level} · {overview.continueLesson.minutes} 分钟
                  </span>
                </div>
                <p className="mt-4 text-[11.5px] text-gold/80">{overview.continueLesson.courseTitle}</p>
                <h2 className="mt-1 font-display text-2xl leading-snug md:text-3xl">
                  {overview.continueLesson.title}
                </h2>
                <p className="mt-1 text-[12.5px] text-cream/55">{overview.continueLesson.titleZh}</p>
                <div className="mt-5 flex flex-wrap items-center gap-3">
                  <Link
                    href={`/desktop/lessons/${overview.continueLesson.slug}`}
                    className="btn bg-cream text-[12.5px] text-forest hover:bg-white"
                  >
                    <Play className="h-3.5 w-3.5" />
                    继续这一课
                  </Link>
                  <Link
                    href={`/desktop/courses/${overview.continueLesson.courseSlug}`}
                    className="inline-flex items-center gap-1 text-[11.5px] text-cream/60 hover:text-cream"
                  >
                    查看课程大纲
                    <ArrowUpRight className="h-3 w-3" />
                  </Link>
                  <span className="ml-auto hidden items-center gap-1.5 text-[11px] text-cream/40 sm:flex">
                    <Target className="h-3.5 w-3.5" />+{overview.continueLesson.xp} XP
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="card p-6">
              <CheckCircle2 className="h-6 w-6 text-forest" />
              <h2 className="mt-3 font-display text-2xl">所有课时都已完成</h2>
              <p className="mt-1 text-[12.5px] text-ink/50">
                去词汇本巩固记忆，等待新课程上线。
              </p>
              <Link href="/desktop/vocab" className="btn btn-primary mt-4 text-[12px]">
                打开词汇本
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard
              label="连续学习"
              value={`${overview.streak} 天`}
              hint={overview.streak > 0 ? "保持住" : "今天开始"}
              icon={<Flame className="h-4 w-4 text-clay" />}
            />
            <StatCard
              label="完成课时"
              value={`${overview.completedLessons}/${overview.totalLessons}`}
              hint={`累计 ${overview.completedMinutes} 分钟`}
              icon={<BookOpen className="h-4 w-4" />}
            />
            <StatCard
              label="已掌握词汇"
              value={`${overview.wordsMastered}`}
              hint={`收藏 ${overview.wordsSaved} 个`}
              icon={<Bookmark className="h-4 w-4" />}
            />
            <StatCard
              label="总 XP"
              value={overview.totalXp}
              hint={`本周 +${overview.weeklyXp}`}
              icon={<TrendingUp className="h-4 w-4" />}
            />
          </div>

          <div className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl">课程进度</h2>
              <Link
                href="/desktop/courses"
                className="inline-flex items-center gap-1 text-[11.5px] font-medium text-moss hover:text-forest"
              >
                全部课程
                <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {overview.courses.slice(0, 4).map(({ course, progress, completedCount, lessonCount }) => (
                <Link
                  key={course.id}
                  href={`/desktop/courses/${course.slug}`}
                  className="group rounded-2xl border border-line/80 bg-[#fffdf8] p-3.5 transition-colors hover:border-forest/30"
                >
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <span className="grid h-7 w-7 place-items-center rounded-lg bg-forest/[0.07] text-[12px] text-forest">
                        {course.emoji}
                      </span>
                      <span className="text-[12.5px] font-semibold text-ink">{course.title}</span>
                    </span>
                    <span className="text-[10.5px] text-ink/40">{progress}%</span>
                  </div>
                  <div className="mt-2.5">
                    <ProgressBar value={progress} tone={progress === 100 ? "gold" : "forest"} />
                  </div>
                  <p className="mt-1.5 text-[10px] text-ink/40">
                    {completedCount}/{lessonCount} 课时 · {course.level}
                  </p>
                </Link>
              ))}
            </div>
          </div>

          <div className="card p-5">
            <h2 className="font-display text-xl">最近学习</h2>
            {overview.recent.length === 0 ? (
              <p className="mt-2 rounded-xl border border-dashed border-line px-4 py-6 text-center text-[11.5px] text-ink/40">
                还没有学习记录，完成第一节课后会出现在这里。
              </p>
            ) : (
              <div className="mt-3 divide-y divide-line/60">
                {overview.recent.map((item) => (
                  <Link
                    key={item.lessonId}
                    href={`/desktop/lessons/${item.slug}`}
                    className="flex items-center justify-between gap-3 py-2.5 transition-colors hover:text-forest"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-[12.5px] font-medium text-ink">
                        {item.title}
                      </span>
                      <span className="block text-[10.5px] text-ink/40">
                        {item.courseTitle} · {formatDate(item.completedAt)}
                      </span>
                    </span>
                    <span className="flex shrink-0 items-center gap-2">
                      <span className="rounded-full bg-forest/[0.07] px-2 py-0.5 text-[10px] font-semibold text-forest">
                        {item.score} 分
                      </span>
                      <ArrowUpRight className="h-3.5 w-3.5 text-ink/30" />
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right rail */}
        <div className="space-y-4">
          <div className="card p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-moss/60">
                  Subscription
                </p>
                <h2 className="mt-1 font-display text-xl">
                  {entitlement.state === "trialing" ? "7 天免费试用" : entitlement.planName}
                </h2>
              </div>
              <Crown className={`h-5 w-5 ${entitlement.canAccess ? "text-gold" : "text-ink/25"}`} />
            </div>
            <div className="mt-3 flex items-center gap-4">
              <ProgressRing
                percent={
                  entitlement.state === "trialing"
                    ? entitlement.trialProgress
                    : entitlement.canAccess
                      ? 100
                      : 100
                }
                size={84}
              >
                <span className="font-display text-lg leading-none text-ink">
                  {entitlement.state === "trialing"
                    ? entitlement.trialDaysLeft
                    : entitlement.canAccess
                      ? "∞"
                      : 0}
                </span>
                <span className="mt-0.5 block text-[9px] text-ink/40">
                  {entitlement.state === "trialing" ? "天剩余" : entitlement.canAccess ? "有效" : "已到期"}
                </span>
              </ProgressRing>
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] leading-relaxed text-ink/55">{entitlement.nextChargeNote}</p>
                <Link
                  href={
                    entitlement.state === "trialing" || entitlement.state === "expired"
                      ? "/checkout?plan=annual"
                      : "/desktop/billing"
                  }
                  className={`btn mt-3 w-full text-[11.5px] ${
                    entitlement.state === "expired" ? "btn-clay" : "btn-primary"
                  }`}
                >
                  {entitlement.state === "trialing"
                    ? "升级会员 · 锁定 ¥39/月"
                    : entitlement.state === "expired"
                      ? "立即订阅"
                      : "管理订阅与账单"}
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          </div>

          {wordOfDay && (
            <div className="relative overflow-hidden rounded-[26px] border border-line bg-[#fffdf8] p-5">
              <div className="absolute right-0 top-0 h-24 w-24 rounded-full bg-gold/10 blur-2xl" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-clay/70">
                    Word of the day
                  </p>
                  <span className="chip">{wordOfDay.level}</span>
                </div>
                <div className="mt-2 flex items-end justify-between gap-2">
                  <h2 className="font-display text-3xl text-ink">{wordOfDay.word}</h2>
                  <SpeakButton text={`${wordOfDay.word}. ${wordOfDay.exampleEn}`} />
                </div>
                <p className="text-[11px] text-ink/40">
                  {wordOfDay.phonetic} · {wordOfDay.partOfSpeech}
                </p>
                <p className="mt-2 text-[13px] font-medium text-ink">{wordOfDay.meaningZh}</p>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink/50">{wordOfDay.nuance}</p>
                <div className="mt-3 rounded-xl border border-line/80 bg-parchment/30 p-3">
                  <p className="text-[11.5px] italic leading-relaxed text-ink/75">{wordOfDay.exampleEn}</p>
                  <p className="mt-1 text-[10.5px] text-ink/40">{wordOfDay.exampleZh}</p>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <SaveWordButton wordId={wordOfDay.id} saved={Boolean(wordSaved)} />
                  <Link href="/desktop/vocab" className="text-[10.5px] text-moss hover:text-forest">
                    去词汇本 →
                  </Link>
                </div>
              </div>
            </div>
          )}

          <div className="card p-5">
            <h2 className="flex items-center gap-2 font-display text-xl">
              <Sparkles className="h-4 w-4 text-gold" />
              今日三件事
            </h2>
            <div className="mt-3 space-y-2">
              {[
                {
                  title: "精读一节课",
                  hint: overview.continueLesson ? `${overview.continueLesson.minutes} 分钟` : "已完成全部课时",
                  done: completedToday || !overview.continueLesson,
                  href: overview.continueLesson ? `/desktop/lessons/${overview.continueLesson.slug}` : "/desktop/courses",
                },
                {
                  title: `复习 ${wordBank.dueToday.length} 张词汇卡`,
                  hint: wordBank.dueToday.length === 0 ? "今日暂无待复习" : "间隔重复",
                  done: wordBank.dueToday.length === 0,
                  href: "/desktop/vocab",
                },
                {
                  title: "收藏 1 个新词",
                  hint: `已收藏 ${overview.wordsSaved} 个`,
                  done: overview.wordsSaved > 0,
                  href: "/desktop/vocab",
                },
              ].map((task) => (
                <Link
                  key={task.title}
                  href={task.href}
                  className="flex items-center gap-2.5 rounded-xl border border-line/80 bg-[#fffdf8] px-3 py-2.5 transition-colors hover:border-forest/30"
                >
                  <span
                    className={`grid h-5 w-5 place-items-center rounded-full border ${
                      task.done ? "border-forest bg-forest text-cream" : "border-line text-transparent"
                    }`}
                  >
                    <CheckCircle2 className="h-3 w-3" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block text-[12px] font-medium ${task.done ? "text-ink/40 line-through" : "text-ink"}`}>
                      {task.title}
                    </span>
                    <span className="block text-[10px] text-ink/40">{task.hint}</span>
                  </span>
                  <ArrowRight className="h-3 w-3 shrink-0 text-ink/25" />
                </Link>
              ))}
            </div>
          </div>

          <Link
            href="/mobile"
            className="group flex items-center justify-between rounded-[22px] border border-clay/25 bg-clay/[0.06] p-4"
          >
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-clay/70">
                Mobile app
              </p>
              <p className="mt-0.5 text-[12.5px] font-semibold text-ink">在手机上继续今天的学习</p>
              <p className="text-[10.5px] text-ink/45">通勤时的复习卡已准备好</p>
            </div>
            <span className="grid h-8 w-8 place-items-center rounded-full bg-clay text-white transition-transform group-hover:translate-x-0.5">
              <ArrowRight className="h-4 w-4" />
            </span>
          </Link>

          <p className="px-1 text-[10px] text-ink/35">
            试用结束于 {formatDate(entitlement.trialEndsAt)} · 学习记录永久保存
          </p>
        </div>
      </div>
    </div>
  );
}
