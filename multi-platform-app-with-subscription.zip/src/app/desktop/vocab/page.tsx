import { BookOpen, Bookmark, CheckCircle2, Layers } from "lucide-react";
import { getViewer } from "@/lib/session";
import { getWordBank } from "@/lib/data";
import { StatCard } from "@/components/ui";
import { WordStudio } from "@/components/word-studio";

export const dynamic = "force-dynamic";

export default async function DesktopVocabPage() {
  const { user, entitlement } = await getViewer();
  const wordBank = await getWordBank(user.id);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-moss/60">
            Vocabulary · SRS
          </p>
          <h1 className="mt-2 font-display text-[clamp(1.7rem,2.6vw,2.3rem)]">词汇本</h1>
          <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-ink/50">
            收藏的词汇会进入间隔复习队列。标记「已掌握」后间隔拉长，标记「还不熟」则明天再出现。
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <StatCard label="待复习" value={wordBank.dueToday.length} hint="今日队列" icon={<Layers className="h-4 w-4" />} />
          <StatCard label="已收藏" value={wordBank.saved} hint={`共 ${wordBank.total} 词`} icon={<Bookmark className="h-4 w-4" />} />
          <StatCard label="已掌握" value={wordBank.mastered} hint="长期记忆" icon={<CheckCircle2 className="h-4 w-4" />} />
        </div>
      </div>

      {entitlement.state === "expired" && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-clay/25 bg-clay/[0.06] px-4 py-3">
          <p className="flex items-center gap-2 text-[11.5px] text-clay">
            <BookOpen className="h-3.5 w-3.5" />
            试用已结束：复习卡暂停，但 {wordBank.saved} 个已收藏词汇与掌握度全部保留。
          </p>
          <a href="/checkout?plan=annual" className="btn btn-clay text-[11px]">
            恢复复习
          </a>
        </div>
      )}

      <WordStudio items={wordBank.items} canAccess={entitlement.canAccess} />
    </div>
  );
}
