export type PlanId = "monthly" | "annual" | "lifetime";

export type BillingPlan = {
  id: PlanId;
  name: string;
  nameEn: string;
  priceCents: number;
  originalCents?: number;
  per: string;
  periodDays: number | null;
  tagline: string;
  features: string[];
  badge?: string;
  highlight?: boolean;
};

export const TRIAL_DAYS = 7;

export const PLANS: BillingPlan[] = [
  {
    id: "monthly",
    name: "月度会员",
    nameEn: "Monthly",
    priceCents: 6800,
    per: "/ 月",
    periodDays: 30,
    tagline: "灵活开始，随时取消",
    features: ["全部 6 大高阶课程", "双端同步学习进度", "每日一词与间隔复习", "学习报告与错题回顾"],
  },
  {
    id: "annual",
    name: "年度会员",
    nameEn: "Annual",
    priceCents: 46800,
    originalCents: 81600,
    per: "/ 年",
    periodDays: 365,
    tagline: "相当于 ¥39 / 月，最受欢迎",
    features: [
      "月度会员全部权益",
      "词汇精讲直播回放",
      "写作批改每月 4 次",
      "朗读与语调评估报告",
      "优先体验新课程",
    ],
    badge: "推荐",
    highlight: true,
  },
  {
    id: "lifetime",
    name: "终身会员",
    nameEn: "Lifetime",
    priceCents: 129800,
    per: "一次性",
    periodDays: null,
    tagline: "一次购买，长期更新",
    features: ["年度会员全部权益", "终身访问与课程更新", "专属学习路径规划", "终身会员徽章"],
  },
];

export const PLAN_MAP: Record<PlanId, BillingPlan> = {
  monthly: PLANS[0],
  annual: PLANS[1],
  lifetime: PLANS[2],
};

export function isPlanId(value: string): value is PlanId {
  return value === "monthly" || value === "annual" || value === "lifetime";
}

export function planDisplayName(plan: string): string {
  if (isPlanId(plan)) return PLAN_MAP[plan].name;
  return "7 天免费试用";
}

export function planDisplayNameEn(plan: string): string {
  if (isPlanId(plan)) return PLAN_MAP[plan].nameEn;
  return "Free trial";
}

export type Coupon = { code: string; percentOff: number; label: string };

export const COUPONS: Coupon[] = [
  { code: "NUANCE30", percentOff: 30, label: "首发 7 折券" },
  { code: "WELCOME15", percentOff: 15, label: "新学员 85 折券" },
];

export function findCoupon(code: string | null | undefined): Coupon | null {
  if (!code) return null;
  const normalized = code.trim().toUpperCase();
  return COUPONS.find((coupon) => coupon.code === normalized) ?? null;
}

export type PriceBreakdown = {
  plan: BillingPlan;
  subtotalCents: number;
  discountCents: number;
  totalCents: number;
  coupon: Coupon | null;
};

export function priceBreakdown(planId: PlanId, couponCode?: string | null): PriceBreakdown {
  const plan = PLAN_MAP[planId];
  const coupon = findCoupon(couponCode);
  const discountCents = coupon ? Math.round((plan.priceCents * coupon.percentOff) / 100) : 0;
  return {
    plan,
    subtotalCents: plan.priceCents,
    discountCents,
    totalCents: plan.priceCents - discountCents,
    coupon,
  };
}

export function addPlanPeriod(from: Date, planId: PlanId): Date | null {
  const plan = PLAN_MAP[planId];
  if (!plan.periodDays) return null;
  const next = new Date(from.getTime());
  next.setDate(next.getDate() + plan.periodDays);
  return next;
}

export function formatCNY(cents: number): string {
  const value = cents / 100;
  return `¥${value.toLocaleString("zh-CN", {
    minimumFractionDigits: value % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

export const PAYMENT_METHODS = [
  { id: "wechat", name: "微信支付", hint: "扫码即时到账", glyph: "微" },
  { id: "alipay", name: "支付宝", hint: "安全快捷", glyph: "支" },
  { id: "applepay", name: "Apple Pay", hint: "面容 / 指纹确认", glyph: "" },
  { id: "card", name: "银行卡", hint: "支持境内外信用卡", glyph: "卡" },
] as const;

export type PaymentMethodId = (typeof PAYMENT_METHODS)[number]["id"];

export function paymentMethodName(id: string): string {
  return PAYMENT_METHODS.find((method) => method.id === id)?.name ?? id;
}
