import { cache } from "react";
import { cookies, headers } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, type User } from "@/db/schema";
import { ensureSeed } from "./seed";
import { TRIAL_DAYS, isPlanId, planDisplayName, planDisplayNameEn } from "./plans";

export const SESSION_COOKIE = "nuance_session";
const DAY_MS = 86_400_000;

export type AccessState = "trialing" | "active" | "lifetime" | "expired";

export type Entitlement = {
  state: AccessState;
  canAccess: boolean;
  isTrial: boolean;
  plan: string;
  planName: string;
  planNameEn: string;
  statusLabel: string;
  trialStartedAt: Date;
  trialEndsAt: Date;
  trialDaysLeft: number;
  trialHoursLeft: number;
  trialProgress: number;
  trialNote: string;
  periodEnd: Date | null;
  autoRenew: boolean;
  nextChargeNote: string;
};

export type Viewer = {
  user: User;
  entitlement: Entitlement;
};

export function computeEntitlement(user: User, now = new Date()): Entitlement {
  const plan = isPlanId(user.plan) ? user.plan : "trial";
  const nowMs = now.getTime();
  const trialStartMs = user.trialStartedAt.getTime();
  const trialEndMs = user.trialEndsAt.getTime();
  const remainingMs = Math.max(0, trialEndMs - nowMs);
  const trialDaysLeft = Math.ceil(remainingMs / DAY_MS);
  const trialHoursLeft = Math.ceil(remainingMs / 3_600_000);
  const trialProgress = Math.min(
    100,
    Math.max(0, Math.round(((nowMs - trialStartMs) / (trialEndMs - trialStartMs)) * 100)),
  );

  const periodEndMs = user.currentPeriodEnd ? user.currentPeriodEnd.getTime() : 0;
  const paidActive =
    (plan === "monthly" || plan === "annual") &&
    periodEndMs > nowMs &&
    user.status !== "expired";
  const lifetime = plan === "lifetime";
  const trialActive = !paidActive && !lifetime && remainingMs > 0;

  const state: AccessState = lifetime
    ? "lifetime"
    : paidActive
      ? "active"
      : trialActive
        ? "trialing"
        : "expired";

  const canAccess = state !== "expired";

  const trialNote =
    trialDaysLeft > 1
      ? `试用期还剩 ${trialDaysLeft} 天`
      : trialDaysLeft === 1
        ? `试用期还剩 ${trialHoursLeft} 小时`
        : "免费试用已结束";

  return {
    state,
    canAccess,
    isTrial: plan === "trial",
    plan,
    planName: planDisplayName(user.plan),
    planNameEn: planDisplayNameEn(user.plan),
    statusLabel:
      state === "lifetime"
        ? "终身会员"
        : state === "active"
          ? user.status === "canceled"
            ? "已取消 · 到期前有效"
            : "订阅有效"
          : state === "trialing"
            ? "试用中"
            : "已到期",
    trialStartedAt: user.trialStartedAt,
    trialEndsAt: user.trialEndsAt,
    trialDaysLeft,
    trialHoursLeft,
    trialProgress,
    trialNote,
    periodEnd: user.currentPeriodEnd,
    autoRenew: user.autoRenew,
    nextChargeNote:
      lifetime
        ? "已一次性买断，无需再次付费"
        : paidActive && user.currentPeriodEnd
          ? user.autoRenew
            ? `将于 ${formatDate(user.currentPeriodEnd)} 自动续费`
            : `有效期至 ${formatDate(user.currentPeriodEnd)}，到期后不再扣款`
          : state === "trialing"
            ? `试用结束于 ${formatDate(user.trialEndsAt)}，不会自动扣款`
            : "订阅已失效，续订即可继续学习",
  };
}

export function formatDate(date: Date | null | undefined): string {
  if (!date) return "—";
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "Asia/Shanghai",
  }).format(date);
}

export function formatDateTime(date: Date | null | undefined): string {
  if (!date) return "—";
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "Asia/Shanghai",
  }).format(date);
}

export const getViewer = cache(async (): Promise<Viewer> => {
  await ensureSeed();
  const store = await cookies();
  const headerStore = await headers();
  const sessionKey =
    store.get(SESSION_COOKIE)?.value ??
    headerStore.get("x-nuance-session") ??
    "guest-demo-session";

  const found = await db.select().from(users).where(eq(users.sessionKey, sessionKey)).limit(1);
  let user = found[0];

  if (!user) {
    const now = new Date();
    const trialEndsAt = new Date(now.getTime() + TRIAL_DAYS * DAY_MS);
    await db
      .insert(users)
      .values({
        sessionKey,
        trialStartedAt: now,
        trialEndsAt,
        displayName: "学习者",
        status: "trialing",
        plan: "trial",
      })
      .onConflictDoNothing();
    const created = await db.select().from(users).where(eq(users.sessionKey, sessionKey)).limit(1);
    user = created[0];
  }

  if (!user) {
    throw new Error("无法创建学习档案，请检查数据库连接");
  }

  return { user, entitlement: computeEntitlement(user) };
});
