import { sql } from "drizzle-orm";
import { db } from "@/db";
import { courses, lessons, words } from "@/db/schema";
import { COURSE_SEED, WORD_SEED } from "./content";

let seedPromise: Promise<void> | null = null;

async function countRows(table: "courses" | "words"): Promise<number> {
  if (table === "courses") {
    const rows = await db.select({ count: sql<number>`count(*)::int` }).from(courses);
    return rows[0]?.count ?? 0;
  }
  const rows = await db.select({ count: sql<number>`count(*)::int` }).from(words);
  return rows[0]?.count ?? 0;
}

async function runSeed(): Promise<void> {
  if ((await countRows("courses")) === 0) {
    for (const course of COURSE_SEED) {
      const inserted = await db
        .insert(courses)
        .values({
          slug: course.slug,
          title: course.title,
          titleEn: course.titleEn,
          tagline: course.tagline,
          description: course.description,
          category: course.category,
          level: course.level,
          accent: course.accent,
          emoji: course.emoji,
          minutes: course.minutes,
          sortOrder: course.sortOrder,
        })
        .onConflictDoNothing()
        .returning({ id: courses.id });

      const courseId = inserted[0]?.id;
      if (!courseId) continue;

      await db
        .insert(lessons)
        .values(
          course.lessons.map((lesson) => ({
            courseId,
            slug: lesson.slug,
            title: lesson.title,
            titleZh: lesson.titleZh,
            summary: lesson.summary,
            level: lesson.level,
            minutes: lesson.minutes,
            xp: lesson.xp,
            content: lesson.content,
            quiz: lesson.quiz,
            sortOrder: lesson.sortOrder,
          })),
        )
        .onConflictDoNothing();
    }
  }

  if ((await countRows("words")) === 0) {
    await db.insert(words).values(WORD_SEED).onConflictDoNothing();
  }
}

export function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
