export type PaymentResult =
  | { ok: true; orderNo: string; planName: string; totalCents: number }
  | { ok: false; message: string };

export type CouponResult =
  | { ok: true; percentOff: number; label: string }
  | { ok: false; message: string };

export type SimpleResult = { ok: boolean; message: string };

export type LessonResult = { ok: true; score: number } | { ok: false; message: string };

export type SaveWordResult =
  | { ok: true; saved: boolean; message: string }
  | { ok: false; message: string };

export type ReviewResult = { ok: true; status: string } | { ok: false; message: string };
