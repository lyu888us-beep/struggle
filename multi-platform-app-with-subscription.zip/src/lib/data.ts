import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  courses,
  lessonProgress,
  lessons,
  payments,
  wordProgress,
  words,
  type Course,
  type Lesson,
  type Payment,
  type Word,
  type WordProgress,
} from "@/db/schema";

const DAY_MS = 86_400_000;

export type LessonSlim = {
  id: number;
  slug: string;
  title: string;
  titleZh: string;
  minutes: number;
  level: string;
  xp: number;
};

export type CourseCard = {
  course: Course;
  lessonCount: number;
  completedCount: number;
  progress: number;
  nextLesson: LessonSlim | null;
};

export type ActivityItem = {
  lessonId: number;
  slug: string;
  title: string;
  titleZh: string;
  courseTitle: string;
  completedAt: Date;
  score: number;
};

export type LearningOverview = {
  courses: CourseCard[];
  totalLessons: number;
  completedLessons: number;
  completedMinutes: number;
  streak: number;
  totalXp: number;
  weeklyXp: number;
  wordsTotal: number;
  wordsSaved: number;
  wordsMastered: number;
  wordOfDay: Word | null;
  continueLesson: (LessonSlim & { courseTitle: string; courseSlug: string }) | null;
  recent: ActivityItem[];
};

function dayKey(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function computeStreak(dates: Date[]): number {
  if (dates.length === 0) return 0;
  const unique = Array.from(new Set(dates.map(dayKey))).sort().reverse();
  const today = dayKey(new Date());
  const yesterday = dayKey(new Date(Date.now() - DAY_MS));
  if (unique[0] !== today && unique[0] !== yesterday) return 0;
  let streak = 1;
  let cursor = new Date(`${unique[0]}T00:00:00+08:00`).getTime();
  for (let index = 1; index < unique.length; index += 1) {
    cursor -= DAY_MS;
    if (unique[index] === dayKey(new Date(cursor))) {
      streak += 1;
    } else {
      break;
    }
  }
  return streak;
}

export async function getLearningOverview(userId: number): Promise<LearningOverview> {
  const rows = await db
    .select({
      course: courses,
      lesson: lessons,
      progress: lessonProgress,
    })
    .from(courses)
    .leftJoin(lessons, eq(lessons.courseId, courses.id))
    .leftJoin(
      lessonProgress,
      and(eq(lessonProgress.lessonId, lessons.id), eq(lessonProgress.userId, userId)),
    )
    .orderBy(courses.sortOrder, lessons.sortOrder);

  const courseMap = new Map<number, CourseCard>();
  let totalLessons = 0;
  let completedLessons = 0;
  let completedMinutes = 0;
  let totalXp = 0;
  let weeklyXp = 0;
  const completionDates: Date[] = [];
  const activity: ActivityItem[] = [];
  const weekAgo = Date.now() - 7 * DAY_MS;
  let continueLesson: LearningOverview["continueLesson"] = null;

  for (const row of rows) {
    if (!courseMap.has(row.course.id)) {
      courseMap.set(row.course.id, {
        course: row.course,
        lessonCount: 0,
        completedCount: 0,
        progress: 0,
        nextLesson: null,
      });
    }
    const card = courseMap.get(row.course.id);
    if (!card || !row.lesson) continue;

    totalLessons += 1;
    card.lessonCount += 1;

    if (row.progress) {
      completedLessons += 1;
      card.completedCount += 1;
      completedMinutes += row.lesson.minutes;
      totalXp += row.lesson.xp;
      completionDates.push(row.progress.completedAt);
      if (row.progress.completedAt.getTime() >= weekAgo) {
        weeklyXp += row.lesson.xp;
      }
      activity.push({
        lessonId: row.lesson.id,
        slug: row.lesson.slug,
        title: row.lesson.title,
        titleZh: row.lesson.titleZh,
        courseTitle: row.course.title,
        completedAt: row.progress.completedAt,
        score: row.progress.score,
      });
    } else {
      if (!card.nextLesson) {
        card.nextLesson = {
          id: row.lesson.id,
          slug: row.lesson.slug,
          title: row.lesson.title,
          titleZh: row.lesson.titleZh,
          minutes: row.lesson.minutes,
          level: row.lesson.level,
          xp: row.lesson.xp,
        };
      }
      if (!continueLesson) {
        continueLesson = {
          ...card.nextLesson,
          courseTitle: row.course.title,
          courseSlug: row.course.slug,
        };
      }
    }
  }

  for (const card of courseMap.values()) {
    card.progress =
      card.lessonCount === 0 ? 0 : Math.round((card.completedCount / card.lessonCount) * 100);
  }

  const vocabRows = await db
    .select({ word: words, progress: wordProgress })
    .from(words)
    .leftJoin(
      wordProgress,
      and(eq(wordProgress.wordId, words.id), eq(wordProgress.userId, userId)),
    )
    .orderBy(words.id);

  const wordsSaved = vocabRows.filter((row) => row.progress).length;
  const wordsMastered = vocabRows.filter((row) => row.progress?.status === "mastered").length;
  const dayIndex = Math.floor(Date.now() / DAY_MS);
  const wordOfDay =
    vocabRows.length > 0 ? (vocabRows[dayIndex % vocabRows.length]?.word ?? null) : null;

  activity.sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());

  return {
    courses: Array.from(courseMap.values()).sort((a, b) => a.course.sortOrder - b.course.sortOrder),
    totalLessons,
    completedLessons,
    completedMinutes,
    streak: computeStreak(completionDates),
    totalXp,
    weeklyXp,
    wordsTotal: vocabRows.length,
    wordsSaved,
    wordsMastered,
    wordOfDay,
    continueLesson,
    recent: activity.slice(0, 5),
  };
}

export async function getCourseCards(userId: number): Promise<CourseCard[]> {
  const overview = await getLearningOverview(userId);
  return overview.courses;
}

export type LessonWithProgress = Lesson & { completed: boolean; score: number | null };

export type CourseDetail = {
  course: Course;
  lessons: LessonWithProgress[];
  completedCount: number;
  progress: number;
};

export async function getCourseDetail(
  slug: string,
  userId: number,
): Promise<CourseDetail | null> {
  const found = await db.select().from(courses).where(eq(courses.slug, slug)).limit(1);
  const course = found[0];
  if (!course) return null;

  const rows = await db
    .select({ lesson: lessons, progress: lessonProgress })
    .from(lessons)
    .leftJoin(
      lessonProgress,
      and(eq(lessonProgress.lessonId, lessons.id), eq(lessonProgress.userId, userId)),
    )
    .where(eq(lessons.courseId, course.id))
    .orderBy(lessons.sortOrder);

  const list: LessonWithProgress[] = rows.map((row) => ({
    ...row.lesson,
    completed: Boolean(row.progress),
    score: row.progress?.score ?? null,
  }));

  const completedCount = list.filter((lesson) => lesson.completed).length;

  return {
    course,
    lessons: list,
    completedCount,
    progress: list.length === 0 ? 0 : Math.round((completedCount / list.length) * 100),
  };
}

export type LessonDetail = {
  lesson: Lesson;
  course: Course;
  completed: boolean;
  score: number | null;
  previous: { slug: string; title: string } | null;
  next: { slug: string; title: string } | null;
  siblings: { slug: string; title: string; titleZh: string; completed: boolean }[];
  savedWordIds: number[];
};

export async function getLessonDetail(slug: string, userId: number): Promise<LessonDetail | null> {
  const found = await db.select().from(lessons).where(eq(lessons.slug, slug)).limit(1);
  const lesson = found[0];
  if (!lesson) return null;

  const courseRows = await db.select().from(courses).where(eq(courses.id, lesson.courseId)).limit(1);
  const course = courseRows[0];
  if (!course) return null;

  const progressRows = await db
    .select()
    .from(lessonProgress)
    .where(and(eq(lessonProgress.userId, userId), eq(lessonProgress.lessonId, lesson.id)))
    .limit(1);

  const siblingsRows = await db
    .select({ lesson: lessons, progress: lessonProgress })
    .from(lessons)
    .leftJoin(
      lessonProgress,
      and(eq(lessonProgress.lessonId, lessons.id), eq(lessonProgress.userId, userId)),
    )
    .where(eq(lessons.courseId, course.id))
    .orderBy(lessons.sortOrder);

  const siblings = siblingsRows.map((row) => ({
    slug: row.lesson.slug,
    title: row.lesson.title,
    titleZh: row.lesson.titleZh,
    completed: Boolean(row.progress),
  }));

  const index = siblings.findIndex((item) => item.slug === lesson.slug);
  const saved = await db
    .select({ wordId: wordProgress.wordId })
    .from(wordProgress)
    .where(eq(wordProgress.userId, userId));

  return {
    lesson,
    course,
    completed: progressRows.length > 0,
    score: progressRows[0]?.score ?? null,
    previous: index > 0 ? siblings[index - 1] : null,
    next: index >= 0 && index < siblings.length - 1 ? siblings[index + 1] : null,
    siblings,
    savedWordIds: saved.map((row) => row.wordId),
  };
}

export type WordItem = { word: Word; progress: WordProgress | null };

export type WordBank = {
  items: WordItem[];
  saved: number;
  mastered: number;
  learning: number;
  total: number;
  dueToday: WordItem[];
};

export async function getWordBank(userId: number): Promise<WordBank> {
  const rows = await db
    .select({ word: words, progress: wordProgress })
    .from(words)
    .leftJoin(
      wordProgress,
      and(eq(wordProgress.wordId, words.id), eq(wordProgress.userId, userId)),
    )
    .orderBy(words.word);

  const items: WordItem[] = rows.map((row) => ({ word: row.word, progress: row.progress }));
  const savedItems = items.filter((item) => item.progress);
  const mastered = items.filter((item) => item.progress?.status === "mastered").length;
  const learning = items.filter((item) => item.progress?.status === "learning").length;

  return {
    items,
    saved: savedItems.length,
    mastered,
    learning,
    total: items.length,
    dueToday: savedItems.filter((item) => item.progress?.status !== "mastered").slice(0, 8),
  };
}

export async function getPayments(userId: number): Promise<Payment[]> {
  return db
    .select()
    .from(payments)
    .where(eq(payments.userId, userId))
    .orderBy(desc(payments.createdAt));
}

export async function getPaymentByOrder(orderNo: string, userId: number): Promise<Payment | null> {
  const rows = await db
    .select()
    .from(payments)
    .where(and(eq(payments.orderNo, orderNo), eq(payments.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}
