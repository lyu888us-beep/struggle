export type ContentBlock =
  | { type: "lead"; text: string }
  | { type: "heading"; text: string }
  | { type: "paragraph"; text: string }
  | { type: "quote"; text: string; source: string }
  | { type: "tip"; title: string; text: string }
  | { type: "phrases"; title: string; items: { en: string; zh: string }[] }
  | { type: "note"; text: string };

export type ContentQuiz = {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
};

export type CourseSeed = {
  slug: string;
  title: string;
  titleEn: string;
  tagline: string;
  description: string;
  category: string;
  level: string;
  accent: string;
  emoji: string;
  minutes: number;
  sortOrder: number;
  lessons: LessonSeed[];
};

export type LessonSeed = {
  slug: string;
  title: string;
  titleZh: string;
  summary: string;
  level: string;
  minutes: number;
  xp: number;
  sortOrder: number;
  content: ContentBlock[];
  quiz: ContentQuiz[];
};

export const COURSE_SEED: CourseSeed[] = [
  {
    slug: "meaning-boundaries",
    title: "词义的边界",
    titleEn: "The Edge of Meaning",
    tagline: "从「认识单词」到「懂它的分寸」",
    description:
      "高阶英语真正的门槛不是词汇量，而是词语之间的细微差别。本课程用近义词拆解与语料对比，训练你在写作与口语中做出精确选择。",
    category: "词汇",
    level: "C1",
    accent: "forest",
    emoji: "◈",
    minutes: 96,
    sortOrder: 1,
    lessons: [
      {
        slug: "plausible-possible-probable",
        title: "Plausible, Possible, Probable",
        titleZh: "三种「可能」，三种立场",
        summary:
          "同样表示「有可能」，plausible 带着判断，possible 保留余地，probable 则几乎在下注。选错一个词，你的立场就变了。",
        level: "C1",
        minutes: 14,
        xp: 60,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "Advanced vocabulary is less about knowing more words than about knowing how far each word is willing to commit.",
          },
          {
            type: "paragraph",
            text: "Most learners treat possible, probable and plausible as interchangeable synonyms for 「可能」. Native speakers do not. Each word encodes a different amount of evidence and a different degree of personal commitment.",
          },
          {
            type: "phrases",
            title: "语感坐标",
            items: [
              { en: "possible", zh: "存在可能性；说话人几乎不表态，只排除「不可能」。" },
              { en: "probable", zh: "基于证据的较高概率，通常暗示 60% 以上。" },
              { en: "plausible", zh: "解释或说法「站得住脚」，重点在逻辑可信，而非概率。" },
            ],
          },
          {
            type: "paragraph",
            text: "Compare: It is possible that the meeting will be postponed — the speaker has no information. It is probable that the meeting will be postponed — the speaker has seen evidence. The explanation is plausible — the speaker finds the reasoning coherent, even if unproven.",
          },
          {
            type: "quote",
            text: "A plausible story can be false; a probable event can be unexplained. Precision begins where the synonyms end.",
            source: "Course note",
          },
          {
            type: "tip",
            title: "写作应用",
            text: "在学术写作里，用 plausible 评价他人理论，用 probable 预测数据走向，用 possible 保留存在性结论。三个词的语气强度依次是 plausible < possible < probable（就承诺程度而言，possible 最中性）。",
          },
          {
            type: "heading",
            text: "一处常见误用",
          },
          {
            type: "paragraph",
            text: "中文里我们常说「一个可能的解释」。英文若写 a possible explanation，读者会理解成「也许存在某种解释」；要表达「这个解释说得通」，应该写 a plausible explanation。这是 C1 与 C2 之间最典型的分界线之一。",
          },
          {
            type: "note",
            text: "练习：回想你最近写过的一句英文判断，把其中的 possible / probable / plausible 换成更精确的那个。",
          },
        ],
        quiz: [
          {
            question: "The theory is ______: it accounts for every data point we have, though no one has tested it yet.",
            options: ["probable", "plausible", "possible", "inevitable"],
            answer: 1,
            explanation:
              "句子强调「逻辑上解释得通、但尚未被验证」，因此用 plausible。probable 需要证据支持，possible 只表示存在性。",
          },
          {
            question: "Which sentence shows the speaker has actual evidence?",
            options: [
              "It is possible that demand will rise.",
              "It is probable that demand will rise.",
              "Demand might rise, I suppose.",
              "A rise in demand is not inconceivable.",
            ],
            answer: 1,
            explanation: "probable 通常建立在证据之上，是四个选项里承诺程度最高的表达。",
          },
        ],
      },
      {
        slug: "restrain-refrain-prevent",
        title: "Restrain, Refrain, Prevent",
        titleZh: "克制、自制与阻止",
        summary:
          "三个词都指向「不做某事」，但主语、宾语与责任完全不同。这是中式英文最容易露馅的一组。",
        level: "C1",
        minutes: 13,
        xp: 60,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "English cares about who is holding back whom. Restrain takes an object, refrain does not, and prevent needs a second event.",
          },
          {
            type: "phrases",
            title: "结构决定含义",
            items: [
              { en: "restrain somebody / something", zh: "克制某人或某物；主语是施加约束的一方。" },
              { en: "refrain from doing something", zh: "自己忍住不做；主语同时是行为者。" },
              { en: "prevent somebody from doing something", zh: "阻止他人做某事；强调因果阻断。" },
            ],
          },
          {
            type: "paragraph",
            text: "She restrained her anger and said nothing. She refrained from commenting. She prevented her colleague from sending the email. In each case the grammar tells you who wanted what.",
          },
          {
            type: "tip",
            title: "中文思维陷阱",
            text: "「我克制住没有回复」不能写成 I restrained from replying。因为 restrain 必须有宾语。正确说法是 I refrained from replying 或 I restrained myself from replying。",
          },
          {
            type: "paragraph",
            text: "There is also a register difference. Refrain is formal and a little administrative — you will see it in policy language: passengers are asked to refrain from smoking. Restrain is physical and legal as often as emotional.",
          },
          {
            type: "quote",
            text: "Self-control is the art of refraining; management is the art of restraining; policy is the art of preventing.",
            source: "Course note",
          },
          {
            type: "note",
            text: "进阶练习：把「政府阻止了价格进一步上涨」改写为两种不同结构的英文，并说明两者语气的差异。",
          },
        ],
        quiz: [
          {
            question: "Passengers are kindly asked to ______ from using their phones during take-off.",
            options: ["restrain", "refrain", "prevent", "resist"],
            answer: 1,
            explanation: "refrain from doing 表示自己忍住不做，是公告、政策类文本的固定搭配。",
          },
          {
            question: "Which sentence is grammatically correct?",
            options: [
              "He restrained from laughing.",
              "He refrained laughing.",
              "He restrained himself from laughing.",
              "He prevented to laugh.",
            ],
            answer: 2,
            explanation: "restrain 需要宾语，restrain oneself from doing 是正确的反身结构。",
          },
        ],
      },
      {
        slug: "understatement-hedging",
        title: "Understatement & Hedging",
        titleZh: "轻描淡写与保留语气",
        summary:
          "英美精英语言的核心技术：如何用更少的音量说出更强的判断。学会 hedge，你的英文立刻显得成熟。",
        level: "C2",
        minutes: 16,
        xp: 70,
        sortOrder: 3,
        content: [
          {
            type: "lead",
            text: "Fluency is knowing what to say. Sophistication is knowing how much of it to leave out.",
          },
          {
            type: "paragraph",
            text: "Hedging is the linguistic softening of a claim: it seems that, arguably, to some extent, I would suggest. Understatement goes further — it signals a large reality with a small word, as in not bad for extraordinary, or a bit of a problem for a crisis.",
          },
          {
            type: "phrases",
            title: "实用 hedges",
            items: [
              { en: "It would appear that…", zh: "比 It is clear that 更克制，适合职场陈述。" },
              { en: "I am not entirely convinced that…", zh: "礼貌而坚定的反对。" },
              { en: "That is one way of putting it.", zh: "你心里并不同意，但先留一线。" },
              { en: "With the greatest respect…", zh: "英式会议里，这句话后面通常跟着最强的反对。" },
            ],
          },
          {
            type: "quote",
            text: "The British do not say what they mean; they say what the situation can bear.",
            source: "Reading note on register",
          },
          {
            type: "tip",
            title: "边界感",
            text: "Hedging 用在结论与评价上很高级，但不要用在事实陈述上。The data would appear to suggest 可以；The meeting would appear to start at nine 显得荒谬。",
          },
          {
            type: "heading",
            text: "双向训练",
          },
          {
            type: "paragraph",
            text: "高阶读者需要能听出 hedge 背后的硬度。当同事说 I would gently push back on that, 他不是在客气，而是在明确反对。请在下次英文会议里记录三句 hedge，并写下它真正的意思。",
          },
        ],
        quiz: [
          {
            question: "A colleague writes: \"I am not entirely convinced that this timeline is realistic.\" What is the most likely meaning?",
            options: [
              "They fully support the timeline.",
              "They have no opinion yet.",
              "They think the timeline is unrealistic.",
              "They want a longer meeting.",
            ],
            answer: 2,
            explanation: "not entirely convinced 是礼貌但明确的反对，实际态度是「时间表不现实」。",
          },
          {
            question: "Which claim is hedged appropriately for an academic conclusion?",
            options: [
              "This proves everything.",
              "The evidence would appear to support a moderate effect.",
              "Everybody knows the effect is huge.",
              "There is no doubt whatsoever.",
            ],
            answer: 1,
            explanation: "would appear to support a moderate effect 在结论上保留余地，符合学术写作的 hedging 规范。",
          },
        ],
      },
    ],
  },
  {
    slug: "argument-architecture",
    title: "论证的骨架",
    titleEn: "The Architecture of Argument",
    tagline: "写出可以被引用、而不是被浏览的英文",
    description:
      "面向论文、报告与高阶写作场景。从论点句、让步结构到证据密度，把「英语作文」升级为「英语论证」。",
    category: "写作",
    level: "C2",
    accent: "clay",
    emoji: "⌘",
    minutes: 78,
    sortOrder: 2,
    lessons: [
      {
        slug: "claims-that-survive",
        title: "Claims That Survive",
        titleZh: "让论点经得起反驳",
        summary:
          "脆弱的论点怕反例，强壮的论点自带边界。学习三层论点结构和让步让步在让步写作法。",
        level: "C2",
        minutes: 18,
        xp: 80,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "A weak claim needs agreement. A strong claim survives disagreement.",
          },
          {
            type: "paragraph",
            text: "Most advanced learners write claims that are either too broad — technology has changed education — or too personal. Academic English rewards claims with scoped conditions: for whom, under what circumstances, to what degree.",
          },
          {
            type: "phrases",
            title: "三层论点模板",
            items: [
              { en: "Although X has been widely documented, Y remains undertheorised.", zh: "指出空白，建立研究位置。" },
              { en: "This essay argues that A, provided that B.", zh: "带条件的论点，最抗反驳。" },
              { en: "The evidence suggests a moderate rather than decisive effect.", zh: "控制强度的结论。" },
            ],
          },
          {
            type: "heading",
            text: "让步写作法（Concession）",
          },
          {
            type: "paragraph",
            text: "Strong argumentation acknowledges the best version of the opposing view before answering it. Not: Some people say X, but I disagree. Rather: Even granting that X holds in urban contexts, the rural data point the other way.",
          },
          {
            type: "tip",
            title: "句式升级",
            text: "把 But 升级为 Even so / That said / Even granting that…。把 I think 升级为 This paper contends / The data indicate。把 very important 升级为 decisive / load-bearing。",
          },
          {
            type: "quote",
            text: "You do not persuade a sceptic by raising your voice. You persuade them by lending them yours.",
            source: "Writing seminar",
          },
          {
            type: "note",
            text: "练习：写出一句含 although 与 provided that 的论点句，要求即使被反例攻击也不会立刻崩塌。",
          },
        ],
        quiz: [
          {
            question: "Which is the strongest academic claim?",
            options: [
              "Social media is bad for everyone.",
              "Social media is definitely harmful.",
              "Social media use correlates with anxiety among adolescents, particularly in high-intensity users.",
              "I think social media is a problem.",
            ],
            answer: 2,
            explanation: "该论点限定了人群、强度与结论类型（相关性），因此经得起反驳。",
          },
          {
            question: "What is the function of a concession in an argument?",
            options: [
              "To hide your opinion",
              "To show you understand the strongest opposing case before answering it",
              "To make the essay longer",
              "To avoid taking any position",
            ],
            answer: 1,
            explanation: "让步不是退让，而是先承认对方最强版本，以提升自身论证的可信度。",
          },
        ],
      },
      {
        slug: "evidence-density",
        title: "Evidence Density",
        titleZh: "证据密度与句子节奏",
        summary:
          "好英文不是长句堆叠，而是论点、证据、解释的呼吸。掌握 T-E-E 结构与句长变化。",
        level: "C1",
        minutes: 15,
        xp: 70,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "Rhythm is meaning. A paragraph that never breathes reads like a list of demands.",
          },
          {
            type: "paragraph",
            text: "Evidence density is the ratio of specific, checkable material to general statement. Academic paragraphs typically follow Topic — Evidence — Explanation, with the explanation doing the intellectual work.",
          },
          {
            type: "phrases",
            title: "从证据到解释",
            items: [
              { en: "This pattern suggests that…", zh: "把数据转成解释。" },
              { en: "A closer reading reveals…", zh: "把读者带到细节。" },
              { en: "That is not to say that…", zh: "提前封住误读。" },
            ],
          },
          {
            type: "paragraph",
            text: "Sentence length is a signalling device. Short sentences land conclusions. Longer sentences build the conditions under which that conclusion becomes unavoidable. Alternate the two deliberately.",
          },
          {
            type: "tip",
            title: "自查表",
            text: "一个段落里如果有两个以上的 very、really、a lot，就删掉一个。如果连续三句都以 The 开头，改写一句的语序。",
          },
          {
            type: "paragraph",
            text: "Finally, prefer verbs to nominalisations. The committee decided reads faster and firmer than The committee made a decision.",
          },
        ],
        quiz: [
          {
            question: "Which sentence is the most effective conclusion of a paragraph?",
            options: [
              "The results are very interesting and important.",
              "The pattern holds.",
              "It should be noted that the results, in various ways, might perhaps be considered significant.",
              "As mentioned above, results matter a lot in research.",
            ],
            answer: 1,
            explanation: "短句落地结论，力度来自克制而非堆叠形容词。",
          },
          {
            question: "The T-E-E structure stands for:",
            options: [
              "Theory, Example, Ending",
              "Topic sentence, Evidence, Explanation",
              "Tense, Emphasis, Emotion",
              "Thesis, Evaluation, Extension",
            ],
            answer: 1,
            explanation: "Topic sentence 立论，Evidence 提供可核查材料，Explanation 完成解释工作。",
          },
        ],
      },
    ],
  },
  {
    slug: "idiom-and-instinct",
    title: "习语与语感",
    titleEn: "Idiom and Instinct",
    tagline: "听懂字面之外的真正意思",
    description:
      "从酒吧闲聊到董事会博弈，习语是文化的压缩包。本课程拆解高频表达的来源、语气与使用禁区。",
    category: "口语",
    level: "C1",
    accent: "gold",
    emoji: "❋",
    minutes: 64,
    sortOrder: 3,
    lessons: [
      {
        slug: "reading-between-lines",
        title: "Reading Between the Lines",
        titleZh: "读懂话外之意",
        summary:
          "That is a bold move. Fine. I am sure it will be fine. 三句话，三种警告。练习解码英语的间接性。",
        level: "C1",
        minutes: 13,
        xp: 60,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "The most important information in English conversation is often carried by the tone, not the words.",
          },
          {
            type: "phrases",
            title: "高频潜台词",
            items: [
              { en: "That is a bold move.", zh: "我认为这是个冒险、甚至不妥的决定。" },
              { en: "I will let you two discuss it.", zh: "我不介入，但你们得自己承担后果。" },
              { en: "We will see.", zh: "我不同意，但不想现在争论。" },
              { en: "No complaints here.", zh: "我其实相当满意。" },
            ],
          },
          {
            type: "paragraph",
            text: "Indirectness is not dishonesty; it is social lubrication. In British and much of corporate English, a direct no can read as an attack. A skilled listener learns to detect the boundary in a softened sentence.",
          },
          {
            type: "tip",
            title: "听力训练",
            text: "看剧时关掉字幕，先猜说话人真实态度，再开字幕核对。特别注意句尾语调的下沉与拖长。",
          },
          {
            type: "quote",
            text: "Understatement is a form of precision: it trusts the listener to do half the work.",
            source: "Conversation analysis note",
          },
          {
            type: "paragraph",
            text: "In your own speech, one well-placed understatement is elegant. Three in a row sounds evasive. Calibrate.",
          },
        ],
        quiz: [
          {
            question: "Your manager says: \"That is certainly one way to approach it.\" What are they most likely signalling?",
            options: ["Enthusiastic approval", "Mild disapproval or doubt", "A request for more detail", "A promotion"],
            answer: 1,
            explanation: "one way to approach it 是典型的含蓄否定：暗示还有更好的做法。",
          },
          {
            question: "Which reply is a polite but firm disagreement in a meeting?",
            options: [
              "No, you are wrong.",
              "I am not sure I follow, but fine.",
              "I see the logic, though I would take a different view.",
              "Whatever you think.",
            ],
            answer: 2,
            explanation: "先承认对方逻辑，再表达不同立场，是职场英语里稳定而体面的反对方式。",
          },
        ],
      },
      {
        slug: "idioms-with-origins",
        title: "Idioms With Origins",
        titleZh: "带出处的习语",
        summary:
          "知道习语从哪里来，才不会用错场合。从 brass tacks 到 read the room，理解背后的文化逻辑。",
        level: "C1",
        minutes: 12,
        xp: 55,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "An idiom used well is invisible. An idiom used slightly wrong is loud.",
          },
          {
            type: "phrases",
            title: "精读与场景",
            items: [
              { en: "get down to brass tacks", zh: "进入实质细节；源自布料量尺，适合商务讨论。" },
              { en: "read the room", zh: "读出在场者的情绪与气氛；现代口语，谨慎用于正式书面。" },
              { en: "move the needle", zh: "带来可见的实质进展；创业与绩效语境。" },
              { en: "a hard sell", zh: "难以推销 / 难以让人接受的主张。" },
            ],
          },
          {
            type: "paragraph",
            text: "Idioms carry register. Get down to brass tacks belongs in a working session, not a eulogy. Read the room is conversational and recent; in a formal proposal, say gauge the audience instead.",
          },
          {
            type: "tip",
            title: "安全用法",
            text: "一次对话用一到两个习语即可。把它们放在句首或句尾做过渡，比塞进句中更自然。",
          },
          {
            type: "paragraph",
            text: "Also note the direction of idioms. It is a hard sell, not a difficult sell; you move the needle, you do not push it.",
          },
        ],
        quiz: [
          {
            question: "Your team keeps discussing strategy in general. You want specifics. You say:",
            options: [
              "Let us read the room.",
              "Let us get down to brass tacks.",
              "It is a hard sell.",
              "Let us move the needle.",
            ],
            answer: 1,
            explanation: "get down to brass tacks 意为进入实质细节，正合此语境。",
          },
          {
            question: "Which idiom is least appropriate in a formal written proposal?",
            options: ["a viable alternative", "a measurable impact", "read the room", "a phased rollout"],
            answer: 2,
            explanation: "read the room 属于现代口语，正式书面语宜用 gauge the audience。",
          },
        ],
      },
    ],
  },
  {
    slug: "prosody-studio",
    title: "语音与语调",
    titleEn: "Prosody Studio",
    tagline: "让别人愿意听你说完",
    description:
      "高级口语的关键不在单个音标，而在重音、停顿与语调轮廓。用最低成本，让表达听起来接近母语。",
    category: "发音",
    level: "B2",
    accent: "ocean",
    emoji: "◍",
    minutes: 58,
    sortOrder: 4,
    lessons: [
      {
        slug: "stress-not-sounds",
        title: "Stress, Not Sounds",
        titleZh: "重音比音标更重要",
        summary:
          "一个句子只有一个主角。学会信息重音，你的英语立刻从「能听懂」变成「好听」。",
        level: "B2",
        minutes: 12,
        xp: 50,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "Listeners forgive a wrong vowel far more easily than a flat rhythm.",
          },
          {
            type: "paragraph",
            text: "English is stress-timed: content words take weight, function words compress. The sentence I would have told you becomes almost I'd've toldya in fast speech — not because speakers are lazy, but because the rhythm requires it.",
          },
          {
            type: "phrases",
            title: "三个练习动作",
            items: [
              { en: "I did not say he stole it.", zh: "重读 did not：强调否认。" },
              { en: "I did not say he stole it.", zh: "重读 he：指向另一个人。" },
              { en: "I did not say he stole it.", zh: "重读 stole：争议在动作本身。" },
            ],
          },
          {
            type: "tip",
            title: "跟读法",
            text: "选 30 秒播客，先标出每句的重音词，再跟读三遍：第一遍只打拍子，第二遍只念重音词，第三遍完整连读。",
          },
          {
            type: "paragraph",
            text: "Record yourself. Most learners discover their flatness only when they hear the playback. This app's 朗读 button uses your browser's speech engine — use it as a reference, then compare.",
          },
        ],
        quiz: [
          {
            question: "In \"I did not say he stole it\", stressing he implies:",
            options: [
              "The speaker denies saying anything.",
              "Someone else said it.",
              "Theft definitely happened.",
              "The sentence is a question.",
            ],
            answer: 1,
            explanation: "重读 he 把对比焦点放在人身上，暗示原话是别人说的。",
          },
          {
            question: "English rhythm is best described as:",
            options: ["syllable-timed", "stress-timed", "tone-based", "random"],
            answer: 1,
            explanation: "英语以重音计时，功能词会被压缩，形成起伏的节奏。",
          },
        ],
      },
      {
        slug: "pausing-with-purpose",
        title: "Pausing With Purpose",
        titleZh: "有目的的停顿",
        summary:
          "停顿不是卡住，而是句法的一部分。三个位置、两个长度，让你的表达拥有结构感。",
        level: "B2",
        minutes: 11,
        xp: 50,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "Silence is the punctuation of speech. Without it, even perfect grammar sounds hurried.",
          },
          {
            type: "paragraph",
            text: "Speakers use three pause lengths: micro (between phrases), medium (between ideas), long (before a conclusion). Most non-native speakers only have two: none, or falling apart.",
          },
          {
            type: "paragraph",
            text: "Try marking your next presentation script with single and double slashes. Read it aloud. The room will feel your structure before they understand your argument.",
          },
          {
            type: "tip",
            title: "面试场景",
            text: "被问到难题时，先说 That is a good question, 停 1.5 秒，再回答。这个停顿会被听成从容，而不是迟疑。",
          },
          {
            type: "quote",
            text: "The pause is where the listener catches up. Give them the space and they will give you the room.",
            source: "Prosody studio",
          },
        ],
        quiz: [
          {
            question: "The most effective place for a longer pause is:",
            options: [
              "in the middle of a key noun",
              "before your conclusion",
              "between every word",
              "immediately after saying hello",
            ],
            answer: 1,
            explanation: "结论前的长停顿能制造结构感，让听众集中注意力。",
          },
          {
            question: "A well-timed pause in an interview is perceived as:",
            options: ["weakness", "confidence", "rudeness", "confusion"],
            answer: 1,
            explanation: "从容的短暂停顿传达掌控感，而非迟疑。",
          },
        ],
      },
    ],
  },
  {
    slug: "boardroom-english",
    title: "会议室英语",
    titleEn: "The Boardroom",
    tagline: "在真实的商业博弈里说对话",
    description:
      "汇报、谈判、反对、收尾。用结构化的高阶表达，在英文会议里既保持体面，也保住立场。",
    category: "商务",
    level: "C1",
    accent: "plum",
    emoji: "◆",
    minutes: 62,
    sortOrder: 5,
    lessons: [
      {
        slug: "disagree-upward",
        title: "Disagree Upward",
        titleZh: "如何向上级说不",
        summary:
          "对齐目标、承认风险、提出替代，三步完成一次不失礼貌的反对。",
        level: "C1",
        minutes: 14,
        xp: 65,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "Disagreement is a technical skill. It needs a structure, not more courage.",
          },
          {
            type: "phrases",
            title: "三句式反对",
            items: [
              { en: "I share the goal behind this.", zh: "先对齐目标，降低对抗感。" },
              { en: "My concern is timing rather than direction.", zh: "限定争议范围，问题具体化。" },
              { en: "Could we pilot it with one region first?", zh: "提出可执行的替代方案。" },
            ],
          },
          {
            type: "paragraph",
            text: "Never disagree with a person when you can disagree with a variable. Shifting the dispute to timing, scope or resourcing keeps the relationship intact while preserving your objection.",
          },
          {
            type: "tip",
            title: "语气校准",
            text: "I am not sure that will work 显得准备不足；I would question whether the deadline is realistic 显示你带着判断参会。",
          },
          {
            type: "paragraph",
            text: "Finally, end with a commitment. If we proceed, I will need two more engineers by June. This turns dissent into planning.",
          },
        ],
        quiz: [
          {
            question: "Which opening best preserves the relationship while objecting?",
            options: [
              "That is wrong.",
              "I share the goal behind this, though I see the risk differently.",
              "I do not like it.",
              "We tried that before and failed.",
            ],
            answer: 1,
            explanation: "先对齐目标再限定分歧，是向上反对最稳定的开局。",
          },
          {
            question: "The recommended strategy is to disagree with:",
            options: ["the person", "the meeting", "a variable such as timing or scope", "the company"],
            answer: 2,
            explanation: "把争议落到可调整的变量上，保护关系并保留立场。",
          },
        ],
      },
      {
        slug: "closing-the-room",
        title: "Closing the Room",
        titleZh: "如何收住一场会议",
        summary:
          "决定、负责人、时间点。三句话收尾，让你的英文会议有结果。",
        level: "C1",
        minutes: 12,
        xp: 60,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "Meetings rarely end; they simply run out of time. A closer is a gift to everyone.",
          },
          {
            type: "paragraph",
            text: "A strong close has three elements: what was decided, who owns it, and when it lands. It should take under forty seconds and never introduce new information.",
          },
          {
            type: "phrases",
            title: "收尾句型",
            items: [
              { en: "To be clear on what we agreed…", zh: "重述决定，避免误读。" },
              { en: "Ownership sits with…", zh: "明确负责人，比 who will do it 更有力。" },
              { en: "Let us take that offline.", zh: "把偏题议题移出会议。" },
              { en: "I will circulate notes by end of day.", zh: "给出可验证的交付承诺。" },
            ],
          },
          {
            type: "tip",
            title: "反模式",
            text: "避免 Let me know what you think 作为结尾。它把责任推回给所有人，等于没有结论。",
          },
          {
            type: "paragraph",
            text: "If you are not the chair, you can still close your own item: On my side, the next step is X, and I will report back Thursday.",
          },
        ],
        quiz: [
          {
            question: "Which closing sentence is most effective?",
            options: [
              "So yeah, that is basically it.",
              "Let me know what you think.",
              "To recap: we will pilot in Region A, Sam owns the plan, and we review on Thursday.",
              "We had a good discussion today.",
            ],
            answer: 2,
            explanation: "重述决定、明确负责人、给出时间点，这是高效收尾的三要素。",
          },
          {
            question: "Take that offline means:",
            options: [
              "Cancel the project",
              "Discuss it separately, outside this meeting",
              "Work from home",
              "Send an email",
            ],
            answer: 1,
            explanation: "take it offline 指把该议题移到会议之外单独讨论。",
          },
        ],
      },
    ],
  },
  {
    slug: "close-reading",
    title: "文学细读",
    titleEn: "Close Reading",
    tagline: "在文本的缝隙里读懂人",
    description:
      "面向 C2 读者。以短篇小说与散文为材料，训练叙述视角、意象与沉默的解读能力。",
    category: "阅读",
    level: "C2",
    accent: "ink",
    emoji: "❖",
    minutes: 70,
    sortOrder: 6,
    lessons: [
      {
        slug: "narrator-you-can-trust",
        title: "A Narrator You Cannot Trust",
        titleZh: "不可靠叙述者",
        summary:
          "当叙述者开始替自己辩护，故事才真正开始。学会在文本中寻找裂缝。",
        level: "C2",
        minutes: 16,
        xp: 75,
        sortOrder: 1,
        content: [
          {
            type: "lead",
            text: "Every unreliable narrator insists, first of all, on how reasonable they are.",
          },
          {
            type: "paragraph",
            text: "An unreliable narrator is not necessarily a liar. The gap may come from limited knowledge, ideology, or self-deception. Close reading means noticing what the text says next to what the narrator claims.",
          },
          {
            type: "quote",
            text: "I am not a difficult man. I simply prefer things to be done properly.",
            source: "Opening line, unnamed short story",
          },
          {
            type: "paragraph",
            text: "That first sentence already contains its own refutation. The protest is too early, the adjective too absolute. In literary analysis we call this a tonal clue: the narrator tells us how to read him while doing the opposite.",
          },
          {
            type: "phrases",
            title: "分析用语",
            items: [
              { en: "The text withholds…", zh: "文本刻意不提供……" },
              { en: "The narrator protests too much.", zh: "叙述者的辩解过度，反而暴露问题。" },
              { en: "The tone slides from…to…", zh: "语气从……滑向……" },
            ],
          },
          {
            type: "tip",
            title: "写作练习",
            text: "用 150 字描写一场争执，只写其中一方的视角，要求不出现任何明显的说谎，但读者能感到叙述有偏。",
          },
        ],
        quiz: [
          {
            question: "\"I am not a difficult man\" as an opening most likely signals:",
            options: [
              "A reliable, modest narrator",
              "A narrator whose self-image is about to be undermined",
              "A factual report",
              "A comedy of manners",
            ],
            answer: 1,
            explanation: "过早、过度的自我辩护是典型声音线索，暗示叙述不可靠。",
          },
          {
            question: "A tonal clue is:",
            options: [
              "A footnote in a novel",
              "A shift in the narrator's voice that guides interpretation",
              "A chapter title",
              "A description of weather",
            ],
            answer: 1,
            explanation: "语气线索通过叙述声音的变化暗示读者应如何理解文本。",
          },
        ],
      },
      {
        slug: "silence-in-the-text",
        title: "Silence in the Text",
        titleZh: "文本中的沉默",
        summary:
          "最重要的信息，往往是没有被写下来的部分。用三组问题训练缺席的阅读。",
        level: "C2",
        minutes: 14,
        xp: 70,
        sortOrder: 2,
        content: [
          {
            type: "lead",
            text: "Read what is absent. Ask who has no scene, no line, no name.",
          },
          {
            type: "paragraph",
            text: "Close reading pays attention to gaps: characters without dialogue, events summarised rather than dramatised, adjectives never applied. Absence has structure, and structure is evidence.",
          },
          {
            type: "phrases",
            title: "三个提问",
            items: [
              { en: "Who is never given a direct voice?", zh: "谁从未被赋予直接发言权？" },
              { en: "Which scene is narrated in summary?", zh: "哪个场景被一句话带过？" },
              { en: "What does the ending refuse to explain?", zh: "结尾拒绝解释什么？" },
            ],
          },
          {
            type: "paragraph",
            text: "An essay that answers these questions has something original to say, because it looks where summary-oriented readers do not.",
          },
          {
            type: "quote",
            text: "Do not ask only what the author chose. Ask what the form could not bear to say.",
            source: "Seminar annotation",
          },
          {
            type: "tip",
            title: "论文落点",
            text: "把缺席当作结构选择，而不是作者的疏漏。用 The absence of X is not incidental; it is the condition of Y 这样的句式提出主张。",
          },
        ],
        quiz: [
          {
            question: "Reading for absence means noticing:",
            options: [
              "Typographical errors",
              "What the text avoids, omits, or summarises away",
              "Only the protagonist's feelings",
              "The author's biography",
            ],
            answer: 1,
            explanation: "缺席同样是结构，具有可分析的证据价值。",
          },
          {
            question: "The strongest interpretation of a gap is one that:",
            options: [
              "Calls the author careless",
              "Treats the gap as a structural choice with consequences",
              "Ignores it",
              "Quotes other critics only",
            ],
            answer: 1,
            explanation: "把缺席理解为结构选择及其后果，才能形成有说服力的论点。",
          },
        ],
      },
    ],
  },
];

export const WORD_SEED = [
  {
    word: "nuance",
    phonetic: "/ˈnjuː.ɑːns/",
    partOfSpeech: "n.",
    meaningZh: "细微差别；语气的层次",
    nuance: "指同一意思在不同语境中的细微色彩，不指「不同点」本身。高级表达的第一关键词。",
    exampleEn: "The nuance between regret and remorse is the difference between an action and a self.",
    exampleZh: "后悔与懊悔的细微差别，在于一个是行为，一个是自我。",
    level: "C1",
  },
  {
    word: "compelling",
    phonetic: "/kəmˈpel.ɪŋ/",
    partOfSpeech: "adj.",
    meaningZh: "极具说服力的；引人入胜的",
    nuance: "强调让人难以反驳或难以移开注意力，比 interesting 强得多，也比 convincing 更有吸引力。",
    exampleEn: "Her argument was compelling, not least because it was uncomfortable.",
    exampleZh: "她的论点极具说服力，恰因为它令人不适。",
    level: "C1",
  },
  {
    word: "articulate",
    phonetic: "/ɑːˈtɪk.jə.lət/",
    partOfSpeech: "adj. / v.",
    meaningZh: "表达清晰的；清楚地表达",
    nuance: "形容人时是赞美：思路清楚、措辞准确。作动词时强调把模糊的想法说清楚。",
    exampleEn: "He articulated what the room had been circling for an hour.",
    exampleZh: "他把整屋人绕了一小时的想法清晰地说了出来。",
    level: "C1",
  },
  {
    word: "inevitable",
    phonetic: "/ɪˈnev.ɪ.tə.bəl/",
    partOfSpeech: "adj.",
    meaningZh: "不可避免的",
    nuance: "强调因果上无法避免，而非时间上的确定。写作中常与 consequence 搭配。",
    exampleEn: "The delay was not inevitable; the silence made it so.",
    exampleZh: "这次延迟并非不可避免，是沉默让它变成必然。",
    level: "C1",
  },
  {
    word: "candid",
    phonetic: "/ˈkæn.dɪd/",
    partOfSpeech: "adj.",
    meaningZh: "坦诚的、直言的",
    nuance: "诚实但不粗暴，通常用于评价反馈或谈话，是职场高阶礼貌词。",
    exampleEn: "To be candid, the proposal solves a problem we no longer have.",
    exampleZh: "坦率地说，这个方案解决的是我们早已不存在的问题。",
    level: "C1",
  },
  {
    word: "reticent",
    phonetic: "/ˈret.ɪ.sənt/",
    partOfSpeech: "adj.",
    meaningZh: "寡言的、不愿多说的",
    nuance: "强调主动选择少说，而非害羞。与 reluctant 不同，后者的对象是动作。",
    exampleEn: "She was reticent about the meeting because she had lost the argument.",
    exampleZh: "她对那场会议闭口不谈，因为她在争论中落败了。",
    level: "C2",
  },
  {
    word: "ambiguous",
    phonetic: "/æmˈbɪɡ.ju.əs/",
    partOfSpeech: "adj.",
    meaningZh: "歧义的、可作多种解释的",
    nuance: "多元解读是客观属性；若想说「刻意含糊」，用 equivocal。",
    exampleEn: "The memo was deliberately ambiguous about who had authority.",
    exampleZh: "那份备忘录在谁有决定权的问题上刻意含糊。",
    level: "C1",
  },
  {
    word: "mitigate",
    phonetic: "/ˈmɪt.ɪ.ɡeɪt/",
    partOfSpeech: "v.",
    meaningZh: "减轻、缓和（风险或影响）",
    nuance: "正式用语，常用于风险与政策文本。别与 mediate（调解）混淆。",
    exampleEn: "No amount of framing can mitigate a deadline that was never achievable.",
    exampleZh: "再多的措辞包装，也无法减轻一个从未可行的截止日。",
    level: "C2",
  },
  {
    word: "pragmatic",
    phonetic: "/præɡˈmæt.ɪk/",
    partOfSpeech: "adj.",
    meaningZh: "务实的",
    nuance: "强调以结果为标准，含一点「因此可能不够理想」的暗示。",
    exampleEn: "The pragmatic choice is rarely the elegant one.",
    exampleZh: "务实的选择很少是优雅的选择。",
    level: "C1",
  },
  {
    word: "lucid",
    phonetic: "/ˈluː.sɪd/",
    partOfSpeech: "adj.",
    meaningZh: "清晰透彻的",
    nuance: "赞美复杂内容被讲得清楚，比 clear 更高级，多用于写作与讲解。",
    exampleEn: "A lucid sentence is an act of courtesy toward the reader.",
    exampleZh: "一句清晰透彻的话，是对读者的一次礼貌。",
    level: "C2",
  },
  {
    word: "discerning",
    phonetic: "/dɪˈsɜː.nɪŋ/",
    partOfSpeech: "adj.",
    meaningZh: "有鉴赏力的、眼光敏锐的",
    nuance: "形容判断力精细，常与 audience / eye / reader 搭配。",
    exampleEn: "The essay assumes a discerning reader rather than an agreeable one.",
    exampleZh: "这篇文章预设的是有鉴别力的读者，而非顺从的读者。",
    level: "C2",
  },
  {
    word: "ubiquitous",
    phonetic: "/juːˈbɪk.wɪ.təs/",
    partOfSpeech: "adj.",
    meaningZh: "无处不在的",
    nuance: "强调普遍到不被注意，常带轻微批判语气。",
    exampleEn: "The phrase has become so ubiquitous that its original irony is gone.",
    exampleZh: "这个说法已普遍到它最初的讽刺意味消失殆尽。",
    level: "C1",
  },
  {
    word: "resilient",
    phonetic: "/rɪˈzɪl.i.ənt/",
    partOfSpeech: "adj.",
    meaningZh: "有复原力的、能屈能伸的",
    nuance: "强调受压后恢复的能力，而非不受伤。商业语境中已略显滥用。",
    exampleEn: "A resilient argument bends under evidence without breaking.",
    exampleZh: "有韧性的论点会在证据前弯折，但不会断裂。",
    level: "C1",
  },
  {
    word: "prerequisite",
    phonetic: "/ˌpriːˈrek.wɪ.zɪt/",
    partOfSpeech: "n.",
    meaningZh: "先决条件",
    nuance: "强调逻辑或制度上必须先具备的条件，比 requirement 更严格。",
    exampleEn: "Trust is the prerequisite, not the reward, of a difficult conversation.",
    exampleZh: "信任是艰难对话的前提，而不是回报。",
    level: "C1",
  },
  {
    word: "prevalent",
    phonetic: "/ˈprev.əl.ənt/",
    partOfSpeech: "adj.",
    meaningZh: "普遍存在的、流行的",
    nuance: "描述某现象在特定范围内广泛存在，中性而学术。",
    exampleEn: "This misconception is more prevalent among experts than beginners.",
    exampleZh: "这个误解在专家中比在初学者中更普遍。",
    level: "C2",
  },
  {
    word: "coherent",
    phonetic: "/kəʊˈhɪə.rənt/",
    partOfSpeech: "adj.",
    meaningZh: "连贯的、逻辑一致的",
    nuance: "强调各部分能被合成一个整体，是论证与写作评价的核心词。",
    exampleEn: "The conclusion is elegant but not coherent with the evidence above it.",
    exampleZh: "结论很漂亮，却与上面的证据不够一致。",
    level: "C1",
  },
  {
    word: "succinct",
    phonetic: "/səkˈsɪŋkt/",
    partOfSpeech: "adj.",
    meaningZh: "简洁的、要言不烦的",
    nuance: "赞美用词少而信息足，比 short 有褒义，与 curt（无礼的简短）区分。",
    exampleEn: "Her feedback was succinct enough to be remembered.",
    exampleZh: "她的反馈简洁到足以被记住。",
    level: "C1",
  },
  {
    word: "deliberate",
    phonetic: "/dɪˈlɪb.ər.ət/",
    partOfSpeech: "adj.",
    meaningZh: "刻意的；从容的",
    nuance: "既可指有意为之，也可形容节奏沉稳，是雅思托福写作的高频副词来源。",
    exampleEn: "The pause was deliberate; it let the question land.",
    exampleZh: "那个停顿是刻意的，让问题真正落地。",
    level: "C1",
  },
];
