import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const links = [
  { href: "#features", label: "核心功能" },
  { href: "#showcase", label: "产品体验" },
  { href: "#testimonials", label: "学生评价" },
  { href: "#pricing", label: "定价" },
  { href: "#faq", label: "常见问题" },
];

export function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <a href="#top" className="group flex items-center gap-2.5" aria-label="Lexio 乐词 首页">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-500/30 transition-transform duration-300 group-hover:rotate-6 group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
          <path d="M9.5 8.5l2.5 5 2.5-5" />
        </svg>
      </span>
      <span className={cn("text-lg font-bold tracking-tight", dark ? "text-white" : "text-slate-900")}>
        Lexio<span className="text-gradient ml-1 font-extrabold">乐词</span>
      </span>
    </a>
  );
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "py-2" : "py-4"
      )}
    >
      <nav
        className={cn(
          "mx-auto flex max-w-6xl items-center justify-between gap-4 rounded-2xl px-4 py-2.5 transition-all duration-500 sm:px-6",
          scrolled ? "glass mx-4 shadow-xl shadow-indigo-900/5 lg:mx-auto" : "bg-transparent"
        )}
        aria-label="主导航"
      >
        <Logo />

        <ul className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="relative rounded-lg px-3.5 py-2 text-sm font-medium text-slate-600 transition-colors duration-200 hover:text-indigo-600 after:absolute after:bottom-1 after:left-1/2 after:h-0.5 after:w-0 after:-translate-x-1/2 after:rounded-full after:bg-gradient-to-r after:from-indigo-500 after:to-fuchsia-500 after:transition-all after:duration-300 hover:after:w-6"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 md:flex">
          <a href="#pricing" className="text-sm font-medium text-slate-600 transition-colors hover:text-indigo-600">
            登录
          </a>
          <a
            href="#cta"
            className="group relative inline-flex items-center gap-1.5 overflow-hidden rounded-xl bg-slate-900 px-4.5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-slate-900/20 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-indigo-500/30"
          >
            <span className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <span className="relative">免费开始</span>
            <svg className="relative h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <button
          className="grid h-10 w-10 place-items-center rounded-xl text-slate-700 transition-colors hover:bg-white/60 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label={open ? "关闭菜单" : "打开菜单"}
        >
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true">
            {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={cn(
          "glass mx-4 mt-2 overflow-hidden rounded-2xl shadow-xl shadow-indigo-900/10 transition-all duration-400 md:hidden",
          open ? "max-h-96 opacity-100" : "pointer-events-none max-h-0 opacity-0"
        )}
      >
        <ul className="flex flex-col p-3">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-xl px-4 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-indigo-50 hover:text-indigo-600"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li className="mt-2 border-t border-slate-200/70 pt-3">
            <a
              href="#cta"
              onClick={() => setOpen(false)}
              className="block rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-3 text-center text-sm font-semibold text-white shadow-lg shadow-indigo-500/30"
            >
              免费开始学习
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
