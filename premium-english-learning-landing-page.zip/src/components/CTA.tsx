import Reveal from "./Reveal";

export default function CTA() {
  return (
    <section id="cta" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <Reveal direction="scale">
          <div className="relative overflow-hidden rounded-[2.5rem] px-6 py-16 text-center shadow-2xl shadow-indigo-500/30 sm:px-12 sm:py-20">
            {/* bg */}
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600" aria-hidden="true" />
            <div className="animate-blob absolute -left-20 -top-20 h-72 w-72 rounded-full bg-white/15 blur-3xl" aria-hidden="true" />
            <div className="animate-blob absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-fuchsia-300/20 blur-3xl" style={{ animationDelay: "-8s" }} aria-hidden="true" />
            <div
              className="absolute inset-0 opacity-15"
              style={{
                backgroundImage: "radial-gradient(rgba(255,255,255,0.5) 1px, transparent 1px)",
                backgroundSize: "24px 24px",
              }}
              aria-hidden="true"
            />
            {/* floating words */}
            <span className="animate-float absolute left-[8%] top-[18%] hidden rounded-2xl bg-white/10 px-4 py-2 text-sm font-bold text-white/80 backdrop-blur-sm lg:block" aria-hidden="true">
              brilliant ✨
            </span>
            <span className="animate-float-slow absolute right-[10%] top-[26%] hidden rounded-2xl bg-white/10 px-4 py-2 text-sm font-bold text-white/80 backdrop-blur-sm lg:block" aria-hidden="true">
              achieve 🏆
            </span>
            <span className="animate-float absolute bottom-[20%] left-[14%] hidden rounded-2xl bg-white/10 px-4 py-2 text-sm font-bold text-white/80 backdrop-blur-sm lg:block" style={{ animationDelay: "-3s" }} aria-hidden="true">
              persist 🔥
            </span>
            <span className="animate-float-slow absolute bottom-[16%] right-[12%] hidden rounded-2xl bg-white/10 px-4 py-2 text-sm font-bold text-white/80 backdrop-blur-sm lg:block" style={{ animationDelay: "-5s" }} aria-hidden="true">
              succeed 🎓
            </span>

            <div className="relative mx-auto max-w-2xl">
              <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl">
                今天开始，
                <br className="sm:hidden" />
                让下一次考试刮目相看
              </h2>
              <p className="mt-5 text-base leading-relaxed text-indigo-100 sm:text-lg">
                免费试用 7 天 Pro 全部功能，无需绑定支付方式。
                加入 300 万学生，把单词变成你的得分利器。
              </p>
              <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <a
                  href="#top"
                  className="group inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-white px-8 py-4 text-base font-bold text-indigo-700 shadow-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl sm:w-auto"
                >
                  免费开始学习
                  <svg className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </a>
                <a
                  href="#pricing"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-white/30 bg-white/10 px-8 py-4 text-base font-bold text-white backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:bg-white/20 sm:w-auto"
                >
                  查看定价方案
                </a>
              </div>
              <p className="mt-6 text-xs font-medium text-indigo-200">
                ✓ 无需信用卡 &nbsp;·&nbsp; ✓ 随时取消 &nbsp;·&nbsp; ✓ iOS / Android / 网页全平台
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
