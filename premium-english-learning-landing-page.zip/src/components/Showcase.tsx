import { useState } from "react";
import Reveal from "./Reveal";
import { cn } from "../utils/cn";

const tabs = [
  {
    id: "plan",
    label: "智能词单",
    icon: "📅",
    title: "每天醒来，词单已为你排好",
    desc: "告诉 Lexio 你的考试目标和日期，AI 自动拆解考纲词库，生成刚刚好的每日任务——不多到崩溃，不少到焦虑。",
    points: ["按考试日期倒推每日词量", "新词与复习词智能配比", "漏打卡自动重排不堆积"],
  },
  {
    id: "review",
    label: "记忆引擎",
    icon: "⚡",
    title: "在你即将遗忘的那一刻出现",
    desc: "基于 FSRS 间隔重复算法，每个单词都有独立的记忆档案。复习永远发生在遗忘曲线的临界点，效率最大化。",
    points: ["逐词追踪记忆强度", "5 种题型交叉巩固", "错词自动进入强化队列"],
  },
  {
    id: "battle",
    label: "好友对战",
    icon: "⚔️",
    title: "和同桌来一场单词对决",
    desc: "实时匹配同词库的同学进行限时对战，赢取星光积分登上班级榜。背单词第一次有了「再来一局」的冲动。",
    points: ["1v1 实时限时对战", "班级 / 学校排行榜", "赛季奖励与成就徽章"],
  },
];

function ScreenMock({ tab }: { tab: (typeof tabs)[number] }) {
  return (
    <div className="relative mx-auto w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-[#12142b] p-6 shadow-2xl shadow-indigo-950/50">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
        </div>
        <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] font-semibold text-indigo-200">Lexio · {tab.label}</span>
      </div>

      {tab.id === "plan" && (
        <div className="mt-6 space-y-3" key="plan">
          <div className="rounded-2xl bg-gradient-to-r from-indigo-500/20 to-fuchsia-500/20 p-4 ring-1 ring-white/10">
            <p className="text-xs text-indigo-200">距离四级考试</p>
            <p className="mt-1 text-2xl font-bold text-white">38 天 <span className="text-sm font-medium text-indigo-300">· 剩余 1,460 词</span></p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
              <div className="h-full w-[64%] rounded-full bg-gradient-to-r from-indigo-400 to-fuchsia-400" />
            </div>
          </div>
          {[
            { t: "今日新词", n: "30 词", e: "✨", w: "w-[80%]" },
            { t: "待复习", n: "48 词", e: "🔄", w: "w-[45%]" },
            { t: "易错强化", n: "12 词", e: "🎯", w: "w-[20%]" },
          ].map((r) => (
            <div key={r.t} className="flex items-center gap-3 rounded-2xl bg-white/5 p-3.5 ring-1 ring-white/10 transition-colors hover:bg-white/10">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/10 text-base">{r.e}</span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">{r.t}</p>
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className={`h-full ${r.w} rounded-full bg-indigo-400`} />
                </div>
              </div>
              <span className="text-xs font-bold text-indigo-200">{r.n}</span>
            </div>
          ))}
        </div>
      )}

      {tab.id === "review" && (
        <div className="mt-6 space-y-3" key="review">
          <div className="rounded-2xl bg-white/5 p-5 text-center ring-1 ring-white/10">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-indigo-300">选择正确释义</p>
            <p className="mt-2 text-2xl font-bold text-white">ambiguous</p>
            <p className="mt-1 text-xs text-slate-400">/æmˈbɪɡjuəs/ · 考研高频 Top 200</p>
          </div>
          {[
            { t: "adj. 模棱两可的", ok: true },
            { t: "adj. 雄心勃勃的", ok: false },
            { t: "v. 使困惑", ok: false },
          ].map((o) => (
            <div
              key={o.t}
              className={cn(
                "flex items-center justify-between rounded-2xl p-3.5 text-sm font-medium ring-1 transition-colors",
                o.ok
                  ? "bg-emerald-400/15 text-emerald-300 ring-emerald-400/40"
                  : "bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10"
              )}
            >
              {o.t}
              {o.ok && <span className="text-base">✓</span>}
            </div>
          ))}
          <p className="pt-1 text-center text-[11px] text-slate-500">记忆强度 +18% · 下次复习：3 天后</p>
        </div>
      )}

      {tab.id === "battle" && (
        <div className="mt-6 space-y-3" key="battle">
          <div className="flex items-center justify-between rounded-2xl bg-gradient-to-r from-amber-500/20 to-rose-500/20 p-4 ring-1 ring-white/10">
            <div className="flex items-center gap-2.5">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-sky-400 to-indigo-500 text-sm font-bold text-white">我</span>
              <div>
                <p className="text-sm font-bold text-white">860 分</p>
                <p className="text-[10px] text-indigo-200">连对 ×7 🔥</p>
              </div>
            </div>
            <span className="text-lg font-black text-white/60">VS</span>
            <div className="flex items-center gap-2.5">
              <div className="text-right">
                <p className="text-sm font-bold text-white">720 分</p>
                <p className="text-[10px] text-indigo-200">同桌小陈</p>
              </div>
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-fuchsia-400 to-pink-500 text-sm font-bold text-white">陈</span>
            </div>
          </div>
          {[
            { r: "01", n: "林小雨 · 高三 (2) 班", s: "12,480", me: false },
            { r: "02", n: "你 · 冲刺四级词库", s: "11,920", me: true },
            { r: "03", n: "同桌小陈", s: "10,350", me: false },
          ].map((row) => (
            <div
              key={row.r}
              className={cn(
                "flex items-center gap-3 rounded-2xl p-3.5 ring-1",
                row.me ? "bg-indigo-500/20 ring-indigo-400/40" : "bg-white/5 ring-white/10"
              )}
            >
              <span className="text-xs font-black text-indigo-300">{row.r}</span>
              <span className="flex-1 text-sm font-medium text-white">{row.n}</span>
              <span className="text-xs font-bold text-amber-300">⭐ {row.s}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Showcase() {
  const [active, setActive] = useState(0);
  const tab = tabs[active];

  return (
    <section id="showcase" className="relative overflow-hidden py-24 sm:py-32">
      {/* dark panel background */}
      <div className="absolute inset-x-0 inset-y-0 mx-auto max-w-[96rem] sm:inset-x-4 sm:rounded-[3rem]" aria-hidden="true">
        <div className="absolute inset-0 overflow-hidden bg-[#0b0d1f] sm:rounded-[3rem]">
          <div className="animate-blob absolute -left-20 top-10 h-96 w-96 rounded-full bg-indigo-600/25 blur-3xl" />
          <div className="animate-blob absolute -right-10 bottom-0 h-80 w-80 rounded-full bg-fuchsia-600/20 blur-3xl" style={{ animationDelay: "-9s" }} />
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: "radial-gradient(rgba(165,180,252,0.25) 1px, transparent 1px)",
              backgroundSize: "28px 28px",
            }}
          />
        </div>
      </div>

      <div className="relative mx-auto max-w-6xl px-5 sm:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-indigo-200 ring-1 ring-white/15">
              产品体验
            </span>
          </Reveal>
          <Reveal delay={100} as="h2">
            <span className="mt-5 block text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl">
              打开 App 的每一分钟，<br className="hidden sm:block" />都在高效记忆
            </span>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <div className="mt-10 flex flex-wrap justify-center gap-2.5" role="tablist" aria-label="产品功能切换">
            {tabs.map((t, i) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={active === i}
                onClick={() => setActive(i)}
                className={cn(
                  "flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold transition-all duration-300",
                  active === i
                    ? "bg-white text-slate-900 shadow-xl shadow-indigo-950/40 scale-105"
                    : "bg-white/5 text-indigo-200 ring-1 ring-white/10 hover:bg-white/10 hover:text-white"
                )}
              >
                <span aria-hidden="true">{t.icon}</span>
                {t.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-12 grid items-center gap-12 lg:grid-cols-2">
          <Reveal direction="left" key={`text-${tab.id}`}>
            <div>
              <h3 className="text-2xl font-bold text-white sm:text-3xl">{tab.title}</h3>
              <p className="mt-4 text-base leading-relaxed text-slate-400">{tab.desc}</p>
              <ul className="mt-7 space-y-3.5">
                {tab.points.map((p, i) => (
                  <li key={p} className="flex items-center gap-3 text-sm font-medium text-indigo-100" style={{ transitionDelay: `${i * 80}ms` }}>
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-[11px] text-white shadow-lg shadow-indigo-500/30">
                      ✓
                    </span>
                    {p}
                  </li>
                ))}
              </ul>
              <a href="#cta" className="group mt-8 inline-flex items-center gap-2 text-sm font-semibold text-indigo-300 transition-colors hover:text-white">
                立即体验{tab.label}
                <svg className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
            </div>
          </Reveal>
          <Reveal direction="right" key={`mock-${tab.id}`} delay={120}>
            <ScreenMock tab={tab} />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
