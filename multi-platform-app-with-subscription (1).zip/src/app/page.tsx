import { DeviceShowcase } from "@/components/device-showcase";
import { Pricing } from "@/components/pricing";
import { Faq } from "@/components/faq";

const CURRICULUM = [
  {
    n: "01",
    title: "学术语域与模糊限制语",
    en: "Academic Hedging & Register",
    hours: "6 课时",
    level: "C1",
    desc: "把 prove 换成 suggest，语气立刻从断言回到证据。掌握 48 个高频限制表达与它们的强弱梯度。",
  },
  {
    n: "02",
    title: "搭配与类联接",
    en: "Collocation & Colligation",
    hours: "8 课时",
    level: "C1",
    desc: "你认识每一个词，却说不出它们的组合方式。从动词—名词、形容词—介词入手，重建语感的地基。",
  },
  {
    n: "03",
    title: "概念隐喻与抽象思维",
    en: "Conceptual Metaphor",
    hours: "5 课时",
    level: "C1+",
    desc: "time is money、argument is war——把英语借具体讲抽象的机制拆开，理解比喻如何塑造论证。",
  },
  {
    n: "04",
    title: "篇章衔接与信息结构",
    en: "Cohesion & Information Flow",
    hours: "7 课时",
    level: "C2",
    desc: "旧信息在前，新信息在后。段落的呼吸由已知—未知的推进决定，而不是由连接词的数量。",
  },
  {
    n: "05",
    title: "修辞与说服",
    en: "Rhetoric & Persuasion",
    hours: "6 课时",
    level: "C2",
    desc: "让步、反问、三段式与平行结构。从 TED 演讲到求职信，学会在英文里组织一场说服。",
  },
  {
    n: "06",
    title: "新闻英语的立场标记",
    en: "Stance in Journalism",
    hours: "5 课时",
    level: "C1+",
    desc: "报道与评论的边界藏在情态动词与副词里。读懂 The Economist 的克制，也读懂它的态度。",
  },
  {
    n: "07",
    title: "发音、连读与语调",
    en: "Connected Speech & Prosody",
    hours: "9 课时",
    level: "C1",
    desc: "英语是重音计时语言。节奏错了，词汇量再大也听不清。逐句影子跟读，重音、弱读与语调三项评分。",
  },
  {
    n: "08",
    title: "学术写作与同行评议",
    en: "Academic Writing & Peer Review",
    hours: "10 课时",
    level: "C2",
    desc: "从摘要到讨论段，写成审稿人愿意读完的样子。含两次真人一对一精批。",
  },
];

const METHOD = [
  {
    n: "01",
    k: "Input",
    zh: "输入",
    d: "精读一篇真实文本——The Economist、Nature、The New Yorker 的原文，逐句三层注解：词汇、搭配、语域。",
  },
  {
    n: "02",
    k: "Noticing",
    zh: "注意",
    d: "系统把高频搭配、词根词缀、模糊限制语高亮出来，让你第一次“看见”母语者真正在用的组合。",
  },
  {
    n: "03",
    k: "Output",
    zh: "输出",
    d: "用同一篇文本做仿写、改写与影子跟读。发音评分与语域评分即时反馈，错在哪一句就回到哪一句。",
  },
  {
    n: "04",
    k: "Retention",
    zh: "固着",
    d: "间隔复习把词放回它的语境例句里，而不是一张孤立的单词卡。23 天平均连续学习，就是这么来的。",
  },
];

const FEATURES = [
  {
    t: "双端同步的词库",
    d: "在电脑上标注的搭配，地铁上就能复习。4,612 条学术搭配、2,140 个词根与词缀、312 篇精读文本的全部笔记，在 macOS、Windows、iOS、Android 之间实时同步。",
    tag: "Sync",
    span: true,
  },
  {
    t: "影子跟读 Shadowing",
    d: "逐句回声、波形对比、语速渐进。准确度、流利度、语调三项独立评分，错的那一句自动进入明日任务。",
    tag: "Mobile first",
  },
  {
    t: "词根词源图谱",
    d: "spect ← specere「看」，一屏看懂 inspect / perspective / spectator / introspect 一族词。",
    tag: "Etymology",
  },
  {
    t: "AI 学术写作批改",
    d: "从语域、衔接、模糊限制、搭配四个维度评分，给出可直接替换的改写句，而不是一个笼统的分数。",
    tag: "Desktop",
  },
  {
    t: "语境化间隔复习",
    d: "SRS 算法按遗忘曲线排程，卡片上永远是完整的句子与出处，不做孤立单词的机械背诵。",
    tag: "SRS",
  },
  {
    t: "三层精读注解",
    d: "一段原文，三层注释：这一句的词、这一句的搭配、这一句在整篇里的立场。点击任一标注即展开。",
    tag: "Reading",
  },
];

const DOWNLOADS = [
  {
    group: "电脑端",
    en: "Desktop",
    desc: "深度精读、学术写作、词根图谱、批量笔记导出。",
    items: [
      { os: "macOS 13+", arch: "Apple Silicon / Intel", v: "3.4.1", size: "142 MB" },
      { os: "Windows 10+", arch: "x64 / arm64", v: "3.4.1", size: "148 MB" },
    ],
  },
  {
    group: "手机端",
    en: "Mobile",
    desc: "影子跟读、词卡复习、离线精读、每日学习提醒。",
    items: [
      { os: "iOS 16+", arch: "iPhone / iPad", v: "3.4.0", size: "88 MB" },
      { os: "Android 10+", arch: "arm64", v: "3.4.0", size: "76 MB" },
    ],
  },
];

export default function Home() {
  return (
    <main id="top">
      {/* ───────────── HERO ───────────── */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-[1400px] gap-10 px-5 pb-16 pt-12 sm:px-8 lg:grid-cols-[1.12fr_0.88fr] lg:gap-16 lg:pt-20">
          <div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
              <span className="label border border-ink/18 px-2.5 py-1 text-[8.5px] text-ink/70">
                CEFR C1 — C2
              </span>
              <span className="label text-[8.5px] text-taupe">雅思 7.5+ · 托福 105+ · 学术与职业英语</span>
            </div>

            <h1 className="mt-8">
              <span className="display block text-[clamp(3.1rem,8.4vw,7.4rem)]">
                English,
                <br />
                <em className="font-light italic text-vermilion">past fluency.</em>
              </span>
              <span className="hans mt-7 block text-[clamp(1.75rem,4.2vw,3.05rem)] font-bold leading-[1.28] tracking-[-0.015em]">
                从「看得懂」，
                <br className="hidden sm:block" />
                到「说得地道」。
              </span>
            </h1>

            <p className="hans measure mt-8 text-[15px] leading-[2.05] text-ink/74">
              语脉 VERBA 是一套面向高阶学习者的英语训练系统。
              <strong className="font-semibold text-ink">电脑端</strong>负责深度——精读注解、学术写作、词根图谱；
              <strong className="font-semibold text-ink">手机端</strong>负责频率——影子跟读、间隔复习、碎片时间的词卡。
              同一个账号，两块屏幕，一个进度。
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <a
                href="#pricing"
                className="hans bg-ink px-7 py-4 text-[14.5px] font-medium text-paper transition-colors hover:bg-vermilion"
              >
                开始 7 天免费试用
              </a>
              <a
                href="#curriculum"
                className="hans border border-ink/22 px-7 py-4 text-[14.5px] transition-colors hover:border-ink hover:bg-white/50"
              >
                查看课程体系 →
              </a>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2">
              {["全部功能开放", "不需绑定支付方式", "到期不自动扣款", "随时取消"].map((t) => (
                <span key={t} className="hans flex items-center gap-1.5 text-[11.5px] text-taupe">
                  <span className="h-1 w-1 rounded-full bg-vermilion" />
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* 图像：暖光书桌 */}
          <div className="relative min-h-[320px] lg:min-h-[560px]">
            <div className="absolute inset-y-0 left-0 right-[-20vw] lg:right-[-14vw]">
              <img
                src="images/desk.jpg"
                alt="批注过的英文精装书与索引卡"
                className="h-full w-full object-cover object-center"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-paper via-paper/18 to-transparent" />
              <div className="absolute inset-0 bg-vermilion/8 mix-blend-multiply" />
            </div>
            <div className="absolute bottom-5 right-6 max-w-[210px] border-l-2 border-vermilion pl-3">
              <div className="label text-[7.5px] text-ink/60">Plate 01</div>
              <div className="hans mt-1 text-[11px] leading-relaxed text-ink/72">
                一段原文，三层注解。所有语料均来自真实出版物，注明期号与作者。
              </div>
            </div>
          </div>
        </div>

        {/* 双端展示 */}
        <div className="rule-strong bg-paper-2/70">
          <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8">
            <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="label text-vermilion">The software · 双端客户端</div>
                <h2 className="hans mt-4 text-[clamp(1.65rem,3.4vw,2.5rem)] font-bold leading-[1.35] tracking-[-0.015em]">
                  同一个软件，在两块屏幕上
                  <br className="hidden sm:block" />
                  都长成它该有的样子。
                </h2>
              </div>
              <div className="hidden gap-8 md:flex">
                {[
                  ["客户端版本", "3.4.1 / 3.4.0"],
                  ["支持系统", "macOS · Win · iOS · Android"],
                  ["同步延迟", "< 400 ms"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <div className="label text-[8px] text-taupe">{k}</div>
                    <div className="num mt-1.5 text-[13px]">{v}</div>
                  </div>
                ))}
              </div>
            </div>
            <DeviceShowcase />
          </div>
        </div>
      </section>

      {/* ───────────── 数据横幅 ───────────── */}
      <section className="ink-band px-5 py-14 sm:px-8">
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-y-10 md:grid-cols-5">
          {[
            ["12,800", "名 C1+ 进阶学员"],
            ["312", "篇精读文本 · 逐句注解"],
            ["4,612", "条学术搭配与类联接"],
            ["23", "天 · 学员平均连续学习"],
            ["4.9", "双端应用商店评分 / 5.0"],
          ].map(([v, k]) => (
            <div key={k} className="border-l border-paper/18 pl-5">
              <div className="num text-[clamp(1.9rem,3.4vw,2.75rem)] leading-none tracking-[-0.03em] text-paper">
                {v}
              </div>
              <div className="hans mt-3 text-[11.5px] leading-relaxed text-paper/70">{k}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ───────────── 课程体系 ───────────── */}
      <section id="curriculum" className="scroll-mt-20 px-5 py-24 sm:px-8">
        <div className="mx-auto max-w-[1400px]">
          <div className="grid gap-10 border-b-2 border-ink pb-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <div className="label text-vermilion">Curriculum · 课程体系</div>
              <h2 className="hans mt-5 text-[clamp(2.2rem,5vw,3.9rem)] font-bold leading-[1.14] tracking-[-0.022em]">
                56 课时，
                <br />
                八个真实的
                <span className="text-vermilion">语言问题</span>。
              </h2>
            </div>
            <p className="hans self-end text-[14.5px] leading-[2.05] text-ink/72">
              高阶英语的瓶颈从来不是词汇量，而是<strong className="font-semibold text-ink">语域、搭配与立场</strong>。
              语脉的八门课程不按“话题”划分，而按语言本身的结构问题划分：
              为什么这句话在这里显得专业，为什么那句话听起来像机器翻译。
              每一课都以一篇真实文本为骨架，可逐句注解、逐句跟读、逐句仿写。
            </p>
          </div>

          {/* 词条式目录 */}
          <div>
            {CURRICULUM.map((c, i) => (
              <article
                key={c.n}
                className="group grid grid-cols-1 gap-x-8 gap-y-3 border-b border-ink/12 py-7 transition-colors hover:bg-white/45 md:grid-cols-[64px_1fr_1.25fr_120px]"
              >
                <div className="num pt-1 text-[12px] text-vermilion">{c.n}</div>
                <div>
                  <h3 className="hans text-[19px] font-semibold leading-snug">{c.title}</h3>
                  <div className="mt-1.5 text-[11.5px] italic text-taupe" style={{ fontFamily: "Fraunces, serif" }}>
                    {c.en}
                  </div>
                </div>
                <p className="hans text-[12.5px] leading-[1.95] text-ink/68">{c.desc}</p>
                <div className="flex items-start gap-3 md:flex-col md:items-end md:gap-1.5">
                  <span className="num text-[11px] text-ink/70">{c.hours}</span>
                  <span className="label border border-ink/18 px-2 py-[3px] text-[8px] text-taupe">
                    Level {c.level}
                  </span>
                </div>

                {/* 两门课程配图 */}
                {i === 1 && (
                  <div className="col-span-full mt-4 overflow-hidden">
                    <img
                      src="images/module-collocation.jpg"
                      alt="搭配与类联接示意图"
                      className="h-[150px] w-full object-cover opacity-95 md:h-[190px]"
                      loading="lazy"
                    />
                  </div>
                )}
                {i === 4 && (
                  <div className="col-span-full mt-4 overflow-hidden">
                    <img
                      src="images/module-rhetoric.jpg"
                      alt="修辞与说服示意图"
                      className="h-[150px] w-full object-cover opacity-95 md:h-[190px]"
                      loading="lazy"
                    />
                  </div>
                )}
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ───────────── 方法论 ───────────── */}
      <section id="method" className="ink-band relative scroll-mt-20 overflow-hidden">
        <div className="mx-auto grid max-w-[1400px] lg:grid-cols-[0.85fr_1.15fr]">
          <div className="relative min-h-[280px] lg:min-h-full">
            <img
              src="images/letterpress.jpg"
              alt="活字凸版金属字模特写"
              className="absolute inset-0 h-full w-full object-cover opacity-72"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-ink/70 via-ink/25 to-ink" />
            <div className="absolute bottom-8 left-8 max-w-[230px]">
              <div className="label text-[8px] text-vermilion">Plate 02</div>
              <p className="hans mt-2 text-[11.5px] leading-[1.9] text-paper/72">
                语言的习得像排版：先选字，再组合，最后才是印刷的精度。
              </p>
            </div>
          </div>

          <div className="px-5 py-20 sm:px-10">
            <div className="label text-vermilion">Method · 学习方法</div>
            <h2 className="hans mt-5 text-[clamp(2rem,4.2vw,3.2rem)] font-bold leading-[1.2] tracking-[-0.02em]">
              输入 · 注意 · 输出 · 固着
            </h2>
            <p className="hans measure mt-5 text-[13.5px] leading-[2] text-paper/74">
              语脉的每节课都遵循同一条路径。它不是“看视频 + 做题”，而是一次完整的语言处理循环。
            </p>

            <div className="mt-12 space-y-0">
              {METHOD.map((m) => (
                <div key={m.n} className="grid grid-cols-[52px_1fr] gap-5 border-t border-paper/16 py-7">
                  <div>
                    <div className="num text-[13px] text-vermilion">{m.n}</div>
                    <div className="label mt-1.5 text-[7.5px] text-paper/58">{m.k}</div>
                  </div>
                  <div>
                    <h3 className="hans text-[18px] font-semibold text-paper">{m.zh}</h3>
                    <p className="hans mt-2.5 max-w-[42rem] text-[13px] leading-[2] text-paper/74">{m.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ───────────── 功能 ───────────── */}
      <section id="features" className="scroll-mt-20 px-5 py-24 sm:px-8">
        <div className="mx-auto max-w-[1400px]">
          <div className="flex flex-wrap items-end justify-between gap-6 border-b-2 border-ink pb-8">
            <div>
              <div className="label text-vermilion">Features · 双端功能</div>
              <h2 className="hans mt-5 text-[clamp(2.1rem,4.6vw,3.5rem)] font-bold leading-[1.15] tracking-[-0.022em]">
                六件小事，
                <br />
                做到极致。
              </h2>
            </div>
            <p className="hans max-w-sm text-[13px] leading-[2] text-taupe">
              每一项功能都对应一个具体的语言问题，没有为了功能表而存在的功能。
            </p>
          </div>

          <div className="grid gap-px bg-ink/12 md:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f, i) => (
              <div
                key={f.t}
                className={`group relative bg-paper p-8 transition-colors hover:bg-white/60 ${
                  f.span ? "lg:col-span-2 lg:p-10" : ""
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <h3
                    className={`hans font-semibold leading-snug ${
                      f.span ? "text-[clamp(1.55rem,2.7vw,2.15rem)] tracking-[-0.015em]" : "text-[19px]"
                    }`}
                  >
                    {f.t}
                  </h3>
                  <span className="label shrink-0 border border-ink/15 px-2 py-[3px] text-[7.5px] text-taupe">
                    {f.tag}
                  </span>
                </div>
                <p
                  className={`hans mt-5 leading-[2] text-ink/68 ${
                    f.span ? "max-w-2xl text-[14px]" : "text-[12.5px]"
                  }`}
                >
                  {f.d}
                </p>
                <div className="num mt-7 text-[10px] text-taupe/70">
                  {String(i + 1).padStart(2, "0")} / 06
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───────────── 下载 ───────────── */}
      <section id="download" className="scroll-mt-20 bg-paper-2/60 px-5 py-24 sm:px-8">
        <div className="mx-auto max-w-[1400px]">
          <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:gap-16">
            <div>
              <div className="label text-vermilion">Download · 软件下载</div>
              <h2 className="hans mt-5 text-[clamp(2.1rem,4.6vw,3.5rem)] font-bold leading-[1.15] tracking-[-0.022em]">
                一个订阅，
                <br />
                覆盖你所有的
                <span className="text-vermilion">屏幕</span>。
              </h2>
              <p className="hans measure mt-6 text-[14px] leading-[2.05] text-ink/72">
                电脑端与手机端不是两个产品，而是同一个词库的两种形态。
                登录同一账号后，笔记、进度、跟读录音与复习队列自动同步；
                在电脑上标注的搭配，通勤路上就会出现在手机的复习卡片里。
              </p>

              <div className="mt-8 border border-ink/14 bg-white/52">
                {[
                  ["同步延迟", "< 400 ms"],
                  ["离线可用", "精读文本 / 词卡 / 跟读音频"],
                  ["账号体系", "邮箱 + 手机号，支持 Apple / 微信登录"],
                  ["数据导出", "Anki · CSV · Markdown 随时导出"],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-baseline justify-between gap-6 border-b border-ink/10 px-5 py-3.5 last:border-0">
                    <span className="hans text-[12px] text-taupe">{k}</span>
                    <span className="num text-[11.5px] text-right">{v}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-8">
              {DOWNLOADS.map((group) => (
                <div key={group.group} className="border border-ink/14 bg-white/52">
                  <div className="flex items-end justify-between border-b border-ink/12 px-6 py-5">
                    <div>
                      <h3 className="hans text-[21px] font-semibold">{group.group}</h3>
                      <div className="label mt-1 text-[8px] text-taupe">{group.en} client</div>
                    </div>
                    <p className="hans max-w-[220px] text-right text-[11px] leading-relaxed text-taupe">
                      {group.desc}
                    </p>
                  </div>
                  {group.items.map((it) => (
                    <div
                      key={it.os}
                      className="flex flex-wrap items-center gap-x-5 gap-y-3 border-b border-ink/10 px-6 py-5 last:border-0"
                    >
                      <div className="min-w-[150px]">
                        <div className="num text-[14px]">{it.os}</div>
                        <div className="num mt-1 text-[10px] text-taupe">{it.arch}</div>
                      </div>
                      <div className="num text-[10.5px] text-taupe">
                        v{it.v} · {it.size}
                      </div>
                      <a
                        href="#pricing"
                        className="hans ml-auto bg-ink px-5 py-2.5 text-[12px] text-paper transition-colors hover:bg-vermilion"
                      >
                        下载客户端
                      </a>
                    </div>
                  ))}
                </div>
              ))}

              <div className="flex items-start gap-4 border border-dashed border-ink/25 px-6 py-5">
                <div className="h-2 w-2 shrink-0 translate-y-2 rounded-full bg-vermilion" />
                <p className="hans text-[12px] leading-[1.95] text-taupe">
                  试用期内可在全部平台登录。试用结束后客户端仍可打开、浏览已下载内容，
                  但新的学习任务需要订阅后继续。
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ───────────── 价格与试用 ───────────── */}
      <Pricing />

      {/* ───────────── FAQ ───────────── */}
      <Faq />
    </main>
  );
}
