import { NextResponse } from "next/server";
import { ensureUser, resolveAccess } from "@/lib/billing";

export const dynamic = "force-dynamic";

export const LESSON_LIBRARY: Record<
  string,
  { title: string; titleEn: string; source: string; minutes: number; body: string[] }
> = {
  "hedges-01": {
    title: "模糊限制语：把断言调成学术语气",
    titleEn: "Academic Hedging & Register",
    source: "The Economist · Science & technology",
    minutes: 18,
    body: [
      "Ocean acidification has often been called the “other CO₂ problem”.",
      "Researchers suggest that surface pH may fall by a further 0.3 units by 2100 — a change that would appear modest on paper, yet is widely regarded as catastrophic for calcifying organisms.",
      "It is worth noting that the wording matters: a verb such as “prove” commits the writer to certainty, whereas “indicate”, “suggest” or “point to” leave room for the evidence to move.",
    ],
  },
};

export async function GET(req: Request) {
  try {
    const slug = new URL(req.url).searchParams.get("slug") ?? "hedges-01";
    const account = await ensureUser();
    const access = await resolveAccess(account.id);
    const lesson = LESSON_LIBRARY[slug] ?? LESSON_LIBRARY["hedges-01"];

    if (access.tier === "locked") {
      return NextResponse.json(
        {
          ok: false,
          reason: "trial_expired",
          access,
          preview: lesson.body.slice(0, 1),
          message: "试用已结束，订阅后继续学习第 02 课及之后的全部内容。",
        },
        { status: 402 }
      );
    }

    return NextResponse.json({ ok: true, access, lesson });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "lesson_failed" },
      { status: 500 }
    );
  }
}
