import { NextResponse } from "next/server";
import { ensureUser, resolveAccess, touchProgress } from "@/lib/billing";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      lessonSlug?: string;
      device?: "desktop" | "mobile";
      seconds?: number;
    };
    const account = await ensureUser();
    await touchProgress(
      account.id,
      body.lessonSlug ?? "hedges-01",
      body.device === "mobile" ? "mobile" : "desktop",
      Math.max(0, Math.min(20000, Math.round(body.seconds ?? 60)))
    );
    return NextResponse.json({ ok: true, access: await resolveAccess(account.id) });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "progress_failed" },
      { status: 500 }
    );
  }
}
