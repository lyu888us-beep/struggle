import { NextResponse } from "next/server";
import {
  cancelSubscription,
  createSubscription,
  endTrialNow,
  ensureUser,
  planByCode,
  restartTrial,
} from "@/lib/billing";

export const dynamic = "force-dynamic";

type Payload = {
  action?: "subscribe" | "cancel" | "simulate-expiry" | "reset-trial";
  planCode?: string;
  method?: string;
};

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Payload;
    const account = await ensureUser();

    if (body.action === "subscribe") {
      const planCode = body.planCode ?? "yearly";
      const method = body.method ?? "wechat";
      if (!["monthly", "yearly", "team"].includes(planCode)) {
        return NextResponse.json({ ok: false, error: "unknown_plan" }, { status: 400 });
      }
      const receipt = await createSubscription({ userId: account.id, planCode, method });
      return NextResponse.json({
        ok: true,
        plan: planByCode(planCode),
        receipt,
        message: "支付成功，全部课程已在双端解锁。",
      });
    }

    if (body.action === "cancel") {
      const done = await cancelSubscription(account.id);
      return NextResponse.json({
        ok: true,
        canceled: done,
        message: done
          ? "已关闭自动续费，当前计费周期结束时失效。"
          : "当前没有进行中的订阅。",
      });
    }

    if (body.action === "simulate-expiry") {
      await endTrialNow(account.id);
      return NextResponse.json({
        ok: true,
        message: "已模拟试用到期：课程将被锁定并触发付费墙。",
      });
    }

    if (body.action === "reset-trial") {
      await restartTrial(account.id);
      return NextResponse.json({ ok: true, message: "试用已重置为 7 天。" });
    }

    return NextResponse.json({ ok: false, error: "unknown_action" }, { status: 400 });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "billing_failed" },
      { status: 500 }
    );
  }
}
