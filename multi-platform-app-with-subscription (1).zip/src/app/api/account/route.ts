import { NextResponse } from "next/server";
import {
  DEVICE_COOKIE,
  ensureUser,
  listOrders,
  recentProgress,
  resolveAccess,
} from "@/lib/billing";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const account = await ensureUser();
    const access = await resolveAccess(account.id);
    const orderRows = await listOrders(account.id);
    const progressRows = await recentProgress(account.id);

    const res = NextResponse.json({
      ok: true,
      isNew: account.isNew,
      access,
      orders: orderRows.map((o) => ({
        invoiceNo: o.invoiceNo,
        amountCents: o.amountCents,
        method: o.method,
        status: o.status,
        createdAt: o.createdAt.toISOString(),
      })),
      activity: progressRows.map((p) => ({
        lessonSlug: p.lessonSlug,
        device: p.device,
        seconds: p.seconds,
        updatedAt: p.updatedAt.toISOString(),
      })),
    });

    if (account.isNew) {
      res.cookies.set(DEVICE_COOKIE, account.deviceKey, {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 365,
        path: "/",
      });
    }
    return res;
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "account_failed" },
      { status: 500 }
    );
  }
}
