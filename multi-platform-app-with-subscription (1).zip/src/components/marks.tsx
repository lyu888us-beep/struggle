export function VerbaMark({ className = "h-7 w-7" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <rect x="0.5" y="0.5" width="39" height="39" rx="3" fill="#17181b" />
      <path
        d="M8.5 10.5h7.2c2.05 0 3.42.42 4.5 1.42 1.1 1.02 1.63 2.36 1.63 4.06 0 1.83-.5 3.25-1.55 4.32-1.02 1.05-2.4 1.55-4.28 1.55h-3.02v7.6H8.5V10.5Zm4.48 6.53h1.6c1.9 0 2.86-.62 2.86-1.98 0-1.34-.96-1.94-2.86-1.94h-1.6v3.92Z"
        fill="#f3eee6"
      />
      <path d="M22.8 10.5h4.5l3.6 12.1 3.6-12.1h4.4L31.9 30h-4.2L22.8 10.5Z" fill="#f3eee6" />
      <path d="M4 33.6h32" stroke="#c8452c" strokeWidth="2.4" strokeLinecap="square" />
    </svg>
  );
}

export function Waveform({
  bars = 34,
  active = true,
  className = "h-10 w-full",
}: {
  bars?: number;
  active?: boolean;
  className?: string;
}) {
  const heights = Array.from({ length: bars }, (_, i) => {
    const v = Math.abs(Math.sin(i * 1.37) * 0.62 + Math.sin(i * 0.41) * 0.34);
    return 0.18 + v * 0.82;
  });
  return (
    <svg viewBox={`0 0 ${bars * 4} 40`} preserveAspectRatio="none" className={className} aria-hidden="true">
      {heights.map((h, i) => {
        const played = i / bars < 0.58;
        return (
          <rect
            key={i}
            x={i * 4}
            y={20 - (h * 36) / 2}
            width="2.1"
            height={h * 36}
            rx="1"
            fill={active && played ? "#c8452c" : "#17181b"}
            opacity={active && played ? 1 : 0.22}
          />
        );
      })}
    </svg>
  );
}
