"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";

const ITEMS = [
  {
    q: "7 天试用是怎么计算的？",
    a: "从你在任一客户端注册的那一刻起满 168 小时。到期前 24 小时我们会通过站内与邮件提醒你。试用不绑定任何支付方式，到期后不会自动扣款——只有你主动选择计划并完成支付，才会开始计费。",
  },
  {
    q: "试用到期后，我的学习数据还在吗？",
    a: "全部保留。词卡、笔记、跟读录音、学习报告都会留在你的账号里，只是学习功能会被锁定：每课保留前三段预览，词库可浏览但无法进入复习队列。订阅后立即恢复，进度不会重置。",
  },
  {
    q: "电脑端和手机端需要分别购买吗？",
    a: "不需要。一个订阅覆盖全部平台：macOS 13+、Windows 10+、iOS 16+、Android 10+。登录同一账号即可同步词库、笔记、学习进度与跟读录音，切换设备时从上次中断的句子继续。",
  },
  {
    q: "可以随时取消吗？",
    a: "可以。在「我的账户 → 订阅管理」中一键关闭自动续费，当前计费周期结束时失效，期间功能不受影响。当期费用不予退还，但订阅后 7 天内可申请全额退款。",
  },
  {
    q: "支持哪些支付方式？是否开发票？",
    a: "支持微信支付、支付宝（含花呗分期）以及 Visa / Mastercard。所有支付均支持开具电子普通发票，订单号可在账户页查询，发票会在支付后 24 小时内发送至你的邮箱。",
  },
  {
    q: "学生或院校有优惠吗？",
    a: "有。使用 .edu 邮箱完成学生认证后，年度计划立减至 7 折（¥412 / 年）。院校与团队 5 席起购，含教师后台、班级词库与学习报告导出，可统一开票，具体请联系 hi@verba.study。",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="scroll-mt-20 px-5 py-24 sm:px-8">
      <div className="mx-auto grid max-w-[1400px] gap-12 lg:grid-cols-[0.85fr_1.4fr]">
        <div>
          <div className="label text-vermilion">FAQ · 常见问题</div>
          <h2 className="hans mt-5 text-[clamp(2.1rem,4.4vw,3.4rem)] font-bold leading-[1.12] tracking-[-0.02em]">
            关于试用、
            <br />
            计费与退款
          </h2>
          <p className="hans mt-5 text-[13.5px] leading-[2] text-taupe">
            没找到答案？写信到{" "}
            <a href="mailto:hi@verba.study" className="text-vermilion underline underline-offset-4">
              hi@verba.study
            </a>
            ，工作日 12 小时内回复。
          </p>
        </div>

        <div>
          {ITEMS.map((item, i) => {
            const on = open === i;
            return (
              <div key={item.q} className="border-b border-ink/14">
                <button
                  onClick={() => setOpen(on ? null : i)}
                  className="flex w-full items-start gap-5 py-6 text-left"
                  aria-expanded={on}
                >
                  <span className="num mt-1 text-[11px] text-vermilion">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="hans flex-1 text-[17px] font-semibold leading-[1.6]">{item.q}</span>
                  <motion.span animate={{ rotate: on ? 45 : 0 }} transition={{ duration: 0.25 }}>
                    <Plus className="h-4 w-4 text-taupe" />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {on && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="hans measure pb-7 pl-[38px] text-[13.5px] leading-[2.1] text-ink/72">
                        {item.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
