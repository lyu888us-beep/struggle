"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  BarChart3,
  BookOpen,
  ChevronRight,
  Home,
  Layers,
  Mic,
  Play,
  Search,
  Settings,
  User,
} from "lucide-react";
import { Waveform } from "@/components/marks";

type Device = "desktop" | "mobile";

const DESKTOP_NAV = [
  { icon: Home, label: "今日训练", active: true },
  { icon: BookOpen, label: "精读库" },
  { icon: Mic, label: "影子跟读" },
  { icon: Layers, label: "词库 · 4,612" },
  { icon: BarChart3, label: "学习报告" },
  { icon: Settings, label: "设置" },
];

const PHONE_TABS = [
  { icon: Home, label: "今日", active: true },
  { icon: BookOpen, label: "精读" },
  { icon: Mic, label: "跟读" },
  { icon: Layers, label: "词库" },
  { icon: User, label: "我的" },
];

function DesktopScreen() {
  return (
    <div className="flex h-[450px] w-[720px] flex-col overflow-hidden bg-paper">
      {/* 窗口栏 */}
      <div className="flex h-[30px] shrink-0 items-center gap-2 border-b border-ink/10 bg-paper-2 px-3">
        <span className="h-[8px] w-[8px] rounded-full bg-[#d8a49a]" />
        <span className="h-[8px] w-[8px] rounded-full bg-[#e0c89b]" />
        <span className="h-[8px] w-[8px] rounded-full bg-[#a9c0a6]" />
        <div className="mx-auto flex h-[18px] w-[260px] items-center gap-1.5 rounded-full border border-ink/10 bg-white/70 px-2.5">
          <Search className="h-[9px] w-[9px] text-taupe" />
          <span className="num text-[8.5px] text-taupe">搜索：hedging verbs in academic prose</span>
        </div>
        <span className="label text-[7px] text-taupe">3.4.1</span>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* 侧栏 */}
        <aside className="flex w-[164px] shrink-0 flex-col bg-ink-2 px-3 py-4">
          <div className="label mb-5 px-2 text-[8px] text-paper/45">Verba Desktop</div>
          <nav className="space-y-[3px]">
            {DESKTOP_NAV.map((item) => (
              <div
                key={item.label}
                className={`flex items-center gap-2 rounded-[3px] px-2 py-[6px] ${
                  item.active ? "bg-vermilion text-white" : "text-paper/62 hover:bg-white/6"
                }`}
              >
                <item.icon className="h-[11px] w-[11px]" />
                <span className="text-[9.5px]">{item.label}</span>
                {item.active && <ChevronRight className="ml-auto h-[9px] w-[9px]" />}
              </div>
            ))}
          </nav>
          <div className="mt-auto border-t border-paper/12 pt-3">
            <div className="num flex items-baseline justify-between text-[8px] text-paper/55">
              <span>试用剩余</span>
              <span className="text-vermilion">6 天</span>
            </div>
            <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-paper/15">
              <div className="h-full w-[86%] bg-vermilion" />
            </div>
            <div className="num mt-2 text-[7.5px] text-paper/38">全功能开放 · 到期不自动扣款</div>
          </div>
        </aside>

        {/* 主栏 */}
        <main className="min-w-0 flex-1 px-6 py-4">
          <div className="label text-[7.5px] text-taupe">
            The Economist · Science &amp; technology · 1,240 词 · CEFR C1
          </div>
          <h3 className="mt-1.5 text-[19px] leading-[1.15] tracking-[-0.02em]" style={{ fontFamily: "Fraunces, serif" }}>
            Ocean acidification: <span className="italic text-vermilion">the other</span> CO₂ problem
          </h3>
          <p className="mt-3 text-[10px] leading-[1.95] text-ink/82">
            Ocean acidification has often been called the{" "}
            <span className="bg-vermilion/12 px-[3px]">“other CO₂ problem”</span>. Researchers{" "}
            <span className="border-b-2 border-vermilion pb-[1px]">suggest that</span> surface pH may
            fall by a further 0.3 units by 2100 — a change that would{" "}
            <span className="border-b-2 border-vermilion pb-[1px]">appear modest on paper</span>, yet
            is widely regarded as catastrophic for calcifying organisms.
          </p>
          <p className="mt-2.5 text-[10px] leading-[1.95] text-ink/70">
            It is worth noting that the wording matters: a verb such as “prove” commits the writer to
            certainty, whereas <span className="border-b-2 border-vermilion pb-[1px]">indicate</span>,{" "}
            <span className="border-b-2 border-vermilion pb-[1px]">point to</span> leave room for the
            evidence to move.
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            {[
              { k: "REGISTER", v: "hedging · suggest / indicate / point to" },
              { k: "COLLOCATION", v: "appear modest on paper" },
              { k: "SYNTAX", v: "It is worth noting that …" },
            ].map((tag) => (
              <div
                key={tag.k}
                className="flex items-center gap-2 border border-vermilion/35 bg-vermilion/8 px-2 py-[5px]"
              >
                <span className="label text-[6.5px] text-vermilion">{tag.k}</span>
                <span className="text-[8.5px] text-ink/78">{tag.v}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-3 border-t border-ink/10 pt-3">
            <div className="flex h-[26px] w-[26px] items-center justify-center rounded-full bg-vermilion">
              <Play className="h-[9px] w-[9px] fill-white text-white" />
            </div>
            <div className="flex-1">
              <div className="flex h-[18px] items-end gap-[2px]">
                {Array.from({ length: 64 }).map((_, i) => (
                  <span
                    key={i}
                    className="w-[2px] rounded-full"
                    style={{
                      height: `${6 + Math.abs(Math.sin(i * 0.9) * 12)}px`,
                      background: i < 34 ? "#c8452c" : "rgba(23,24,27,0.18)",
                    }}
                  />
                ))}
              </div>
            </div>
            <span className="num text-[8px] text-taupe">01:12 / 02:04</span>
          </div>
        </main>

        {/* 右栏 */}
        <aside className="w-[186px] shrink-0 border-l border-ink/10 bg-paper-2 px-4 py-4">
          <div className="label text-[7.5px] text-taupe">词根图谱</div>
          <div className="mt-2 border border-ink/12 bg-white/55 p-2.5">
            <div className="text-[15px] tracking-[-0.01em]" style={{ fontFamily: "Fraunces, serif" }}>
              spect-
            </div>
            <div className="mt-1 text-[8.5px] text-taupe">
              拉丁语 <span className="italic">specere</span> — to look
            </div>
            <div className="mt-2 space-y-[3px]">
              {["inspect", "perspective", "spectator", "introspect"].map((w) => (
                <div key={w} className="flex items-center justify-between">
                  <span className="num text-[8.5px] text-ink/80">{w}</span>
                  <span className="h-[3px] w-[3px] rounded-full bg-vermilion" />
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <svg viewBox="0 0 44 44" className="h-[52px] w-[52px] -rotate-90">
              <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(23,24,27,0.12)" strokeWidth="5" />
              <circle
                cx="22"
                cy="22"
                r="18"
                fill="none"
                stroke="#c8452c"
                strokeWidth="5"
                strokeLinecap="round"
                strokeDasharray="113"
                strokeDashoffset="43"
              />
            </svg>
            <div>
              <div className="num text-[15px] leading-none">62%</div>
              <div className="mt-1 text-[8px] text-taupe">今日精读进度</div>
            </div>
          </div>

          <div className="mt-4 space-y-2 border-t border-ink/10 pt-3">
            {[
              ["待复习词卡", "24"],
              ["已掌握搭配", "318"],
              ["连续学习", "23 天"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between">
                <span className="text-[8.5px] text-taupe">{k}</span>
                <span className="num text-[10px]">{v}</span>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

function MobileScreen() {
  return (
    <div className="flex h-[560px] w-[268px] flex-col overflow-hidden bg-paper">
      {/* 状态栏 */}
      <div className="flex h-[30px] shrink-0 items-center justify-between px-5 pt-1">
        <span className="num text-[9px] font-semibold">9:41</span>
        <div className="flex items-center gap-[3px]">
          {[3, 5, 7, 9].map((h) => (
            <span key={h} className="w-[2.5px] rounded-full bg-ink" style={{ height: h }} />
          ))}
          <span className="ml-1 h-[8px] w-[15px] rounded-[2px] border border-ink/60">
            <span className="block h-full w-[70%] bg-ink" />
          </span>
        </div>
      </div>

      {/* 头部 */}
      <div className="flex items-end justify-between px-5 pb-3 pt-2">
        <div>
          <div className="label text-[7px] text-taupe">Today</div>
          <div className="hans text-[15px] font-bold leading-tight">2 月 11 日 · 周三</div>
        </div>
        <div className="flex items-center gap-1 border border-vermilion/35 bg-vermilion/8 px-2 py-1">
          <span className="h-[4px] w-[4px] rounded-full bg-vermilion" />
          <span className="num text-[8px] text-vermilion">连续 23 天</span>
        </div>
      </div>

      {/* 影子跟读卡 */}
      <div className="mx-4 border border-ink/12 bg-white/60 p-3">
        <div className="flex items-center justify-between">
          <div className="label text-[6.5px] text-vermilion">Shadowing</div>
          <div className="num text-[7px] text-taupe">Unit 12</div>
        </div>
        <div className="mt-1 text-[11px] font-semibold">连读与弱读 · /wɪð ə/</div>
        <div className="mt-2 flex items-center gap-2.5">
          <div className="flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-full bg-vermilion">
            <Play className="h-[8px] w-[8px] fill-white text-white" />
          </div>
          <Waveform bars={30} className="h-[26px] flex-1" />
        </div>
        <div className="mt-2 flex items-center justify-between border-t border-ink/8 pt-2">
          <span className="num text-[7.5px] text-taupe">跟读 12 / 20 句</span>
          <span className="num text-[8px]">
            发音评分 <span className="text-vermilion">86</span>
          </span>
        </div>
      </div>

      {/* 词卡 */}
      <div className="mx-4 mt-3 border border-ink/12 bg-white/60 p-3">
        <div className="flex items-baseline gap-1.5">
          <span className="text-[17px] tracking-[-0.01em]" style={{ fontFamily: "Fraunces, serif" }}>
            hedge
          </span>
          <span className="num text-[8px] text-taupe">/hedʒ/</span>
          <span className="ml-auto text-[8px] italic text-vermilion">v.</span>
        </div>
        <div className="hans mt-1 text-[10px] leading-relaxed text-ink/78">
          （用模棱两可的话）回避、留余地 —— 学术写作中常用于弱化断言。
        </div>
        <div className="mt-2 border-l-2 border-vermilion pl-2 text-[8.5px] italic leading-relaxed text-ink/62">
          The authors hedge their claim, admitting the sample was small.
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button className="hans border border-ink/15 py-[6px] text-[9px] text-taupe">模糊</button>
          <button className="hans bg-ink py-[6px] text-[9px] text-paper">掌握</button>
        </div>
      </div>

      {/* 进度条 */}
      <div className="mx-4 mt-3">
        <div className="flex items-center justify-between">
          <span className="text-[8.5px] text-taupe">今日精读 · 海洋酸化</span>
          <span className="num text-[8.5px]">62%</span>
        </div>
        <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-ink/10">
          <div className="h-full w-[62%] bg-vermilion" />
        </div>
      </div>

      {/* 底部标签栏 */}
      <div className="mt-auto flex h-[54px] items-start justify-around border-t border-ink/10 bg-paper-2 px-2 pt-2">
        {PHONE_TABS.map((tab) => (
          <div key={tab.label} className="flex flex-1 flex-col items-center gap-[3px]">
            <tab.icon className={`h-[13px] w-[13px] ${tab.active ? "text-vermilion" : "text-taupe"}`} />
            <span className={`text-[7.5px] ${tab.active ? "text-vermilion" : "text-taupe"}`}>
              {tab.label}
            </span>
          </div>
        ))}
      </div>
      <div className="mx-auto mb-2 h-[3px] w-[86px] rounded-full bg-ink/22" />
    </div>
  );
}

function Frame({
  device,
  active,
  onSelect,
}: {
  device: Device;
  active: boolean;
  onSelect: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onSelect}
      aria-label={device === "desktop" ? "查看电脑端界面" : "查看手机端界面"}
      className="block cursor-pointer"
      animate={{
        opacity: active ? 1 : 0.22,
        scale: active ? 1 : 0.88,
        x: active ? 0 : device === "desktop" ? -70 : 70,
        filter: active ? "blur(0px)" : "blur(1.2px)",
      }}
      transition={{ type: "spring", stiffness: 120, damping: 22, mass: 0.9 }}
      style={{ zIndex: active ? 20 : 10 }}
    >
      {device === "desktop" ? (
        <div>
          <div className="rounded-[13px] border border-white/10 bg-ink p-[9px] shadow-[0_36px_70px_-24px_rgba(23,24,27,0.55)]">
            <div className="overflow-hidden rounded-[4px]">
              <DesktopScreen />
            </div>
          </div>
          <div className="mx-auto h-[11px] w-[840px] rounded-b-[12px] bg-gradient-to-b from-[#33363c] to-[#22242a]">
            <div className="mx-auto h-[4px] w-[110px] rounded-b-[6px] bg-[#1b1d21]" />
          </div>
        </div>
      ) : (
        <div>
          <div className="relative rounded-[36px] border border-white/12 bg-ink p-[9px] shadow-[0_36px_70px_-24px_rgba(23,24,27,0.55)]">
            <div className="overflow-hidden rounded-[28px]">
              <MobileScreen />
            </div>
            <div className="absolute left-1/2 top-[18px] h-[20px] w-[82px] -translate-x-1/2 rounded-full bg-ink" />
            <div className="absolute -right-[3px] top-[130px] h-[52px] w-[3px] rounded-r bg-[#3a3d43]" />
          </div>
        </div>
      )}
    </motion.button>
  );
}

export function DeviceShowcase() {
  const [device, setDevice] = useState<Device>("desktop");

  return (
    <div className="w-full">
      <div className="relative h-[360px] sm:h-[460px] lg:h-[560px]">
        {/* 电脑端 */}
        <div
          className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 scale-[0.32] sm:scale-[0.58] lg:scale-[0.72] xl:scale-[0.86] ${
            device === "mobile" ? "hidden lg:block" : "block"
          }`}
        >
          <Frame device="desktop" active={device === "desktop"} onSelect={() => setDevice("desktop")} />
        </div>

        {/* 手机端 */}
        <div
          className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 scale-[0.52] sm:scale-[0.72] lg:scale-[0.78] xl:scale-[0.92] ${
            device === "desktop" ? "hidden lg:block" : "block"
          }`}
        >
          <Frame device="mobile" active={device === "mobile"} onSelect={() => setDevice("mobile")} />
        </div>
      </div>

      {/* 切换器 */}
      <div className="mx-auto mt-4 flex w-full max-w-[520px] items-stretch border border-ink/14 bg-white/45">
        {(["desktop", "mobile"] as Device[]).map((d) => {
          const on = device === d;
          return (
            <button
              key={d}
              onClick={() => setDevice(d)}
              className="relative flex-1 px-5 py-3 text-left transition-colors"
            >
              {on && (
                <motion.span
                  layoutId="device-pill"
                  className="absolute inset-0 bg-ink"
                  transition={{ type: "spring", stiffness: 260, damping: 28 }}
                />
              )}
              <span className="relative z-10 block">
                <span
                  className={`label block text-[8px] ${on ? "text-vermilion" : "text-taupe"}`}
                >
                  {d === "desktop" ? "Desktop" : "Mobile"}
                </span>
                <span
                  className={`hans mt-1 block text-[15px] font-semibold ${
                    on ? "text-paper" : "text-ink/70"
                  }`}
                >
                  {d === "desktop" ? "电脑端 · 深度精读" : "手机端 · 随身跟读"}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      <p className="hans mt-3 text-center text-[12px] text-taupe">
        点击切换设备 —— 同一个账号、同一份词库，界面随屏幕重新排布，学习进度实时同步。
      </p>
    </div>
  );
}
