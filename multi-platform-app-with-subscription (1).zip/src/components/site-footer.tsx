import { VerbaMark } from "@/components/marks";

const COLUMNS = [
  {
    title: "产品",
    items: ["电脑端 · macOS / Windows", "手机端 · iOS / Android", "课程体系", "词根词源图谱", "版本更新日志"],
  },
  {
    title: "学习",
    items: ["精读库（312 篇）", "影子跟读训练", "学术写作工坊", "间隔复习计划", "教师后台"],
  },
  {
    title: "支持",
    items: ["帮助中心", "退款与发票", "edu 学生认证", "院校合作", "联系我们"],
  },
];

export function SiteFooter() {
  return (
    <footer className="ink-band mt-24 px-5 pb-10 pt-16 sm:px-8">
      <div className="mx-auto max-w-[1400px]">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div>
            <div className="flex items-center gap-3">
              <VerbaMark className="h-10 w-10" />
              <div>
                <div className="hans text-[19px] font-bold text-paper">语脉 VERBA</div>
                <div className="label text-[9px] text-paper/60">Advanced English, engineered</div>
              </div>
            </div>
            <p className="hans mt-6 max-w-sm text-[13.5px] leading-[1.9] text-paper/60">
              一套面向高阶学习者的英语训练系统。电脑端负责深度与输出，手机端负责频率与固着，
              两块屏幕共享同一份词库、同一个进度。
            </p>
            <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2">
              <a href="#pricing" className="hans text-[13px] text-paper/80 hover:text-vermilion">
                价格与试用
              </a>
              <a href="#download" className="hans text-[13px] text-paper/80 hover:text-vermilion">
                下载客户端
              </a>
              <a
                href="mailto:hi@verba.study"
                className="num text-[12px] text-paper/80 hover:text-vermilion"
              >
                hi@verba.study
              </a>
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <div className="label text-[10px] text-vermilion">{col.title}</div>
              <ul className="mt-5 space-y-3">
                {col.items.map((item) => (
                  <li key={item}>
                    <a href="#top" className="hans text-[13px] text-paper/62 transition-colors hover:text-paper">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-paper/15 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="num text-[11px] text-paper/58">
            © 2026 语脉 VERBA · 版本 3.4.1 · 构建 20260211
          </p>
          <p className="hans text-[11px] text-paper/58">
            试用期内全部功能开放 · 到期不自动扣款 · 随时可取消
          </p>
        </div>
      </div>
    </footer>
  );
}
