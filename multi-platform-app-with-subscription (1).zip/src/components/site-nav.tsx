"use client";

import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { VerbaMark } from "@/components/marks";
import { useAccount } from "@/lib/use-account";

const LINKS = [
  { href: "#curriculum", label: "课程体系" },
  { href: "#method", label: "学习方法" },
  { href: "#features", label: "双端功能" },
  { href: "#pricing", label: "价格与试用" },
  { href: "#download", label: "软件下载" },
  { href: "#faq", label: "常见问题" },
];

export function SiteNav() {
  const { access, refresh } = useAccount();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const status =
    access.tier === "pro"
      ? { text: access.planName ?? "会员有效", dot: "bg-moss", cls: "text-moss" }
      : access.tier === "trial"
        ? { text: `试用剩余 ${access.daysLeft} 天`, dot: "bg-vermilion", cls: "text-vermilion" }
        : { text: "试用已结束", dot: "bg-taupe", cls: "text-taupe" };

  return (
    <header
      className={`sticky top-0 z-50 transition-colors duration-300 ${
        scrolled ? "bg-paper/92 backdrop-blur-md" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-6 px-5 sm:px-8">
        <a href="#top" className="flex items-center gap-2.5">
          <VerbaMark className="h-8 w-8" />
          <span className="leading-none">
            <span className="hans block text-[17px] font-bold tracking-[0.06em]">语脉</span>
            <span className="label block text-[9px] text-taupe">Verba</span>
          </span>
        </a>

        <nav className="ml-4 hidden items-center gap-7 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="hans text-[13.5px] text-ink/75 transition-colors hover:text-vermilion"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <button
            onClick={() => void refresh()}
            className="hidden items-center gap-2 border border-ink/12 bg-white/45 px-3 py-1.5 transition-colors hover:border-ink/25 sm:flex"
            title="点击刷新账户状态"
          >
            <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
            <span className={`num text-[11px] font-medium ${status.cls}`}>{status.text}</span>
          </button>
          <a
            href="#pricing"
            className="hans hidden bg-ink px-5 py-2.5 text-[13px] text-paper transition-colors hover:bg-vermilion sm:block"
          >
            开始 7 天免费试用
          </a>
          <button
            aria-label="打开菜单"
            className="lg:hidden"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-y border-ink/12 bg-paper px-5 py-4 lg:hidden">
          <ul className="space-y-3">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="hans block text-[15px] text-ink/85"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex items-center gap-2 border border-ink/12 px-3 py-2">
            <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
            <span className="num text-[11px]">{status.text}</span>
          </div>
        </div>
      )}
    </header>
  );
}
