"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Loader2, Lock, ShieldCheck, X } from "lucide-react";
import { useAccount } from "@/lib/use-account";

const PLANS = [
  {
    code: "trial",
    name: "全功能试用",
    en: "Trial",
    price: "¥0",
    unit: "7 天",
    note: "不绑定支付方式",
    summary: "全部课程、双端客户端、AI 批改额度一次性开放。",
  },
  {
    code: "monthly",
    name: "月度会员",
    en: "Monthly",
    price: "¥68",
    unit: "/ 月",
    note: "随时取消",
    summary: "适合雅思、托福、面试冲刺期，按月灵活付费。",
  },
  {
    code: "yearly",
    name: "年度会员",
    en: "Yearly",
    price: "¥588",
    unit: "/ 年",
    note: "折合 ¥49 / 月 · 省 28%",
    summary: "含两次一对一写作精批，赠送词根词源图谱实体手册。",
  },
  {
    code: "team",
    name: "院校 / 团队",
    en: "Campus",
    price: "¥520",
    unit: "/ 席 / 年",
    note: "5 席起购",
    summary: "教师后台、班级词库、学习报告导出与统一开票。",
  },
] as const;

const MATRIX: { label: string; cells: string[] }[] = [
  { label: "精读库 312 篇（三层注解）", cells: ["✓", "✓", "✓", "✓"] },
  { label: "影子跟读 + 发音评分", cells: ["✓", "✓", "✓", "✓"] },
  { label: "词根词源图谱 · 4,612 条", cells: ["✓", "✓", "✓", "✓"] },
  { label: "AI 学术写作批改", cells: ["3 篇", "10 篇 / 月", "不限 + 2 次人工精批", "不限"] },
  { label: "间隔复习 SRS 词库", cells: ["500 词", "不限", "不限", "不限"] },
  { label: "双端同步（电脑 + 手机）", cells: ["✓", "✓", "✓", "✓"] },
  { label: "离线下载精读文本", cells: ["—", "30 篇", "不限", "不限"] },
  { label: "教师后台与班级报告", cells: ["—", "—", "—", "✓"] },
];

const METHODS = [
  { code: "wechat", label: "微信支付", hint: "推荐 · 免密续费", color: "#2f6b52" },
  { code: "alipay", label: "支付宝", hint: "支持花呗分期", color: "#2b6cb0" },
  { code: "card", label: "Visa / Mastercard", hint: "境外卡 · 3D Secure", color: "#17181b" },
];

function money(cents: number) {
  return `¥${(cents / 100).toFixed(2)}`;
}

function dateLabel(iso: string | null) {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(iso));
}

export function Pricing() {
  const { access, orders, activity, refresh } = useAccount();
  const [open, setOpen] = useState(false);
  const [plan, setPlan] = useState<"monthly" | "yearly" | "team">("yearly");
  const [method, setMethod] = useState("wechat");
  const [busy, setBusy] = useState(false);
  const [receipt, setReceipt] = useState<{
    invoiceNo: string;
    amountCents: number;
    periodEnd: string;
    message: string;
  } | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const trialProgress = useMemo(() => {
    const start = new Date(access.trialStartedAt).getTime();
    const end = new Date(access.trialEndsAt).getTime();
    const pct = ((Date.now() - start) / Math.max(1, end - start)) * 100;
    return Math.max(2, Math.min(100, pct));
  }, [access.trialStartedAt, access.trialEndsAt]);

  async function act(body: Record<string, unknown>, message?: string) {
    setBusy(true);
    try {
      const res = await fetch("/api/billing", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (data?.receipt) setReceipt(data.receipt);
      setToast(data?.message ?? message ?? "已完成");
      await refresh();
    } catch {
      setToast("网络异常，请稍后重试");
    } finally {
      setBusy(false);
    }
  }

  function openPaywall(target: (typeof PLANS)[number]["code"] = "yearly") {
    if (target !== "trial") setPlan(target as "monthly" | "yearly" | "team");
    setReceipt(null);
    setOpen(true);
  }

  return (
    <section id="pricing" className="relative scroll-mt-20 px-5 py-24 sm:px-8">
      <div className="mx-auto max-w-[1400px]">
        {/* 标题 */}
        <div className="grid gap-10 lg:grid-cols-[1fr_1.15fr]">
          <div>
            <div className="label text-vermilion">Pricing · 7-day trial</div>
            <h2 className="hans mt-5 text-[clamp(2.4rem,5.4vw,4.2rem)] font-bold leading-[1.08] tracking-[-0.02em]">
              先用 7 天，
              <br />
              再决定要不要
              <span className="text-vermilion">付费</span>。
            </h2>
            <p className="hans measure mt-6 text-[15px] leading-[2] text-ink/72">
              注册即开启 <strong className="font-semibold">168 小时</strong>全功能试用，不需要绑定支付方式。
              到期前 24 小时我们会提醒你；试用结束后<strong className="font-semibold">不会自动扣款</strong>
              —— 你需要主动选择一个计划。所有已学内容、词卡与跟读录音都会保留。
            </p>

            {/* 试用状态板 */}
            <div className="mt-8 border border-ink/14 bg-white/52">
              <div className="flex items-center justify-between border-b border-ink/10 px-6 py-3">
                <div className="label text-[9px] text-taupe">My account · 我的账户</div>
                <div className="flex items-center gap-2">
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      access.tier === "pro" ? "bg-moss" : access.tier === "trial" ? "bg-vermilion" : "bg-taupe"
                    }`}
                  />
                  <span className="num text-[11px]">{access.label}</span>
                </div>
              </div>

              <div className="flex items-end gap-6 px-6 py-6">
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="num text-[64px] leading-none tracking-[-0.04em]">
                      {access.tier === "pro" ? "∞" : access.daysLeft}
                    </span>
                    <span className="hans text-[13px] text-taupe">
                      {access.tier === "pro" ? "会员有效" : "天后结束"}
                    </span>
                  </div>
                  <div className="num mt-2 text-[11px] text-taupe">
                    试用自 {dateLabel(access.trialStartedAt)} 起 · 至 {dateLabel(access.trialEndsAt)}
                  </div>
                </div>
                <div className="ml-auto text-right">
                  <div className="num text-[11px] text-taupe">已解锁课时</div>
                  <div className="num mt-1 text-[22px]">
                    {access.lessonsUnlocked}
                    <span className="text-[13px] text-taupe"> / {access.lessonsTotal}</span>
                  </div>
                </div>
              </div>

              <div className="px-6">
                <div className="h-[5px] w-full overflow-hidden rounded-full bg-ink/10">
                  <motion.div
                    className={`h-full ${access.tier === "pro" ? "bg-moss" : "bg-vermilion"}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${access.tier === "pro" ? 100 : trialProgress}%` }}
                    transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                  />
                </div>
              </div>

              <div className="mt-5 grid grid-cols-1 gap-px border-t border-ink/10 bg-ink/10 sm:grid-cols-2">
                <div className="bg-white/45 px-6 py-4">
                  <div className="label text-[8px] text-taupe">当前计划</div>
                  <div className="hans mt-1.5 text-[14px]">
                    {access.planName ?? "尚未订阅 · 试用版"}
                  </div>
                  <div className="num mt-1 text-[10.5px] text-taupe">
                    {access.periodEnd
                      ? `下次续费 ${dateLabel(access.periodEnd)} · ${money(access.nextBillingCents ?? 0)}`
                      : access.autoRenew === false
                        ? "无自动续费"
                        : "到期后不自动扣款"}
                  </div>
                </div>
                <div className="bg-white/45 px-6 py-4">
                  <div className="label text-[8px] text-taupe">双端活动记录</div>
                  <ul className="mt-1.5 space-y-1">
                    {(activity.length ? activity : [{ lessonSlug: "hedges-01", device: "desktop", seconds: 420, updatedAt: new Date().toISOString() }]).slice(0, 2).map((a, i) => (
                      <li key={i} className="num flex items-center gap-2 text-[10.5px] text-ink/72">
                        <span
                          className={`px-1.5 py-[1px] text-[8px] uppercase ${
                            a.device === "mobile" ? "bg-vermilion/12 text-vermilion" : "bg-ink/8 text-taupe"
                          }`}
                        >
                          {a.device === "mobile" ? "iOS" : "macOS"}
                        </span>
                        {a.lessonSlug} · {Math.round(a.seconds / 60)} 分钟
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* 演示控制 */}
            <div className="mt-4 flex flex-wrap items-center gap-2 border border-dashed border-ink/22 px-4 py-3">
              <span className="label text-[8px] text-taupe">Demo controls</span>
              <button
                disabled={busy}
                onClick={() => void act({ action: "simulate-expiry" })}
                className="hans border border-ink/15 px-3 py-1.5 text-[11.5px] transition-colors hover:border-vermilion hover:text-vermilion disabled:opacity-50"
              >
                模拟试用到期
              </button>
              <button
                disabled={busy}
                onClick={() => void act({ action: "reset-trial" })}
                className="hans border border-ink/15 px-3 py-1.5 text-[11.5px] transition-colors hover:border-vermilion hover:text-vermilion disabled:opacity-50"
              >
                重置为 7 天
              </button>
              <button
                disabled={busy}
                onClick={() => void act({ action: "cancel" })}
                className="hans border border-ink/15 px-3 py-1.5 text-[11.5px] transition-colors hover:border-vermilion hover:text-vermilion disabled:opacity-50"
              >
                关闭自动续费
              </button>
            </div>
          </div>

          {/* 价目账簿 */}
          <div>
            <div className="flex items-end justify-between border-b-2 border-ink pb-2">
              <div className="label text-[9px] text-taupe">Tariff · 价目表</div>
              <div className="label text-[9px] text-taupe">CNY · 含税</div>
            </div>

            {PLANS.map((p, i) => {
              const highlight = p.code === "yearly";
              return (
                <div
                  key={p.code}
                  className={`group relative border-b border-ink/12 transition-colors ${
                    highlight ? "bg-vermilion text-paper" : "hover:bg-white/50"
                  }`}
                >
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-3 px-5 py-6">
                    <div className="min-w-[150px]">
                      <div className="flex items-center gap-2">
                        <span className="num text-[10px] opacity-70">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <h3 className="hans text-[19px] font-semibold">{p.name}</h3>
                      </div>
                      <div className={`label mt-1 text-[8px] ${highlight ? "text-paper/70" : "text-taupe"}`}>
                        {p.en}
                      </div>
                    </div>

                    <div className="flex-1">
                      <p className={`hans text-[12.5px] leading-relaxed ${highlight ? "text-paper/85" : "text-ink/62"}`}>
                        {p.summary}
                      </p>
                      <div className={`num mt-1 text-[10px] ${highlight ? "text-paper/70" : "text-taupe"}`}>
                        {p.note}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="num text-[30px] leading-none tracking-[-0.03em]">{p.price}</div>
                      <div className={`num mt-1 text-[10px] ${highlight ? "text-paper/70" : "text-taupe"}`}>
                        {p.unit}
                      </div>
                    </div>

                    <button
                      disabled={busy}
                      onClick={() =>
                        p.code === "trial"
                          ? void act({ action: "reset-trial" })
                          : openPaywall(p.code as "monthly" | "yearly" | "team")
                      }
                      className={`hans min-w-[118px] px-4 py-2.5 text-[12.5px] transition-colors disabled:opacity-60 ${
                        highlight
                          ? "bg-paper text-vermilion hover:bg-white"
                          : "border border-ink/22 hover:border-ink hover:bg-ink hover:text-paper"
                      }`}
                    >
                      {p.code === "trial" ? "立即试用" : "选择此计划"}
                    </button>
                  </div>
                  {highlight && (
                    <div className="label absolute right-5 top-0 bg-ink px-2 py-[3px] text-[7px] text-paper">
                      Recommended
                    </div>
                  )}
                </div>
              );
            })}

            {/* 对照表 */}
            <div className="mt-10 overflow-x-auto scrollbar-none">
              <table className="w-full min-w-[560px] border-collapse">
                <thead>
                  <tr className="border-b-2 border-ink">
                    <th className="label py-2 text-left text-[8.5px] text-taupe">功能对照</th>
                    {PLANS.map((p) => (
                      <th key={p.code} className="label px-2 py-2 text-right text-[8.5px] text-taupe">
                        {p.en}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {MATRIX.map((row) => (
                    <tr key={row.label} className="border-b border-ink/10">
                      <td className="hans py-3 pr-4 text-[12.5px] text-ink/78">{row.label}</td>
                      {row.cells.map((c, i) => (
                        <td
                          key={i}
                          className={`num px-2 py-3 text-right text-[11px] ${
                            c === "—" ? "text-taupe/60" : c === "✓" ? "text-moss" : "text-ink/80"
                          }`}
                        >
                          {c === "✓" ? <Check className="ml-auto h-3.5 w-3.5" /> : c}
                        </td>
                      ))}
                    </tr>
                  ))}
                  <tr className="border-b-2 border-ink">
                    <td className="label py-4 text-[9px] text-taupe">价格</td>
                    {PLANS.map((p) => (
                      <td key={p.code} className="num px-2 py-4 text-right text-[13px]">
                        {p.price}
                        <span className="text-[9px] text-taupe"> {p.unit}</span>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {[
                { t: "到期不自动扣款", d: "试用结束只是停止学习功能，不会产生任何扣费。" },
                { t: "7 天内无理由退款", d: "订阅后 7 天内申请，全额退回原支付渠道。" },
                { t: "一个订阅覆盖双端", d: "macOS / Windows / iOS / Android 全平台通用。" },
              ].map((f) => (
                <div key={f.t} className="flex gap-3">
                  <ShieldCheck className="mt-[3px] h-4 w-4 shrink-0 text-moss" />
                  <div>
                    <div className="hans text-[12.5px] font-semibold">{f.t}</div>
                    <div className="hans mt-1 text-[11px] leading-relaxed text-taupe">{f.d}</div>
                  </div>
                </div>
              ))}
            </div>

            {orders.length > 0 && (
              <div className="mt-8 border border-ink/12 bg-white/45">
                <div className="label border-b border-ink/10 px-5 py-2.5 text-[8px] text-taupe">
                  Invoices · 订单记录
                </div>
                <ul>
                  {orders.map((o) => (
                    <li key={o.invoiceNo} className="flex items-center justify-between px-5 py-3">
                      <span className="num text-[11px]">{o.invoiceNo}</span>
                      <span className="hans text-[11px] text-taupe">
                        {o.method === "wechat" ? "微信支付" : o.method === "alipay" ? "支付宝" : "银行卡"}
                      </span>
                      <span className="num text-[12px]">{money(o.amountCents)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 付费墙 */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[70] flex items-end justify-center bg-ink/55 p-0 backdrop-blur-sm sm:items-center sm:p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
          >
            <motion.div
              className="relative max-h-[92vh] w-full max-w-[560px] overflow-y-auto bg-paper p-7 shadow-2xl sm:p-9"
              initial={{ y: 28, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ type: "spring", stiffness: 180, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                aria-label="关闭"
                onClick={() => setOpen(false)}
                className="absolute right-5 top-5 text-taupe hover:text-ink"
              >
                <X className="h-5 w-5" />
              </button>

              {receipt ? (
                <div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-moss">
                    <Check className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="hans mt-5 text-[26px] font-bold">支付成功，全部课程已解锁</h3>
                  <p className="hans mt-3 text-[13.5px] leading-[1.95] text-ink/72">{receipt.message}</p>
                  <dl className="mt-6 border border-ink/12">
                    {[
                      ["订单号", receipt.invoiceNo],
                      ["实付金额", money(receipt.amountCents)],
                      ["有效期至", dateLabel(receipt.periodEnd)],
                      ["覆盖平台", "macOS / Windows / iOS / Android"],
                    ].map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between border-b border-ink/10 px-5 py-3 last:border-0">
                        <dt className="hans text-[12px] text-taupe">{k}</dt>
                        <dd className="num text-[12.5px]">{v}</dd>
                      </div>
                    ))}
                  </dl>
                  <button
                    onClick={() => setOpen(false)}
                    className="hans mt-6 w-full bg-ink py-3.5 text-[14px] text-paper transition-colors hover:bg-vermilion"
                  >
                    继续学习
                  </button>
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-vermilion" />
                    <span className="label text-[9px] text-vermilion">Unlock · 解锁</span>
                  </div>
                  <h3 className="hans mt-4 text-[27px] font-bold leading-tight">
                    {access.tier === "locked" ? "试用已结束" : "升级为正式会员"}
                  </h3>
                  <p className="hans mt-3 text-[13.5px] leading-[1.95] text-ink/72">
                    选择一个计划，立即恢复全部 56 课时、AI 写作批改与双端同步。
                    你已学习的内容、词卡与跟读录音都已保留。
                  </p>

                  <div className="mt-6 space-y-2">
                    {PLANS.filter((p) => p.code !== "trial").map((p) => {
                      const on = plan === p.code;
                      return (
                        <button
                          key={p.code}
                          onClick={() => setPlan(p.code as "monthly" | "yearly" | "team")}
                          className={`flex w-full items-center gap-4 border px-5 py-4 text-left transition-colors ${
                            on ? "border-ink bg-ink text-paper" : "border-ink/15 hover:border-ink/40"
                          }`}
                        >
                          <span
                            className={`h-3 w-3 rounded-full border ${
                              on ? "border-vermilion bg-vermilion" : "border-ink/35"
                            }`}
                          />
                          <span className="hans flex-1 text-[15px] font-semibold">{p.name}</span>
                          <span className="num text-[19px]">{p.price}</span>
                          <span className={`num text-[10px] ${on ? "text-paper/65" : "text-taupe"}`}>
                            {p.unit}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-6">
                    <div className="label text-[8px] text-taupe">支付方式</div>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                      {METHODS.map((m) => (
                        <button
                          key={m.code}
                          onClick={() => setMethod(m.code)}
                          className={`border px-3 py-3 text-left transition-colors ${
                            method === m.code ? "border-vermilion bg-vermilion/8" : "border-ink/15"
                          }`}
                        >
                          <span className="flex items-center gap-1.5">
                            <span className="h-2 w-2 rounded-full" style={{ background: m.color }} />
                            <span className="hans text-[11.5px] font-medium">{m.label}</span>
                          </span>
                          <span className="mt-1 block text-[9px] text-taupe">{m.hint}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    disabled={busy}
                    onClick={() => void act({ action: "subscribe", planCode: plan, method })}
                    className="hans mt-7 flex w-full items-center justify-center gap-2 bg-vermilion py-4 text-[15px] font-semibold text-paper transition-colors hover:bg-vermilion-2 disabled:opacity-60"
                  >
                    {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                    确认支付并解锁
                  </button>
                  <p className="hans mt-3 text-[11px] leading-relaxed text-taupe">
                    点击即表示同意《语脉服务条款》与《自动续费规则》。可随时在账户中关闭自动续费；
                    订阅后 7 天内可申请全额退款。
                  </p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 轻提示 */}
      <AnimatePresence>
        {toast && (
          <motion.div
            className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 border border-ink/15 bg-ink px-5 py-3 text-paper shadow-xl"
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 12, opacity: 0 }}
            onAnimationComplete={() => window.setTimeout(() => setToast(null), 2600)}
          >
            <span className="hans text-[12.5px]">{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
