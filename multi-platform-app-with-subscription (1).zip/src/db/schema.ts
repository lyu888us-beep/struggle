import {
  integer,
  pgTable,
  text,
  timestamp,
  varchar,
  boolean,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ── 用户：以浏览器设备标识（cookie）为锚点，注册后即开启 168 小时试用 ──
export const users = pgTable(
  "users",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    deviceKey: varchar("device_key", { length: 64 }).notNull(),
    email: varchar("email", { length: 191 }),
    displayName: varchar("display_name", { length: 80 }),
    platform: varchar("platform", { length: 16 }).notNull().default("web"),
    trialStartedAt: timestamp("trial_started_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_device_key_uq").on(t.deviceKey)]
);

// ── 计划：价目账簿的真数据 ──
export const plans = pgTable("plans", {
  code: varchar("code", { length: 24 }).primaryKey(),
  name: varchar("name", { length: 60 }).notNull(),
  nameEn: varchar("name_en", { length: 60 }).notNull(),
  priceCents: integer("price_cents").notNull(),
  originalPriceCents: integer("original_price_cents"),
  interval: varchar("interval", { length: 8 }).notNull(), // month | year | seat
  intervalCount: integer("interval_count").notNull().default(1),
  seats: integer("seats").notNull().default(1),
  highlight: boolean("highlight").notNull().default(false),
  summary: text("summary").notNull().default(""),
});

// ── 订阅 ──
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userId: varchar("user_id", { length: 36 }).notNull(),
    planCode: varchar("plan_code", { length: 24 }).notNull(),
    status: varchar("status", { length: 12 }).notNull(), // active | canceled | expired
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }).notNull(),
    canceledAt: timestamp("canceled_at", { withTimezone: true }),
    autoRenew: boolean("auto_renew").notNull().default(true),
  },
  (t) => [index("subs_user_idx").on(t.userId)]
);

// ── 订单 ──
export const orders = pgTable(
  "orders",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userId: varchar("user_id", { length: 36 }).notNull(),
    planCode: varchar("plan_code", { length: 24 }).notNull(),
    amountCents: integer("amount_cents").notNull(),
    currency: varchar("currency", { length: 8 }).notNull().default("CNY"),
    method: varchar("method", { length: 16 }).notNull(), // wechat | alipay | card
    status: varchar("status", { length: 12 }).notNull().default("paid"), // paid | refunded
    invoiceNo: varchar("invoice_no", { length: 24 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("orders_user_idx").on(t.userId)]
);

// ── 学习进度（双端同步的真数据） ──
export const progress = pgTable(
  "progress",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userId: varchar("user_id", { length: 36 }).notNull(),
    lessonSlug: varchar("lesson_slug", { length: 64 }).notNull(),
    device: varchar("device", { length: 12 }).notNull().default("desktop"),
    seconds: integer("seconds").notNull().default(0),
    score: integer("score"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("progress_user_lesson_uq").on(t.userId, t.lessonSlug)]
);

export type User = typeof users.$inferSelect;
export type Plan = typeof plans.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;
export type Order = typeof orders.$inferSelect;
