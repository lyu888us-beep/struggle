import { randomUUID } from "node:crypto";
import { and, desc, eq, gt } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { orders, plans, progress, subscriptions, users, type Plan } from "@/db/schema";

export const TRIAL_DAYS = 7;
export const DEVICE_COOKIE = "verba_device";

export const PLAN_CATALOG: Plan[] = [
  {
    code: "trial",
    name: "全功能试用",
    nameEn: "Trial",
    priceCents: 0,
    originalPriceCents: null,
    interval: "day",
    intervalCount: 7,
    seats: 1,
    highlight: false,
    summary: "7 天内解锁全部课程与双端客户端，不需绑定支付方式。",
  },
  {
    code: "monthly",
    name: "月度会员",
    nameEn: "Monthly",
    priceCents: 6800,
    originalPriceCents: null,
    interval: "month",
    intervalCount: 1,
    seats: 1,
    highlight: false,
    summary: "按月付费，随时取消，适合雅思、托福冲刺期。",
  },
  {
    code: "yearly",
    name: "年度会员",
    nameEn: "Yearly",
    priceCents: 58800,
    originalPriceCents: 81600,
    interval: "year",
    intervalCount: 1,
    seats: 1,
    highlight: true,
    summary: "折合 ¥49 / 月，较月度省 28%，含两次一对一写作精批。",
  },
  {
    code: "team",
    name: "院校 / 团队",
    nameEn: "Campus",
    priceCents: 52000,
    originalPriceCents: null,
    interval: "seat-year",
    intervalCount: 1,
    seats: 5,
    highlight: false,
    summary: "5 席起购，含教师后台、班级词库与学习报告导出。",
  },
];

export function planByCode(code: string): Plan {
  return PLAN_CATALOG.find((p) => p.code === code) ?? PLAN_CATALOG[1];
}

export type AccessState = {
  tier: "trial" | "pro" | "locked";
  label: string;
  daysLeft: number;
  trialEndsAt: string;
  trialStartedAt: string;
  planCode: string | null;
  planName: string | null;
  periodEnd: string | null;
  autoRenew: boolean;
  lessonsUnlocked: number;
  lessonsTotal: number;
  nextBillingCents: number | null;
  memberSince: string;
};

export const LESSON_TOTAL = 56;

async function deviceKey(): Promise<string> {
  const jar = await cookies();
  const existing = jar.get(DEVICE_COOKIE)?.value;
  return existing ?? "";
}

export async function ensureUser(): Promise<{
  id: string;
  deviceKey: string;
  trialEndsAt: Date;
  trialStartedAt: Date;
  isNew: boolean;
}> {
  const jar = await cookies();
  const key = jar.get(DEVICE_COOKIE)?.value ?? randomUUID().replace(/-/g, "").slice(0, 32);

  const found = await db.select().from(users).where(eq(users.deviceKey, key)).limit(1);
  if (found.length) {
    return {
      id: found[0].id,
      deviceKey: key,
      trialEndsAt: found[0].trialEndsAt,
      trialStartedAt: found[0].trialStartedAt,
      isNew: false,
    };
  }

  const now = new Date();
  const trialEndsAt = new Date(now.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
  const id = randomUUID();
  await db.insert(users).values({
    id,
    deviceKey: key,
    trialStartedAt: now,
    trialEndsAt,
  });

  // 记录一次开屏进度，让"双端同步"有真实数据可展示
  await db.insert(progress).values({
    id: randomUUID(),
    userId: id,
    lessonSlug: "hedges-01",
    device: "desktop",
    seconds: 420,
  });

  return { id, deviceKey: key, trialEndsAt, trialStartedAt: now, isNew: true };
}

export async function activeSubscription(userId: string) {
  const rows = await db
    .select()
    .from(subscriptions)
    .where(and(eq(subscriptions.userId, userId), eq(subscriptions.status, "active")))
    .orderBy(desc(subscriptions.currentPeriodEnd))
    .limit(1);
  return rows[0] ?? null;
}

export async function resolveAccess(userId: string): Promise<AccessState> {
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const sub = await activeSubscription(userId);
  const now = new Date();

  const trialEndsAt = user.trialEndsAt;
  const trialActive = now.getTime() < trialEndsAt.getTime();
  const subActive = !!sub && sub.currentPeriodEnd.getTime() > now.getTime();

  const daysLeft = Math.max(
    0,
    Math.ceil((trialEndsAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000))
  );

  const tier: AccessState["tier"] = subActive ? "pro" : trialActive ? "trial" : "locked";
  const plan = sub ? planByCode(sub.planCode) : null;

  return {
    tier,
    label: subActive ? `${plan?.name ?? "会员"} · 有效` : trialActive ? "试用中" : "试用已结束",
    daysLeft: subActive ? 0 : daysLeft,
    trialEndsAt: trialEndsAt.toISOString(),
    trialStartedAt: user.trialStartedAt.toISOString(),
    planCode: sub?.planCode ?? null,
    planName: plan?.name ?? null,
    periodEnd: sub?.currentPeriodEnd.toISOString() ?? null,
    autoRenew: sub?.autoRenew ?? false,
    lessonsUnlocked: tier === "locked" ? 3 : tier === "trial" ? LESSON_TOTAL : LESSON_TOTAL,
    lessonsTotal: LESSON_TOTAL,
    nextBillingCents: subActive && sub ? planByCode(sub.planCode).priceCents : null,
    memberSince: user.createdAt.toISOString(),
  };
}

export async function listOrders(userId: string) {
  return db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt))
    .limit(12);
}

export async function createSubscription(input: {
  userId: string;
  planCode: string;
  method: string;
}) {
  const plan = planByCode(input.planCode);
  const now = new Date();
  const end = new Date(now.getTime());
  if (plan.interval === "month") end.setMonth(end.getMonth() + 1);
  else if (plan.interval === "year") end.setFullYear(end.getFullYear() + 1);
  else end.setDate(end.getDate() + plan.intervalCount);

  const orderId = randomUUID();
  const invoiceNo = `VB-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}-${orderId
    .slice(0, 6)
    .toUpperCase()}`;

  // 价目表落库：订单引用的计划必须在 plans 中真实存在
  await db
    .insert(plans)
    .values({
      code: plan.code,
      name: plan.name,
      nameEn: plan.nameEn,
      priceCents: plan.priceCents,
      originalPriceCents: plan.originalPriceCents,
      interval: plan.interval,
      intervalCount: plan.intervalCount,
      seats: plan.seats,
      highlight: plan.highlight,
      summary: plan.summary,
    })
    .onConflictDoNothing({ target: plans.code });

  await db.insert(orders).values({
    id: orderId,
    userId: input.userId,
    planCode: plan.code,
    amountCents: plan.priceCents,
    method: input.method,
    status: "paid",
    invoiceNo,
  });

  await db.insert(subscriptions).values({
    id: randomUUID(),
    userId: input.userId,
    planCode: plan.code,
    status: "active",
    startedAt: now,
    currentPeriodEnd: end,
    autoRenew: true,
  });

  return { invoiceNo, amountCents: plan.priceCents, periodEnd: end.toISOString() };
}

export async function cancelSubscription(userId: string) {
  const sub = await activeSubscription(userId);
  if (!sub) return false;
  await db
    .update(subscriptions)
    .set({ status: "canceled", autoRenew: false, canceledAt: new Date() })
    .where(eq(subscriptions.id, sub.id));
  return true;
}

export async function endTrialNow(userId: string) {
  await db
    .update(users)
    .set({ trialEndsAt: new Date(Date.now() - 1000) })
    .where(eq(users.id, userId));
}

export async function restartTrial(userId: string) {
  const now = new Date();
  await db
    .update(users)
    .set({
      trialStartedAt: now,
      trialEndsAt: new Date(now.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000),
    })
    .where(eq(users.id, userId));
}

export async function touchProgress(userId: string, lessonSlug: string, device: string, seconds: number) {
  await db
    .insert(progress)
    .values({
      id: randomUUID(),
      userId,
      lessonSlug,
      device,
      seconds,
    })
    .onConflictDoUpdate({
      target: [progress.userId, progress.lessonSlug],
      set: { seconds, device, updatedAt: new Date() },
    });
}

export async function recentProgress(userId: string) {
  return db
    .select()
    .from(progress)
    .where(and(eq(progress.userId, userId), gt(progress.seconds, 0)))
    .orderBy(desc(progress.updatedAt))
    .limit(6);
}

export { deviceKey };
