"use client";

import { useCallback, useEffect, useState } from "react";

export type Access = {
  tier: "trial" | "pro" | "locked";
  label: string;
  daysLeft: number;
  trialEndsAt: string;
  trialStartedAt: string;
  planCode: string | null;
  planName: string | null;
  periodEnd: string | null;
  autoRenew: boolean;
  lessonsUnlocked: number;
  lessonsTotal: number;
  nextBillingCents: number | null;
  memberSince: string;
};

export type AccountPayload = {
  ok: boolean;
  access: Access;
  orders: {
    invoiceNo: string;
    amountCents: number;
    method: string;
    status: string;
    createdAt: string;
  }[];
  activity: {
    lessonSlug: string;
    device: string;
    seconds: number;
    updatedAt: string;
  }[];
};

const FALLBACK: Access = {
  tier: "trial",
  label: "试用中",
  daysLeft: 7,
  trialEndsAt: new Date(Date.now() + 7 * 864e5).toISOString(),
  trialStartedAt: new Date().toISOString(),
  planCode: null,
  planName: null,
  periodEnd: null,
  autoRenew: false,
  lessonsUnlocked: 56,
  lessonsTotal: 56,
  nextBillingCents: null,
  memberSince: new Date().toISOString(),
};

export function useAccount() {
  const [access, setAccess] = useState<Access>(FALLBACK);
  const [orders, setOrders] = useState<AccountPayload["orders"]>([]);
  const [activity, setActivity] = useState<AccountPayload["activity"]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/account", { cache: "no-store" });
      const data = (await res.json()) as AccountPayload;
      if (data?.access) {
        setAccess(data.access);
        setOrders(data.orders ?? []);
        setActivity(data.activity ?? []);
      }
    } catch {
      // 离线时保留本地回退状态，页面仍可用
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { access, orders, activity, loading, refresh };
}
