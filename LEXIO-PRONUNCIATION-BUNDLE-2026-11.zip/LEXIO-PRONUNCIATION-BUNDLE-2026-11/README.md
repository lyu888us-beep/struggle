# Lexio pronunciation handoff audio

All generated speech uses the user's approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains matching application mappings, offline-cache entries, and production MP3 copies under `lexio-pwa-full/media/voice/`.

- `assets/media/voice/` contains **5,377 release MP3s**: 472 processable missing dictionary phrases, five user-approved original word samples, ten initial queue-word recordings, 1,328 safely cut words from groups 0–9, 1,082 safe words from groups 11–19, 1,250 safe cuts from the group-10 retry and groups 20–27, 1,227 safe cuts from groups 28–37, and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps exact phrase text to its `s-...` filename.
- `manifests/word-audio-manifest.json` is the authoritative 4,902-word map, including per-batch metadata. `word-samples.json` is retained as a compatible duplicate.
- The latest ten `voice-00 / en-US` sources covered 1,387 pending rows in groups 28–37. PocketSphinx reported no alignment failures; conservative boundary and clip-quality checks yielded 1,227 safe MP3s, while 160 rows were withheld (83 unsafe boundaries were recorded). No unsafe cut was forced. Every one of the 1,227 staged MP3s passed FFmpeg decode. See `manifests/next-batch-005-safe-cut-report.json`.
- The prior safe-cut staging directories for batches 001–004 were audited: every staged MP3 already exists byte-for-byte in production; no earlier safe word clips were left out of the site.
- Automated alignment/cut checks are not human listening. The 4,897 generated queue clips have not been individually human-listened; the user approved the original five sample words and confirmed the `voice-00` voice, not every new clip.
- The 9,830-item unique queue currently has 4,902 mapped clips and 4,928 still pending. This does not represent completion of the app's 28,414-entry word bank or the broader 20,000+ production target.
- One phrase was excluded after generation content review. Of 501 rewritten example-text targets, only three exact generated targets are mapped; the other 498 still have no matching recording.

This archive does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow separately. The iPhone 16 Pro Max / iOS 27 playback regression remains unverified on a real device.
