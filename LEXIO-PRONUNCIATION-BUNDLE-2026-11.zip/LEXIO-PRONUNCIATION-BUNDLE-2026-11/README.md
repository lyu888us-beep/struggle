# Lexio pronunciation handoff audio

All generated speech uses the user's approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains matching application mappings, offline-cache entries, and tracked production MP3 copies under `lexio-pwa-full/media/voice/`.

- `assets/media/voice/` contains **2,900 release MP3s**: 472 processable missing dictionary phrases, five user-approved original word samples, ten first queue-word recordings, 403 + 925 safely cut words from grouped pilot groups 0–9, 1,082 safely cut queue words from groups 11–19, and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps exact phrase text to its `s-...` filename.
- `manifests/word-audio-manifest.json` is the authoritative 2,425-word map, including per-batch metadata. `word-samples.json` is retained as a compatible duplicate.
- All 1,082 newest production clips passed FFmpeg decode. Automated alignment/cut checks are not human listening; the 2,420 generated queue clips have not been individually human-listened. The user approved the original five sample words and confirmed the `voice-00` voice sounded right, not every new clip.
- The next grouped generation used groups 10–19. Four already-mapped words were excluded before generation. Of the remaining 1,336 rows, 1,082 safe clips are included; 109 neighboring rows were skipped for unreliable silence boundaries, and all 145 pending rows in group 10 were skipped after exact PocketSphinx alignment failed. No unsafe or failed row is represented as generated or playable. See `manifests/next-batch-003-safe-cut-report.json`.
- Across grouped batches 002 and 003, 2,410 queue-word clips were safely cut and published. The 9,830-item unique queue currently has 2,425 mapped clips and 7,405 still pending; this does not represent completion of the app's 28,414-entry word bank or the 20,000+ production target.
- One phrase was excluded after generation content review. Of 501 rewritten example-text targets, only three exact generated targets are mapped; the other 498 still have no matching recording.

This archive does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow separately. The iPhone 16 Pro Max / iOS 27 playback regression remains unverified on a real device.
