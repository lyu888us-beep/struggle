# Lexio pronunciation handoff audio

All generated speech uses the user's approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains matching application mappings, offline-cache entries, and production MP3 copies under `lexio-pwa-full/media/voice/`.

- `assets/media/voice/` contains **4,150 release MP3s**: 472 processable missing dictionary phrases, five user-approved original word samples, ten first queue-word recordings, 403 + 925 safely cut words from grouped pilot groups 0–9, 1,082 safe words from groups 11–19, 1,250 current safe cuts (143 retried from group 10 plus groups 20–27), and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps exact phrase text to its `s-...` filename.
- `manifests/word-audio-manifest.json` is the authoritative 3,675-word map, including per-batch metadata. `word-samples.json` is retained as a compatible duplicate.
- All 1,250 newest production clips passed FFmpeg decode. Automated alignment/cut checks are not human listening; the 3,670 generated queue clips have not been individually human-listened. The user approved the original five sample words and confirmed the `voice-00` voice sounded right, not every new clip.
- The latest ten source recordings covered 1,285 pending rows: two shorter sources retried group 10 after its previous exact-alignment failure, and eight more covered groups 20–27. The group-10 retry omitted the already-mapped sample “comfortable”; groups 20–27 omitted the already-mapped entries “entrepreneur” and “essential”. 1,250 clips were safely cut; 35 neighboring rows were skipped for unreliable silence boundaries. No unsafe row is represented as generated or playable. See `manifests/next-batch-004-safe-cut-report.json`.
- The 9,830-item unique queue currently has 3,675 mapped clips and 6,155 still pending; this does not represent completion of the app's 28,414-entry word bank or the 20,000+ production target.
- One phrase was excluded after generation content review. Of 501 rewritten example-text targets, only three exact generated targets are mapped; the other 498 still have no matching recording.

This archive does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow separately. The iPhone 16 Pro Max / iOS 27 playback regression remains unverified on a real device.
