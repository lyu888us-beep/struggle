# Lexio pronunciation handoff assets

All produced speech uses the already approved voice-00, en-US. This archive is a handoff bundle only: it is stored at repository root, outside lexio-pwa-full, and does not deploy to Pages.

- `assets/media/voice/s-*.mp3` plus `manifests/phrase-clips.json`: 472 processable missing phrases (173 earlier staged + 299 newly generated and PocketSphinx-aligned/cut). One reviewed phrase remains excluded. Alignment is not human listening.
- `assets/media/voice/w-*.mp3` plus `manifests/word-samples.json`: five approved pronunciation samples: comfortable, rural, schedule, entrepreneur, thorough. This is not the full 9,830-word set.
- `assets/exact-targets/`: three rewritten example MP3s generated for the breath, count-by-tens, and LED cases. These are not yet aligned or wired into the app.
- `source-changes.patch`: uncommitted tracked source changes relative to the branch HEAD when this archive was built. In a fresh checkout, inspect `git status` first; apply with `git apply` only if the same edits are absent.
- `manifests/phrase-clips.json` maps exact phrase text to clip ID. Word manifest maps lowercase word to clip ID.

No audio in this archive is deployed. Do not publish until selectedRecordings and sw.js bulkAssets are updated, tests pass, and the remaining rewritten-target aliases to old audio are removed or verified.
