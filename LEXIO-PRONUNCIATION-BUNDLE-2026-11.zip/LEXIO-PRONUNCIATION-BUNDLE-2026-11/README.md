# Lexio pronunciation handoff audio

All generated speech uses the already approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains the matching application mappings, offline cache list, and tracked MP3 copies under `lexio-pwa-full/media/voice/`; do not reapply an old source patch.

- `assets/media/voice/` contains 490 release MP3s: 472 processable missing dictionary phrases, five previously user-approved word samples, ten new queue-word recordings, and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps the exact phrase text to its `s-...` filename. The 472 keys are distinct from each other.
- `manifests/word-samples.json` contains 15 generated words. The five previously user-approved samples are listed separately from the ten new queue words. The ten new words passed PocketSphinx alignment but have not been individually human-listened. This is not the 9,830-word queue; no full word-bank batch is claimed generated.
- `assets/exact-targets/` preserves the three original generated MP3s; their aligned release derivatives are in `assets/media/voice/` and listed in `manifests/exact-targets.json`.
- The 472 phrases were automatically word-aligned and safely cut; the three exact target clips and ten new word clips passed PocketSphinx alignment. FFmpeg decode checks passed for all 490 release clips. Automatic checks are not human listening. The user approved the voice quality of the five original sample words only.
- One phrase was excluded after generation content review. The 501 rewritten example-text targets no longer reuse stale old recordings; only three exact generated targets are mapped, leaving the other 498 without a matching recording for now.

The archive itself does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow status separately. iPhone 16 Pro Max / iOS 27 has not yet been retested.
