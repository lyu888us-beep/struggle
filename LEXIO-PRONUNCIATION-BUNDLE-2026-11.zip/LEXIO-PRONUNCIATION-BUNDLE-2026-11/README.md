# Lexio pronunciation handoff audio

All generated speech uses the user's approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains matching application mappings, offline-cache entries, and tracked production MP3 copies under `lexio-pwa-full/media/voice/`.

- `assets/media/voice/` contains **1,818 release MP3s**: 472 processable missing dictionary phrases, five user-approved original word samples, ten first queue-word recordings, 403 safely cut words from the first grouped pilot batch, 925 additional safely cut queue words, and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps exact phrase text to its `s-...` filename.
- `manifests/word-audio-manifest.json` is the authoritative 1,343-word map, including per-batch metadata. `word-samples.json` is retained as a compatible duplicate.
- The 925 newest clips were all checked with FFmpeg decode (925/925). Automated alignment/cut checks are not human listening; the 1,338 generated queue clips have not been individually human-listened. The user approved the original five sample words and confirmed the `voice-00` voice sounded right, not every new clip.
- Ten grouped source recordings covered 1,423 queue items; 1,328 safely cut clips are now included across two safe-cut passes. **95 rows** were excluded because reliable silence boundaries could not be confirmed. They are not represented as generated or playable. See `manifests/next-batch-002-safe-cut-report.json`.
- The 9,830-item unique queue currently has 1,343 mapped clips and 8,487 items still pending. This does not represent completion of the app's 28,414-entry word bank or the 20,000+ production target.
- One phrase was excluded after generation content review. Of 501 rewritten example-text targets, only three exact generated targets are mapped; the other 498 still have no matching recording.

This archive does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow separately. The iPhone 16 Pro Max / iOS 27 playback regression remains unverified on a real device.
