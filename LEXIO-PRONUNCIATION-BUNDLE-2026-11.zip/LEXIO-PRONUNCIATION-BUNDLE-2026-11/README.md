# Lexio pronunciation handoff audio

All generated speech uses the already approved `voice-00`, `en-US`. This archive is an optional audio/manifests backup, not the website or a deployable app by itself. The current branch contains the matching application mapping, offline cache list, and tracked MP3 copies under `lexio-pwa-full/media/voice/`; do not reapply an old source patch.

- `assets/media/voice/` contains 480 release MP3s: 472 processable missing dictionary phrases, five user-approved word samples, and three aligned exact-target example sentences.
- `manifests/phrase-clips.json` maps the exact phrase text to its `s-...` filename. The 472 keys are distinct from each other.
- `manifests/word-samples.json` contains only `comfortable`, `rural`, `schedule`, `entrepreneur`, and `thorough`. This is not the 9,830-word queue; no full word-bank batch is included or claimed generated.
- `assets/exact-targets/` preserves the three original generated MP3s; their aligned release derivatives are in `assets/media/voice/` and listed in `manifests/exact-targets.json`.
- The 472 phrases were automatically word-aligned and safely cut; the three exact target clips also passed PocketSphinx text alignment. An FFmpeg decode check passed for all 480 release clips. Automatic checks are not human listening. The user approved the voice quality of the five listed word samples only; the new phrases and exact-target clips have not been listened to one by one.
- One phrase was excluded after generation content review. The 501 rewritten example-text targets no longer reuse stale old recordings; only three exact generated targets are mapped, leaving the other 498 without a matching recording for now.

The archive itself does not trigger or constitute a Pages deployment. Site audio files are tracked in `lexio-pwa-full/media/voice/`; the app source and `sw.js` include their mappings and offline resources. Confirm the GitHub Pages workflow status separately. iPhone 16 Pro Max / iOS 27 has not yet been retested.
